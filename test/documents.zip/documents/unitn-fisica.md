

* **Livello**: Laurea di primo livello
* **Classe** del corso:**L-30 - Scienze e tecnologie fisiche**
* **Lingua** in cui si tiene il corso: **Italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova di ammissione
* **Sede**: Dipartimento di Fisica, via Sommarive 14, 38123 Povo (TN).

Obiettivi formativi
-------------------

Il laureato/La laureata in Fisica di Trento:

* possiede una solida preparazione nelle discipline comprese negli ambiti Discipline matematiche e informatiche e Discipline chimiche, con particolare riferimento alla matematica;
* è in grado di privilegiare gli aspetti generali e di base delle discipline comprese negli ambiti Sperimentale e applicativo, Teorico e dei fondamenti della Fisica e Microfisico e della struttura della materia delle attività caratterizzanti indicate nella tabella delle attività formative del presente ordinamento, e in particolare della struttura della materia fino al livello nucleare e subnucleare;
* ha una solida preparazione di tipo **sperimentale** conseguita tramite l'offerta di strutture avanzate di 'laboratorio didattico';
* ha familiarità con gli s**trumenti teorico-matematici, tecnologico-sperimentali e anche informatico-computazionali** relativi alle singole discipline;
* è in grado di integrare fra loro gli strumenti di cui al punto precedente;
* è in grado di svolgere, direttamente o dopo un breve tirocinio, attività lavorative che richiedano una certa familiarità con **tecnologie innovative**;
* è in grado di sviluppare e analizzare **modelli per sistemi complessi** con applicazioni in ambito industriale, finanziario o nei servizi in cui fossero richiesti;
* è in grado di affrontare con profitto qualsiasi specializzazione all'interno di un corso di Laurea Magistrale della classe di Fisica.

Il corso è strutturato in un unico percorso.

Profili professionali
---------------------

Il/La laureato/a in Fisica di Trento sarà in grado di:

* svolgere attività che richiedano l'applicazione della fisica in **settori tecnologici e di ricerca e sviluppo** (tra cui elettronica, ottica, informatica, acustica, meccanica);
* ricoprire ruoli tecnici in attività di **laboratorio** e dei servizi relativi alla radioprotezione, al controllo e sicurezza ambientale, allo sviluppo e caratterizzazione di materiali, alle telecomunicazioni, ai controlli remoti di sistemi satellitari;
* operare in contesti che richiedano la capacità di applicare il metodo scientifico alla soluzione di problemi, alla elaborazione di modelli, alla **raccolta di dati e alla loro analisi**.

Il/La laureato/a in Fisica di Trento, nello svolgimento dei suddetti compiti, avrà modo di esercitare la capacità di analisi e  

modellizzazione di fenomeni complessi con metodologia scientifica, la capacità di problem solving, la capacità di gestione di apparecchiature tecnologicamente avanzate.

Tra i principali ambiti occupazionali, si indicano:

* la prosecuzione degli studi di 2° livello in fisica o altre discipline scientifiche;
* l'industria, con particolare riferimento ai settori dell'elettronica, dell'informatica e dell’energetica;
* il terziario avanzato, in particolare negli ambiti che richiedono lo sviluppo di modelli quantitativi per l'analisi di sistemi complessi e l'analisi dei dati, come l'ambito economico e/o ambientale.

Riguardo alle codifiche ISTAT il corso prepara alla professione di:

* Tecnici fisici e nucleari - (3.1.1.1.2)

Il corso consente inoltre di conseguire l'abilitazione alla professione di perito industriale laureato

Studi che si possono intraprendere dopo la laurea
-------------------------------------------------

La preparazione acquisita con la laurea in Fisica può proseguire con il conseguimento della Laurea Magistrale in Fisica (classe LM-17 delle lauree magistrali in Fisica).








Offerta formativa del corso
---------------------------

* [Percorso del corso di laurea in Fisica](#fisica)
* [Percorso di approfondimento in Fisica](#fisica-approfondimento)

Percorso del corso di laurea in Fisica
--------------------------------------

### Primo anno

| **Analisi matematica I** Il corso ha l’obiettivo di proporre il calcolo differenziale e integrale di funzioni reali di una variabile reale, fino alle equazioni differenziali ordinarie di tipo lineare, fornendone non solo le tecniche e i formalismi, necessari ai corsi che seguiranno, ma anche i fondamenti e le basi logiche. | 9 crediti |
| --- | --- |
| **Fisica generale I** Il corso ha l’obiettivo di far apprendere allo studente gli obiettivi generali e gli strumenti d'indagine della fisica, tramite lo studio approfondito dei principi della meccanica classica newtoniana di una particella, di sistemi di particelle e di corpi rigidi, e dei principi della termodinamica, con alcune loro applicazioni significative. | 15 crediti |
| **Geometria I** Il corso ha l’obiettivo di familiarizzare lo studente con i metodi elementari dell'algebra lineare. Prerequisito per seguire con profitto il corso è la conoscenza delle tecniche elementari per eseguire facili calcoli con numeri interi e razionali. | 9 crediti |
| **Analisi matematica II** Il corso ha l’obiettivo di continuare la formazione matematica introducendo basilari concetti di topologia e il calcolo differenziale per funzioni di più variabili, il problema dei massimi e minimi liberi e vincolati, il teorema delle funzioni implicite e sue applicazioni, la teoria dell'esistenza del problema di Cauchy per le equazioni differenziali (ordinarie), la pratica per la risoluzione di sistemi di equazioni differenziali lineari, le serie di funzioni. Si richiede la conoscenza dei contenuti del corso di Geometria I e di Analisi matematica I. | 9 crediti |
| **Programmazione scientifica** Il corso punta a fornire le basi minime della programmazione scientifica, punto di partenza per l’analisi dei dati e gli studi di fisica computazionale. Sono previste esercitazioni al calcolatore. | 6 crediti |
| **Laboratorio di Fisica I** Il corso fornisce una introduzione al metodo scientifico sperimentale ed alla pratica di laboratorio tramite la conduzione di semplici esperimenti di meccanica e termodinamica, confrontando strategie di misura diverse. Gli obiettivi formativi includono le tecniche di base per l'analisi dei dati e la valutazione degli errori, nonché i concetti elementari della teoria delle probabilità e della statistica. | 9 crediti |

### Secondo anno

| **Analisi matematica III** Il corso ha l’obiettivo di far apprendere la teoria e le applicazioni del calcolo integrale per funzioni reali e campi vettoriali di più variabili reali. La teoria del calcolo differenziale per funzioni di più variabili reali e la teoria del calcolo integrale per funzioni di una variabile reale, sviluppate nei corsi di Analisi matematica I e II, costituiscono un prerequisito essenziale. | 6 crediti |
| --- | --- |
| **Fisica generale II** Il corso ha l’obiettivo di introdurre i concetti fondamentali dell'elettricità e del magnetismo, descrivere le proprietà elettriche e magnetiche della materia a partire da un approccio mesoscopico, e gettare le basi per le successive applicazioni delle equazioni di Maxwell. | 9 crediti |
| **Laboratorio di fisica II (mod. A)** Il corso ha l’obiettivo di familiarizzare gli studenti con aspetti sperimentali relativi ai fenomeni elettrici e magnetici, circuiti elettrici e reti lineari, strumentazione elettronica di base, linee di trasmissione, adattamento di impedenza. | 9 crediti |
| **Laboratorio di fisica II (mod. B)** Il corso ha l’obiettivo di familiarizzare gli studenti con aspetti sperimentali relativi all’ottica geometrica e ondulatoria. | 6 crediti |
| **Meccanica analitica** Il corso ha l’obiettivo di familiarizzare gli studenti con la formulazione Lagrangiana e Hamiltoniana della meccanica classica. | 9 crediti |
| **Metodi matematici per la fisica** Il corso ha l’obiettivo di introdurre lo studente ad alcuni specifici strumenti matematici necessari per la descrizione dei fenomeni fisici della fisica classica e quantistica. Sono prerequisiti essenziali le conoscenze apprese nei corsi di Analisi matematica e di Geometria. | 6 crediti |
| **Fisica generale III** Il corso ha l’obiettivo di avviare allo studio dei fenomeni elettrici e magnetici dipendenti dal tempo utilizzando gli strumenti matematici più adeguati e illustrando le conseguenze formali e pratiche che possono scaturirne (proprietà elettriche e magnetiche della materia, teoria elettromagnetica della luce, interazione tra luce e materia e relatività speciale). Vengono inoltre introdotti i primi concetti della fisica quantistica, offrendo un quadro dei fatti sperimentali e delle conquiste teoriche che indussero a pensare a nuovi principi per la descrizione dei fenomeni microscopici. | 9 crediti |
| **Chimica con esercitazioni di laboratorio** Il corso ha l’obiettivo di fornire agli studenti i fondamenti sperimentali e teorici della chimica e quella minima capacità tecnica che permette loro di sapersi muovere in un laboratorio di chimica. Particolare enfasi viene data alla struttura atomica della materia, alle proprietà chimico-fisiche delle sostanze, alla termodinamica dei processi chimici ed allo studio degli equilibri in soluzione. | 9 crediti |

### Terzo anno

| **Laboratorio di Fisica III** Il corso ha l’obiettivo di approfondire la conoscenza dei sistemi lineari e delle tecniche sperimentali principali in elettronica analogica e digitale. | 9 crediti |
| --- | --- |
| **Introduzione alla meccanica statistica** Il corso ha l’obiettivo di familiarizzare lo studente con la trattazione statistica all'equilibrio termodinamico di un sistema meccanico classico e quantistico con N gradi di libertà. La conoscenza della meccanica Hamiltoniana è un importante prerequisito. | 6 crediti |
| **Complementi matematici della meccanica quantistica** Il corso ha l’obiettivo di approfondire le basi formali e matematiche della meccanica quantistica non relativistica e di familiarizzare lo studente con la soluzione di problemi di meccanica quantistica. | 6 crediti |
| **Meccanica quantistica** Il corso ha l’obiettivo di introdurre i concetti fondamentali della meccanica quantistica non relativistica. | 6 crediti |
| **Fisica nucleare e subnucleare** Il corso ha l’obiettivo di presentare un'introduzione ai concetti e oggetti tipici della fisica nucleare e della fisica delle particelle, sottolineando le idee unificatrici e gli strumenti comuni. | 6 crediti |
| **Struttura della materia** Il corso ha l’obiettivo di far comprendere i meccanismi microscopici quantistici che determinano le principali proprietà della materia allo stato atomico, molecolare e condensato. | 6 crediti |
| **Ulteriori competenze linguistiche: lingua inglese livello B2** Il corso intende offrire gli strumenti necessari per acquisire competenze linguistiche in campo tecnico-scientifico a livello B2. | 6 crediti |
| **Attività a scelta libera** 12 CFU senza vincoli di settore disciplinare scelti tra gli insegnamenti presenti nell'offerta formativa erogata annualmente dal Corso di Laurea oppure, previo consenso della struttura responsabile, tra gli altri corsi erogati dall’Ateneo. Tali crediti possono essere dedicati, su richiesta dello studente e con l’approvazione della struttura didattica competente, ad attività formative coordinate svolte anche all’esterno dell’università nel quadro di specifici accordi e con la supervisione di un docente del Corso di Laurea che, al termine dell'attività assegnerà un voto in trentesimi con eventuale lode, anche in base ad una relazione conclusiva presentata dallo studente. | 12 crediti |
| **Prova finale** Stesura di un elaborato scritto e esame pubblico (3 crediti da assegnare per il contenuto e la presentazione dell'elaborato finale e 3 crediti da assegnare per la capacità di comunicazione in lingua inglese). | 6 crediti |

Percorso di Approfondimento di Fisica - PAF
-------------------------------------------

Il percorso di approfondimento in Fisica ha durata triennale e integra il corso di laurea in Fisica.  

L'obiettivo del percorso è quello di fornire agli studenti particolarmente capaci e motivati uno strumento utile a consolidare ed ampliare le loro conoscenze in fisica e matematica, integrando gli insegnamenti già previsti dal corso di laurea, coprendo eventuali lacune, e acquisendo la confidenza con le basi del sapere scientifico necessaria ad un proficuo proseguimento degli studi nella laurea magistrale.

Maggiori informazioni sono disponibili alla pagina [Percorso di Approfondimento in Fisica - PAF](percorso-di-approfondimento-fisica-paf).








Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 

