

* **Livello**: Laurea di primo livello
* **Classe del corso**: **L-35**- **Scienze Matematiche**
* **Lingua** in cui si tiene il corso: Italiano
* **Modalità di accesso**: accesso a numero **programmato**, con superamento di una prova di ammissione
* **Sede**: Dipartimento di Matematica, via Sommarive 14, 38123 Povo (TN).

Obiettivi formativi
-------------------

Lo scopo del corso di laurea in Matematica dell'Università di Trento è la formazione di laureati che:

* abbiano una solida conoscenza delle nozioni di base e dei metodi propri dei vari settori della matematica e in particolare dell'algebra, della geometria, dell'analisi matematica e della probabilità
* dimostrino abilità matematiche nel ragionamento, nella manipolazione e nel calcolo, e capacità di costruire dimostrazioni rigorose
* siano capaci di comprendere e utilizzare descrizioni e modelli matematici nell'ambito della fisica, delle scienze naturali, dell'ingegneria, dell'economia e delle scienze umane; adeguate competenze informatiche
* possiedano conoscenze utili per riflettere criticamente sulla matematica e sulla scienza, sui loro metodi e sul loro sviluppo, e sul loro rapporto con le scienze umane e la società
* siano in grado di studiare autonomamente testi matematici, in italiano e in inglese, e di esporre il materiale studiato in forma scritta e orale, adeguata a vari tipi di pubblico, utilizzando opportuni strumenti informatici;abbiano adeguate competenze e strumenti per la comunicazione e la gestione dell'informazione
* siano capaci di lavorare in gruppo e di inserirsi prontamente negli ambienti di lavoro;possiedano una mentalità predisposta al rapido apprendimento di nuovi concetti e metodi.

Profili professionali
---------------------

I primi due anni della laurea in Matematica forniscono una preparazione di base utile sia per proseguire gli studi con una laurea magistrale sia per sviluppare attività professionale. I laureati nel corso di laurea in Matematica potranno, scegliendo opportunamente le attività opzionali del terzo anno, svolgere attività professionali:

* nelle aziende e nell'industria
* nel campo della diffusione della cultura scientifica
* nel settore dei servizi
* nella pubblica amministrazione.

Gli ambiti di interesse sono vari, tra cui quelli **informatico**, **finanziario**, della **comunicazione**, **scientifico** e più in generale in tutti i casi in cui sia utile una mentalità flessibile, **competenze computazionali e informatiche**, e una buona dimestichezza con la **gestione**, l'**analisi e il trattamento di dati numerici**.

Scegliendo opportunamente il curriculum e le attività opzionali, i laureati potranno svolgere le attività professionali di Matematici, Statistici, Analisti di sistema.









In questa pagina è presentato il percorso formativo generale previsto dal Regolamento didattico.

Per conoscere nel dettaglio i contenuti del corso è possibile consultare

* il [Manifesto degli Studi](https://offertaformativa.unitn.it/it/l/matematica/regolamenti-e-manifesti), con le attività formative attivate nei vari anni accademici
* i [Syllabi](https://www.esse3.unitn.it/Guide/PaginaRicercaInse.do), i programmi degli insegnamenti dell'anno accademico in corso.

### Primo anno

| Insegnamenti obbligatori | |
| --- | --- |
| **Analisi matematica A1** Introdurre le nozioni fondamentali del calcolo differenziale e integrale per funzioni di una variabile reale, delle successioni e serie numeriche, sviluppando sia una teoria rigorosa sia competenze operative. | 9 crediti |
| **Analisi matematica A2** Fornire le conoscenze di base della teoria del calcolo differenziale per funzioni di più variabili reali, con applicazione in particolare a problemi di ottimizzazione libera e vincolata. | 6 crediti |
| **Fisica generale I (modulo 1)** Far apprendere allo studente gli obiettivi generali e gli strumenti d'indagine della fisica, tramite lo studio approfondito dei principi della meccanica classica newtoniana. | 9 crediti |
| **Geometria A** Fornire una prima introduzione della teoria degli insiemi da un punto di vista semi assiomatico, basilare per tutti gli sviluppi successivi. Su questa base viene quindi fornita una approfondita e rigorosa introduzione ai metodi e ai concetti di base dell’algebra lineare. Fornire una introduzione rigorosa a una varietà di concetti e metodi geometrici classici. Lo studente viene quindi portato a una conoscenza operativa degli spazi affini e proiettivi e della teoria delle forme quadratiche. | 15 crediti |
| **Inglese B1** Supportare la preparazione all’accertamento della conoscenza dell'inglese scientifico, con capacità di comprendere testi scientifici scritti o parlati ad un livello almeno pari al livello B1 del Consiglio d'Europa. | 3 crediti |
| **Informatica** Introdurre agli studenti la programmazione imperativa, fornendo sia le fondamenta teoriche che le competenze pratiche. Vengono quindi presentati le basi della programmazione, gli algoritmi fondamentali e i metodi per potere ragionare rigorosamente sulla correttezza dei programmi. Nell’attività di laboratorio si applicano tali nozioni in modo da acquisire una conoscenza operativa. | 6 crediti |
| **Algebra A** L’obiettivo del corso è, partendo da strutture familiari quali i numeri interi, di introdurre i primi elementi di astrazione, presentando anche alcune applicazioni. | 6 crediti |

| Un insegnamento a scelta tra | |
| --- | --- |
| **Fisica generale I (modulo 2)** Far apprendere allo studente gli obiettivi generali e gli strumenti d'indagine della fisica, tramite lo studio approfondito dei principi della meccanica classica newtoniana. | 6 crediti |
| **Laboratorio di programmazione** | 6 crediti |

### Secondo Anno

| Insegnamenti obbligatori | |
| --- | --- |
| **Algebra B** L’obiettivo del corso è, partendo da strutture familiari quali i numeri interi, di introdurre i primi elementi di astrazione, presentando anche alcune applicazioni. | 6 crediti |
| **Analisi matematica B** Introduzione a capitoli importanti dell'analisi matematica: 1) successioni e serie di funzioni; 2) i primi elementi della teoria delle equazioni differenziali ordinarie; 3) elementi di una teoria moderna della misura e dell'integrazione, con particolare riferimento alla misura di Lebesgue, e calcolo di integrali di volume; 4) forme differenziali, integrali di linea e di superficie, teoremi della divergenza e del rotore. | 12 crediti |
| **Analisi numerica I** Analisi di metodi per l'approssimazione numerica della soluzione di alcune classi di problemi della Matematica. I diversi metodi saranno implementati in linguaggio Matlab e sperimentati su vari esempi. Gli argomenti trattati includeranno: risoluzione di sistemi lineari; approssimazione di autovalori e autovettori; risoluzione di equazioni non lineari; approssimazione polinomiale; integrazione numerica; equazioni differenziali ordinarie. | 9 crediti |
| **Calcolo delle probabilità e statistica matematica** Fornire una introduzione al concetto di evento e di probabilità, partendo da un approccio intuitivo, si perviene a una trattazione rigorosa ed assiomatica, sia nel caso discreto che in quello continuo, dove gioca un ruolo essenziale la teoria della misura. Con gli strumenti così consolidati si perviene alla legge dei grandi numeri e al teorema centrale asintotico. Successivamente si fornirà una introduzione ai concetti di base della statistica come la stima di parametri e il test di ipotesi. | 9 crediti |
| **Fondamenti di fisica matematica** Fornire dapprima una formulazione matematica rigorosa della meccanica classica del punto materiale e dei sistemi di punti, per poi pervenire a una introduzione alla teoria delle equazioni differenziali a derivate parziali con applicazioni alla fisica matematica. | 12 crediti |
| **Geometria B** Presentare i concetti di base di topologia, procedendo poi a una introduzione all’omotopia e al concetto di gruppo fondamentale. Esporre gli studenti a un approccio classico e rigoroso alla teoria delle funzioni di una variabile complessa. | 12 crediti |

| Altre attività | |
| --- | --- |
| **Strumenti informatici per la matematica** Obiettivo del corso è quello di fornire una conoscenza di base del linguaggio LaTeX per la preparazione di testi scientifici, e di un altro software utilizzato nella ricerca o nelle applicazioni della Matematica (a scelta tra diverse proposte). | 3 crediti |

### Terzo anno

| 4 insegnamenti a scelta tra | |
| --- | --- |
| **Fondamenti logici della matematica** Giungere a una riflessione su alcune nozioni fondamentali per la pratica matematica, ad esempio quelle di insieme, di dimostrazione, di cardinalità, di numero naturale; formalizzazione di tali nozioni, in modo da farle diventare oggetto di studio per la matematica; acquisizione delle conoscenze elementari di aritmetica cardinale. | 6 crediti |
| **Geometria C** Introdurre gli oggetti e i metodi della geometria differenziale nei casi più semplici e concreti, cioè per curve e superfici immerse nello spazio euclideo tridimensionale. | 6 crediti |
| **Teoria di Galois** Fornire i principali risultati e metodi della Teoria di Galois, come: il campo di spezzamento di un polinomio, il suo gruppo di Galois, la corrispondenza di Galois, e il teorema di Galois sulla risolubilità di equazioni polinomiali per radicali. | 6 crediti |
| **Analisi matematica C** Fornire un'introduzione alle idee e strumenti di base dell'analisi in spazi infinito-dimensionali, presentando le definizioni ed i primi risultati astratti sugli spazi normati, di Banach e di Hilbert. La teoria generale viene applicata allo studio delle proprietà dei principali spazi di funzioni. | 6 crediti |
| **Statistica Matematica** Lo scopo principale del corso consiste nell'affrontare lo studio dei fondamenti della statistica teorica, nelle sue varie articolazioni, a partire dai principi primi del calcolo delle probabilità. La parte centrale del corso sarà dedicata allo studio della teoria della stima e della verifica di ipotesi basata sull’approccio di verosimiglianza. Attenzione sarà riservata anche al paradigma inferenziale bayesiano e alle tecniche computer intensive. | 6 crediti |
| **Calcolo delle probabilità II** Il corso approfondisce concetti di base quali spazi di probabilità e variabili aleatorie utilizzando la teoria della misura. Vengono trattati in dettaglio argomenti quali la funzione caratteristica di variabili aleatorie, il teorema di Dynkin, i vari tipi di convergenza di variabili aleatorie e la legge forte dei grandi numeri. Il corso fornisce inoltre un'introduzione alla teoria ed alle applicazioni delle catene di Markov | 6 crediti |
| **Fondamenti di Fisica Matematica** Il corso ha lo scopo di introdurre la teoria delle equazioni differenziali a derivate parziali con applicazioni alla fisica matematica | 6 crediti |
| **Analisi numerica II** Nel corso si presentano e analizzano metodi numerici per l'approssimazione della soluzione dei seguenti tipi di problemi: calcolo degli autovalori e autovettori di una matrice, risoluzione di sistemi di equazioni non lineari, ricerca di un punto di minimo di una funzione in una o più variabile e problemi ai limiti per equazioni differenziali. L'obiettivo è fornire agli studenti le competenze per valutare quale metodo utilizzare nelle diverse situazioni e saperli usare e implementare correttamente | 6 crediti |
| Insegnamenti obbligatori | |
| --- | --- |
| **Attività didattiche affini/integrative** 12 CFU a scelta da un’ampia offerta di Attività Didattiche. | 12 crediti |
| **Prova finale** Presentazione orale della durata indicativa di 20 minuti di un argomento concordato con il Supervisore, accompagnata da un elaborato scritto di 15-20 cartelle, redatto in lingua italiana oppure in lingua inglese, seguita da eventuale discussione con la Commissione. | 6 crediti |









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 

