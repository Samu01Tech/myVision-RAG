

* **Livello**: Laurea di **primo livello**
* **Classe** del corso: **L-7 - Ingegneria civile e ambientale**
* **Lingua** in cui si tiene il corso: **italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Ingegneria Civile, Ambientale e Meccanica, via Mesiano, 77 38123 Trento

Obiettivi formativi
-------------------

Il corso di laurea in Ingegneria Civile forma una **figura professionale in grado di operare all’interno di gruppi di lavoro dediti alla progettazione o alla realizzazione di opere ingegneristiche** e che siano in grado di **acquisire, anche autonomamente, ulteriori competenze specifiche nei campi più applicativi dell’Ingegneria Civile**. Ulteriore e importante obiettivo del percorso di studi è quello di fornire una preparazione metodologica di base che consenta ai laureati e alle laureate di intraprendere con profitto i successivi percorsi di formazione superiore di laurea magistrale.

Il corso di laurea in Ingegneria Civile consente di acquisire anche le competenze richieste dal settore delle costruzioni ormai nel pieno della quarta rivoluzione industriale. Esse riguardano principalmente il **rinnovato rapporto delle opere civili con il territorio** e l’**impiego nelle opere civili di tecnologie innovative smart e green, dell’information technology, e dell’Internet of Things**.

[Cosa si studia](https://offertaformativa.unitn.it/it/l/ingegneria-civile/cosa-si-studia)  


Profili professionali
---------------------

I laureati e le laureate in Ingegneria Civile potranno trovare occupazione presso **studi professionali e società di progettazione di opere, impianti ed infrastrutture, presso imprese di costruzioni, Enti e Uffici Pubblici di progettazione, pianificazione, gestione e controllo del patrimonio edilizio, di sistemi urbani e territoriali, di sistemi di trasporto**. Altri sbocchi professionali possono riguardare le **carriere direttive o altri ruoli di responsabilità** in aziende private di piccole e medie dimensioni nelle costruzioni (edilizia), nei trasporti e nelle comunicazioni.

Le funzioni che possono svolgere laureati e laureate sono principalmente quelle di:

* progettista di opere, impianti ed infrastrutture civili (nei limiti stabiliti per gli ingegneri junior)
* componente di gruppi di progettazione avanzata di opere, impianti ed infrastrutture civili
* responsabile della pianificazione, gestione e controllo del patrimonio edilizio, di sistemi urbani e territoriali, di sistemi di trasporto
* componente di gruppi di lavoro tecnico nel campo della protezione civile e del territorio

[Testimonianze sulle prospettive professionali dei laureati e delle laureate in Ingegneria Civile](orientamento-professionale)

Studi che si possono intraprendere dopo la laurea
-------------------------------------------------

La preparazione acquisita con la laurea in Ingegneria Civile può proseguire con ilc onseguimento della [laurea magistrale in Ingegneria Civile](https://offertaformativa.unitn.it/it/lm/ingegneria-civile).  

Inoltre, la laurea in Ingegneria Civile permette di accedere anche ai corsi di laurea magistrale in [Ingegneria Energetica](https://offertaformativa.unitn.it/it/lm/ingegneria-energetica) e in [Environmental Meteorology](https://offertaformativa.unitn.it/en/lm/environmental-meteorology) offerte dal Dipartimento di Ingegneria civile, ambientale e meccanica.









### Primo anno

| Insegnamenti | |
| --- | --- |
| **Analisi matematica 1** Il corso mira ad introdurre gli argomenti basilari dell'analisi infinitesimale in una variabile: numeri reali e numeri complessi, limiti di successioni e di funzioni, funzioni continue, derivate, approssimazione polinomiale, integrali e integrali impropri, serie numeriche, serie di potenze e serie di Fourier, equazioni differenziali lineari e non lineari. | 12 crediti |
| **Chimica** Il corso fornisce i concetti basilari della disciplina chimica. Questi prevedono: la descrizione della struttura degli atomi (composizione nucleare e configurazione elettronica) al fine di comprendere la diversa reattività dei vari elementi; la descrizione dei legami chimici (ionico e covalente) per giustificare la formazione dei vari composti chimici e le loro proprietà chimico-fisiche; la descrizione delle interazioni tra atomi e molecole per comprendere i diversi stati di aggregazione della materia e le loro transizioni di fase. Con un breve richiamo dei risultati del primo e secondo principio della termodinamica sono presentate le grandezze energia interna, entalpia, entropia ed energia libera utili nello studio del decorso delle reazioni chimiche al fine di prevederne il bilancio termico, il verso spontaneo, le condizioni di equilibrio, le reali conversioni dei reagenti in prodotti. Nell'ultima parte del corso, questi aspetti sono presentati specificatamente nello studio delle più comuni reazioni quali: la dissoluzione di soluti solidi; la dissociazione di sostanze acide e basiche in soluzioni acquose; le reazioni di ossidoriduzione coinvolte nella formazione e utilizzo di pile chimiche e nei fenomeni di ossidazione dei metalli. | 6 crediti |
| **Disegno civile + CAD** Il corso integrato ha l'obiettivo di avviare lo studente alla comprensione dello spazio costruito per il tramite degli strumenti concettuali e operativi del disegno. La rappresentazione grafica è quindi intesa in senso ampio, non come mero insieme di operazioni pratiche volte alla produzione di un'immagine, ma come luogo privilegiato del rapporto tra riflessione teorica e realtà fisica, cioè forma di conoscenza critica degli aspetti geometrici e materiali degli oggetti. I due principali ambiti che possono concorrere alla formazione di base dell'ingegnere sono per un verso la struttura geometrica dei procedimenti e, per altro verso, la capacità tecnica nell'espressione e comunicazione grafica. Pertanto il corso intende approfondire i metodi della rappresentazione in proiezioni prospettiche, ortogonali e assonometriche necessari all'elaborazione degli oggetti nello spazio, ma anche i codici e le norme utili a prefigurare il progetto garantendone la redazione formalmente corretta e l'esatta trasmissibilità. | 9 crediti |
| **Lingua inglese livello B2** | 3 crediti |
| **Fisica 1** Il corso ha lo scopo di fornire i fondamenti concettuali ed operativi del metodo sperimentale in fisica, trattando quindi la cinematica e la dinamica classiche, sia del punto materiale sia dei sistemi di punti, arrivando fino alla trattazione della dinamica del corpo rigido. Il corso è integrato da numerosi esercizi di applicazione volti a sviluppare nello studente la capacità di modellare un semplice problema fisico e di trovarne la soluzione. Le conoscenze acquisite sono verificate attraverso una prova scritta, richiedente la risoluzione di uno o più problemi fisici, e di una prova orale vertente sia su argomenti teorici sia sulla discussione dello scritto. | 9 crediti |
| **Durabilità dei materiali da costruzione** Il corso ha l’obiettivo di introdurre gli studenti alla conoscenza dei materiali di uso comune nelle costruzioni civili. Saranno approfondite le relazioni tra proprietà termomeccaniche e composizione/microstruttura dei materiali, per guidare alla scelta di quelli più idonei agli impieghi ingegneristici. Particolare attenzione sarà dedicata allo studio delle possibili forme sia di corrosione dei materiali metallici che di degradazione dei calcestruzzi nelle condizioni ambientali di utilizzo. Gli studenti apprenderanno i metodi di protezione per una scelta più consapevole su quali i più adeguati all’applicazione su strutture in opera. | 6 crediti |
| **Geometria e algebra lineare con elementi di statistica** Il corso intende fornire ai futuri ingegneri elementi di geometria analitica nel piano e nello spazio tridimensionale, nonché un'adeguata conoscenza dei principali metodi dell'algebra lineare. L'efficace formalismo di questa sarà introdotto gradualmente, valorizzando l'intuizione visiva e seguendo un approccio prevalentemente operativo. Per la parte di geometria e algebra lineare il principale obiettivo formativo del corso consiste pertanto nell'apprendimento e nella pratica del linguaggio matematico indispensabile per trattare gli enti in uno spazio e le loro trasformazioni. Il modulo di statistica è invece diretto ad introdurre le nozioni fondamentali del calcolo delle probabilità ed alcuni esempi elementari di modelli statistici e di stima dei parametri. | 9 crediti |
| **Laboratorio didattico di fisica** | 1 credito |

### Secondo anno

| Insegnamenti | |
| --- | --- |
| **Analisi matematica 2** Il corso ha l’obiettivo di introdurre lo studente agli argomenti basilari dell'analisi infinitesimale in più variabili: funzioni vettoriali e curve; derivate parziali e derivate direzionali; funzioni implicite; serie di Taylor e approssimazioni; ottimizzazione, metodo dei moltiplicatori di Lagrange; integrazione multipla; campi vettoriali e integrali di linea; superfici e integrali di superficie; gradiente, divergenza, rotore; teoremi di Green, della divergenza e di Stokes. | 9 crediti |
| **Calcolo numerico e programmazione** Il corso ha l’obiettivo di fare conoscere i diversi metodi per l'approssimazione numerica della soluzione di alcune classi di problemi della matematica applicata, utilizzando il calcolatore: risoluzione di sistemi lineari e di equazioni non lineari; approssimazione di funzioni e di dati; integrazione e derivazione numerica; risoluzione di equazioni differenziali ordinarie (problemi ai limiti e ai valori iniziali); risoluzione numerica di equazioni differenziali a derivate parziali di tipo ellittico, parabolico e iperbolico. Al contempo intende chiarire i fondamenti matematici alla base dei diversi metodi numerici e analizzare le proprietà di stabilità, accuratezza e complessità algoritmica, nonché fornire criteri per la scelta dell'algoritmo più adatto per affrontare un problema specifico curandone la relativa implementazione. | 9 crediti |
| **Fisica 2** Il corso ha lo scopo di fornire agli studenti le conoscenze di base sui fenomeni elettromagnetici e la capacità di usare in modo predittivo le leggi che regolano i suddetti fenomeni. L'elettromagnetismo è presentato partendo dalla fenomenologia e con esempi legati agli aspetti di applicazione tecnologica e naturali dei fenomeni. All’allievo sono presentate e spiegate le equazioni di Maxwell e le relative applicazioni. Il corso si propone quindi di fornire solide basi affinché l’allievo possa poi approfondire ed affrontare autonomamente problemi che coinvolgono i fenomeni elettromagnetici. La parte di Laboratorio prevede che lo studente acquisisca pratica con la strumentazione e la raccolta e il trattamento dei dati sperimentali, con particolare riguardo ai concetti di misura e incertezza, nonché con le tecniche di base dell’analisi dei dati. | 6 crediti |
| **Topografia** Il corso intende fornire conoscenze di base e abilità applicative nei settori del rilievo del territorio, della sua rappresentazione e nella analisi ed elaborazione delle misure. Alla fine del corso, gli allievi avranno acquisito le conoscenze e abilità per progettare un rilievo di carattere locale, per la sua corretta esecuzione e per l’inserimento in un sistema di riferimento sia locale sia nazionale o globale, nonché per il corretto utilizzo dei risultati di rilievi eseguiti da altri e dei prodotti cartografici. Le conoscenze riguardanti la analisi e la elaborazione delle misure dovrebbero essere applicabili anche in contesti differenti dal rilievo metrico del territorio. | 8 crediti |
| **Architettura tecnica** Il corso intende approfondire gli aspetti tecnico-costruttivi dell’edificio civile e industriale. La sintesi tra ideazione della forma e procedimento costruttivo per realizzarla viene definita attraverso la enunciazione di principi costruttivi, da porre a base dell’azione progetto, e la lettura in chiave tecnico-costruttiva dell’organismo edilizio visto come insieme di elementi con ruoli specifici in rapporto alla sicurezza, alla classificazione dello spazio, al comfort abitativo. I principi costruttivi sono enunciati in funzione dei diversi materiali e delle loro potenzialità in rapporto alle loro capacità prestazionali. La lettura in chiave tecnico-costruttiva viene svolta prendendo in considerazione esempi di edifici significativi dell’architettura contemporanea, moderna e del passato. | 9 crediti |
| **Fisica tecnica** Il corso ha l’obiettivo di introdurre l’allievo alla conoscenza della termodinamica, in generale, approfondendo in particolare la termodinamica dell’aria umida e dell’atmosfera e quindi fornendo i principi fondamentali del condizionamento ambientale. Inoltre sono trattati i principi della trasmissione del calore, in regime stazionario e variabile, e introdotti i metodi numerici di soluzione. Una parte del corso è dedicata all’acustica applicata, con particolare riferimento alle implicazioni nel settore delle costruzioni civili. | 9 crediti |
| **Meccanica razionale** Il corso ha l’obiettivo di introdurre i temi fondamentali della meccanica razionale, con particolare riguardo al problema della determinazione delle equazioni del moto per i sistemi vincolati più significativi e delle relative condizioni iniziali, nonché della riduzione delle stesse equazioni alla forma normale, allo scopo di assicurare esistenza ed unicità delle soluzioni massimali. Sono inoltre approfonditi alcuni argomenti di statica e dinamica dei sistemi meccanici, con particolare riguardo agli aspetti di maggiore interesse per l'ingegneria civile: statica dei sistemi olonomi con o senza attrito; stabilità dell'equilibrio ordinario; piccole oscillazioni intorno all'equilibrio stabile; elementi di meccanica dei continui classici. | 9 crediti |
| **Infrastrutture viarie** Scopo del corso è quello di illustrare i criteri e i metodi per il progetto e la costruzione delle infrastrutture viarie (fondamentalmente strade e ferrovie). Si illustrerà il proporzionamento dei singoli elementi e la verifica del tracciato nel suo complesso (andamento plano-altimetrico) basandosi sui criteri di sicurezza, funzionalità, sostenibilità ambientale. Si forniranno altresì i primi elementari concetti di Ingegneria del Traffico utili alle verifiche funzionali ed al controllo delle strade. Vengono poi descritti i principali problemi che riguardano i materiali e la costruzione del corpo stradale e ferroviario e delle relative sovrastrutture. Gli allievi familiarizzeranno così con i più recenti indirizzi di approccio allo studio geometrico funzionale e costruttivo delle strade delle ferrovie in conformità con il dettato normativo nazionale in vista di una utilizzazione critica dei principi attualmente utilizzati nella progettazione infrastrutturale viaria. | 6 crediti |

### Terzo anno

| Insegnamenti | |
| --- | --- |
| **Meccanica dei fluidi** L'insegnamento si fonda sulla rappresentazione teorica dei principi fisici di conservazione della massa, della quantità di moto e dell’energia. I fluidi considerati sono prevalentemente newtoniani ed incomprimibili; importanti digressioni sui fluidi non-newtoniani e/o comprimibili consentono di allargare la trattazione ai gas, ai fluidi naturali bifasici ed a fluidi di impiego industriale. Le applicazioni inerenti i flussi a pressione in sistemi idraulici elementari e complessi in condizioni stazionarie e a moto vario. L’idraulica dei moti fluviali e quella dei mezzi porosi costituisce il completamento formativo in vista di corsi specifici nei settori delle opere idrauliche di difesa e di utilizzazione delle risorse idriche. | 12 crediti |
| **Scienza delle costruzioni** Il corso si propone di illustrare i principi fondamentali riguardanti la meccanica dei solidi e delle strutture in regime elastico lineare e la resistenza dei materiali, fornendo le basi concettuali e i metodi per studiare il comportamento delle strutture ed accertarne la sicurezza in presenza di carichi assegnati. L'impostazione data al corso intende conciliare differenti esigenze: sviluppare con rigore le basi teoriche della disciplina; chiarire il significato fisico dei modelli strutturali introdotti, riconoscendone i limiti di applicabilità; fornire agli allievi capacità pratico-operative su tutti gli argomenti trattati. | 12 crediti |
| **Meccanica computazionale delle strutture 1** È un corso introduttivo al metodo degli elementi finiti applicato all'analisi di solidi e strutture in campo elastico lineare. Vengono illustrate le basi teoriche della metodologia, aspetti specifici relativi a particolari contesti strutturali, e aspetti operativi connessi con l'utilizzo di programmi di calcolo agli elementi finiti. Il corso intende fornire all'allievo le conoscenze indispensabili per un utilizzo consapevole di tali programmi che oggi sono largamente diffusi anche su personal computer. Si mostrano applicazioni del metodo degli elementi finiti per la risoluzione di reali problemi di ingegneria strutturale. | 6 crediti |
| **Geotecnica** Il corso è orientato a fornire una introduzione alla conoscenza del comportamento meccanico dei terreni e delle prove geotecniche in laboratorio e in sito, che costituiscono il punto di partenza per la definizione di un progetto geotecnico. Nel corso, si porrà particolare attenzione allo studio degli effetti della pressione dell’acqua interstiziale, alle problematiche indotte dalla evoluzione nel tempo delle pressioni interstiziali, ai concetti di resistenza del terreno in condizioni non drenate e drenate. Saranno privilegiate le competenze più applicative, che saranno utilizzate per l’interpretazione dei risultati di indagini in sito ed in laboratorio, con lo scopo di ottenere una descrizione geotecnica preliminare dei terreni. Le nozioni impartite in questo corso sono propedeutiche ai corsi di approfondimento teorico e ai corsi progettuali della laurea magistrale | 6 crediti |
| **Tecnica delle costruzioni** Il corso si propone di fornire allo studente le conoscenze di base necessarie ad impostare la progettazione strutturale di tipiche costruzioni dell’ingegneria civile. Lo studente sarà quindi introdotto alla conoscenza delle basi teoriche necessarie ad effettuare i dimensionamenti e le principali verifiche dei più comuni elementi strutturali. Lo sviluppo di semplici esempi applicativi, svolti nel rispetto della normativa tecnica nazionale ed europea, consentirà allo studente di rielaborare ed approfondire i contenuti delle lezioni teoriche. | 6 crediti |
| **Insegnamenti a scelta** Lo studente è libero di attingere a tutti gli insegnamenti offerti in ateneo. Qualora gli insegnamenti scelti siano offerti dal corso di laurea in Ingegneria Civile l’approvazione è automatica, negli altri casi il piano di studi presentato è soggetto ad approvazione da parte della Commissione didi Area Didattica che verifica la coerenza con il percorso formativo. | 12 crediti |
| **Altre attività** Crediti da acquisire con attività di tirocinio esterno, con la frequenza a seminari ed iniziative offerte annualmente dal Dipartimento, con attività di laboratorio collegate alla stesura dell'elaborato finale o tramite riconoscimento di altre attività. | 3 crediti |
| **Prova finale** La prova finale per il conferimento della laurea può consistere  * nella presentazione e discussione di un argomento di approfondimento (Prova finale di tipo A) * oppure nella consuntivazione di specifiche attività svolte dal/la laureando/a durante gli anni di frequenza (Prova finale di tipo B). | 3 crediti |









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 

