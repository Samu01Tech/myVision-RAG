

Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/65/studi-internazionali)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)
* [Orienta: tutti i servizi](http://orienta.unitn.it)
* [Scegliere UniTrento](http://www.unitn.it/ateneo/4/perche-scegliere-unitrento)




* **Livello**: Laurea di primo livello
* **Classe** del corso: **L36 Scienze politiche e relazioni internazionali**
* Lingua in cui si tiene il corso: **italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Sociologia e ricerca sociale, via Verdi 26, 38122 Trento.

Nel corso di laurea in Studi internazionali l’oggetto di studio principale sono i **fenomeni sociali e politici** in riferimento alla **dimensione europea e internazionale**. L’approccio è pertanto multidisciplinare e prevede conoscenze in scienza politica, diritto, storia internazionale, sociologia e in economia europea e internazionale.

### Obiettivi formativi

Il corso di laurea in Studi internazionali, collocato nella classe di laurea “Scienze politiche e relazioni internazionali”, mira a fornire le conoscenze di base e gli strumenti teorici e metodologici, oltre che avanzate competenze in ambito linguistico, per comprendere le caratteristiche e le dinamiche dei fenomeni internazionali, basandosi su un approccio multidisciplinare. L’obiettivo principale del corso di laurea è la comprensione della complessità di tematiche come la **globalizzazione**, le **relazioni internazionali**, la **cooperazione allo sviluppo**, l’**internazionalizzazione** e l’**integrazione europea**.

Nel corso del **primo anno**, lo studente deve apprendere i “fondamenti” delle principali scienze sociali e della statistica. Nel campo della sociologia, saranno introdotti i concetti e le nozioni principali necessarie all'analisi della società e del mutamento sociale. Nel campo della storia contemporanea, verranno presentati i principali fatti avvenuti nel corso del Secolo scorso e le loro più importanti interpretazioni. Nel campo della scienza politica verranno introdotti il linguaggio e le concettualizzazioni proprie della disciplina, l'analisi del processo democratico e del processo di democratizzazione. Nel campo dell'economia politica, una particolare attenzione sarà rivolta alle principali teorie macroeconomiche. Nel campo del diritto pubblico verranno introdotti elementi del diritto pubblico europeo, inteso come la combinazione di diritto pubblico statale e sovranazionale. Nel campo della statistica, verranno presentati i primi rudimenti relativi all’analisi dei dati. Una grande importanza viene attribuita anche alla conoscenza della lingua inglese.  

Nel corso del **secondo anno**, vengono presentati gli indispensabili strumenti della ricerca empirica nell’ambito delle scienze sociali e la conoscenza del diritto internazionale. Vengono altresì presentati i sistemi politici in chiave comparata oltre che il loro comportamento e le loro relazioni nell’ambito del sistema internazionale. In ambito storico, viene presentata la vicenda dello Stato moderno, in quanto forma storicamente determinata di organizzazione del potere, nel contesto europeo-occidentale, dalle origini medievali al consolidamento dell'età moderna, per finire con alcuni cenni alla crisi dello Stato contemporaneo. Come al primo anno, un corso di inglese specialistico completa l’offerta in ambito linguistico. Alcuni corsi saranno specifici ai due percorsi formativi. Nell’indirizzo “Politica e organizzazioni internazionali” verranno presentate le organizzazioni internazionali e in quello di “Cooperazione e sviluppo” i temi propri della sociologia dello sviluppo internazionale.  

Infine, nel corso del **terzo anno** vengono offerti corsi che si concentrano su questioni più specifiche. Essi sono dedicati ai principali temi di ricerca nel campo degli studi europei e internazionali, le questioni delle disuguaglianze sociali, i movimenti sociali e la società civile europea, le questioni della cittadinanza e della democrazia europea, la gestione dei conflitti e altro. Un corso di politica economica internazionale completerà la formazione multidisciplinare. Entro la fine del terzo anno, lo studente dovrà dimostrare anche la conoscenza di una seconda lingua straniera. A completamento del percorso formativo, saranno attivati alcuni seminari di credito su tematiche particolarmente rilevanti concernenti la trasformazione dei sistemi economici, politici e sociali contemporanei. Nel tentativo di incrementare la coerenza e unitarietà dell'offerta formativa, lo studente sarà invitato a scegliere i due esami a libera scelta tra alcuni insegnamenti che si considerano particolarmente importanti ai fini della sua formazione.

### Profili professionali

Le prospettive aperte dallo sviluppo dell'Unione europea e dalle trasformazioni del sistema internazionale creano nuovi scenari occupazionali e nuovi sbocchi professionali.  

Nel campo delle professioni di tipo internazionale e comunitario, il corso di laurea in Studi internazionali fornisce il complesso di competenze teoriche e pratiche atte allo svolgimento di **attività presso le istituzioni comunitarie** o presso le **rappresentanze nazionali e regionali di pubbliche amministrazioni** e **gruppi di interesse a Bruxelles** come funzionario amministrativo.  

Un laureato in Studi internazionali potrebbe trovare un impiego anche nel campo della **progettazione e gestione dei progetti comunitari**, soprattutto nell'ambito delle organizzazioni non governative e appartenenti al terzo settore impegnate, per esempio, nel campo della cooperazione allo sviluppo.  

Nel **campo della pubblica amministrazione e della ricerca**, il laureato in Studi internazionali potrebbe svolgere mansioni di personale addetto alle relazioni con l'Unione europea e nel campo degli affari esteri e di tecnico di ricerca operativa.  

Nel campo delle libere professioni, la laurea in Studi internazionali potrebbe costituire la formazione di base per le attività di **giornalista o pubblicista**, soprattutto come corrispondente dall'estero.  

Infine, nel **campo della ricerca in ambito accademico e nelle professioni con altissimo grado di specializzazione**, il corso di laurea in Studi internazionali offre le prime nozioni del complesso di competenze teoriche e pratiche necessarie allo svolgimento della professione di politologo e storico e consigliere in materia di politica estera e internazionale.

### Studi che si possono intraprendere dopo la laurea

Al termine della laurea in Studi internazionali è possibile accedere a corsi di laurea magistrale, master di primo livello e altri percorsi formativi, in base ai requisiti di ammissione previsti.

All'Università di Trento la laurea in Studi internazionali fornisce le conoscenze necessarie per accedere:

* alla laurea magistrale [Sociology and social research](http://offertaformativa.unitn.it/it/lm/sociology-and-social-research/il-corso)
* alla laurea magistrale in [Organizzazione, Società e Tecnologia](https://offertaformativa.unitn.it/it/lm/organizzazione-societa-tecnologia)
* alla laurea magistrale [Global and Local Studies](https://offertaformativa.unitn.it/it/lm/global-and-local-studies)
* alla laurea magistrale in [Data Science](https://offertaformativa.unitn.it/en/lm/data-science)
* alla laurea magistrale [Metodologia, organizzazione e valutazione dei servizi sociali](http://offertaformativa.unitn.it/it/lm/metodologia-organizzazione-e-valutazione-dei-servizi-sociali/il-corso) (con il recupero dei crediti di tirocinio)
* ad alcuni [Master di primo livello](https://www.unitn.it/ateneo/200/master)








Il percorso formativo prevede un **primo anno comune e al secondo anno la scelta tra due percorsi**:

* Politica e organizzazioni internazionali
* Cooperazione e sviluppo.

Le tabelle seguenti forniscono una panoramica indicativa degli insegnamenti normalmente offerti nei 3 anni di corso. Ogni anno accademico l’elenco può subire modifiche: alcuni corsi potrebbero non essere attivi e potrebbero essere attivati corsi non presenti nell’elenco.

L’elenco definitivo degli insegnamenti offerti è pubblicato ogni anno nelle [Guide del Dipartimento di Sociologia e Ricerca Sociale](https://www.sociologia.unitn.it/111/guida-gli-e-le-studenti).

Primo anno
----------

Insegnamenti comuni ai due percorsi
| Insegnamento | ******Crediti (CFU)****** |
| --- | --- |
| Sociologia  Il corso si propone di fornire una conoscenza di base dei principali concetti e del linguaggio della sociologia; la capacità di applicare questi concetti all'analisi di alcune istituzioni centrali per il funzionamento delle società contemporanee; una visione introduttiva ai temi delle più importanti sociologie speciali | 8 |
| Scienza politica  Il corso si propone di introdurre al linguaggio e alle concettualizzazioni della scienza politica, con particolare riferimento alla teoria della democrazia; alla descrizione del processo democratico e all'analisi tipologica e storico-comparativa dei suoi più importanti fattori; al padroneggiamento critico degli strumenti di analisi e delle problematiche delle democrazie contemporanee | 8 |
| Storia moderna e contemporanea  Gli obiettivi formativi che si intende conseguire sono la padronanza, a grandi linee, del quadro diacronico e problematico relativo alla storia moderna e contemporanea e la capacità di analizzare e comprendere processi e fenomeni storici complessi, individuando le loro origini in età moderna e comparando situazioni storiche specifiche | 12 |
| Economia politica  Il fine del corso è quello di raggiungere una conoscenza di base delle teorie micro e macroeconomiche tradizionali | 8 |
| Metodi quantitativi  Il corso si propone di introdurre lo studente all’utilizzo dei principali metodi quantitativi nell’ambito delle Scienze Sociali ed alla valutazione critica dei risultati ottenuti. In particolare, il corso affronta argomenti di base di statistica e matematica in un’ottica applicativa avvalendosi di strumenti informatici | 12 |
| Diritto pubblico europeo  Il corso si propone di fornire agli studenti le nozioni fondamentali del diritto pubblico e le coordinate metodologiche e critiche utili per confrontarsi con l'evoluzione del sistema giuridico comunitario | 6 |
| Competenze linguistiche Inglese B1  Scopo del corso è sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, interagire in una conversazione e produrre un testo utilizzando un linguaggio semplice. | 8 |

Secondo anno - Percorso Politica e organizzazioni internazionali
----------------------------------------------------------------

Insegnamenti obbligatori
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Metodologia e tecniche della ricerca sociale  Il corso si propone i seguenti obiettivi: fornire agli studenti strumenti concettuali di comprensione dei principali problemi epistemologici relativi alle scienze sociali; illustrare i più comuni approcci metodologici, collegandoli ai paradigmi teorici sottostanti; fornire le conoscenze di base sulle principali tecniche di ricerca empirica | 12 |
| Diritto internazionale  Il corso di diritto internazionale mira a fornire una conoscenza delle caratteristiche di fondo dell’ordinamento giuridico internazionale | 6 |
| Storia delle istituzioni politiche  Gli obiettivi formativi che si intendono conseguire consistono nella conoscenza del quadro diacronico e problematico relativo alla formazione dello stato moderno e nell’acquisizione della consapevolezza del ruolo e del funzionamento delle istituzioni politiche, sotto il profilo costituzionale e amministrativo, nella storia moderna e contemporanea | 8 |
| Politica comparata  Il corso analizza le istituzioni, il sistema partitico e i partiti dei sistemi politici, con particolare riferimento alle democrazie consolidate | 8 |
| Sociologia delle relazioni internazionali  Il corso si prefigge il compito di fare acquisire agli studenti la strumentazione teorica e metodologica necessaria per comprendere il comportamento degli stati nelle relazioni internazionali | 8 |
| Relazioni e organizzazioni internazionali  Il corso si prefigge di introdurre gli studenti al fenomeno delle organizzazioni internazionali, on particolare riferimento a Nazione Unite, NATO, istituzioni di Bretton Woods, UNHCR e Corte penale internazionale | 8 |
| Competenze di lingua inglese. Un livello a scelta tra i seguenti:   * Seminar: Specialist English for International Studies(docente CLA presso il Dipartimento di Sociologia e Ricerca Sociale) * Competenze linguistiche Inglese C1 (docente CLA) * Competenze linguistiche Inglese C2(docente CLA)   Per i livelli C1 e C2 saranno riconosciuti, se non ancora sostenuti, i crediti relativi a Inglese B1 previsto al 1° anno, i 6 crediti obbligatori del 2° anno. Per il livello C2 saranno riconosciuti anche 2 crediti per attività a scelta. Informazioni su come raggiungere le competenze linguistiche alla pagina [Lingue straniere](lingue-straniere) | 6 |

Terzo anno - Percorso Politica e organizzazioni internazionali
--------------------------------------------------------------

Insegnamenti obbligatori
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Politica economica internazionale  Lo scopo del corso è fornire agli studenti una conoscenza di base delle tendenze dell'economia mondiale e della teoria della politica economica in un contesto di apertura internazionale, finalizzata ad acquisire una comprensione critica delle fondamentali scelte di politica economica contemporanea | 8 |
| Sistema politico europeo  Il corso mira a introdurre gli studenti all’Unione europea, alle sue istituzioni e alle politiche comunitarie | 8 |
| Crediti a scelta  Completare la formazione con attività formative a scelta che vengano incontro agli interessi degli studenti (insegnamenti o altre attività formative quali seminari di credito, laboratori, eccetera) | 16 |
| Prova finale  Obiettivo della prova finale è dimostrare di aver acquisito una padronanza nelle materie oggetto di studio del corso di laurea tale da consentire allo studente lo svolgimento di un elaborato contenente spunti originali e critici su di un argomento specifico. | 4 |

Un insegnamento a scelta
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Networks and culture  Il corso descrive l'approccio della prospettiva relazionale, rappresentata dalla Social Network Analysis, per lo studio delle relazioni sociali, degli scambi comunicativi e delle produzioni culturali. Scopo dell’insegnamento è che i partecipanti acquisiscano conoscenze riguardo l'approccio teorico e metodologico della SNA e comprendano l'impatto delle differenze culturali sulla struttura e organizzazione della comunicazione. Fra i contenuti del corso, in particolare verra approfondita la relazione fra tecnologia e organizzazione sociale e le diverse forme di connessione fra individui e fra strutture sociali (organizzazioni, istituzioni e gruppi informali) nelle relazioni economiche e di potere.  Il corso è articolato in due parti: la prima ha carattere introduttivo alle basi teoriche e metodologiche della prospettiva relazionale, mentre la seconda parte è finalizzata all’applicazione pratica attraverso la progettazione e la realizzazione di un progetto di gruppo. Al termine dell’insegnamento, lo studente/essa sarà in grado di a) identificare e comprendere i concetti di base dell’insegnamento; b) illustrare un ambito di applicazione delle teorie e dei metodi appresi; c) descrivere ed analizzare empiricamente un problema/fenomeno sociale attraverso la prospettiva relazionale. | 8 |
| Global civil society  Notions of national civil society have a long history in political writings.  Since the 1980s and the end of the Cold War, academic interest in popular involvement in political life and the ideas and development of a global civil society has grown. This module will consider the historical origins of global civil society, diverse and competing contemporary meanings of global civil and ‘uncivil’ society, and what ‘global civil society’ might mean for notions of sovereignty, democracy, citizenship and power. Case studies will allow students to further reflect on these issues and the relationship of global civil society in its different manifestations to global institutions, forces of globalization, states and individuals, and on different structures, tactics and effectiveness. Fundamental questions addressed will include the degree to which ‘global civil society’ should be considered a single entity and what impact it has (and could have) on global (and regional) governance.  Upon completion of this module students are expected to have acquired the following:   1. An understanding of different theoretical approaches to global civil society. 2. Knowledge of a variety of global civil society campaigns. 3. The ability to recognise how global civil society groups exert power at different territorial levels and on different themes through their strategies. 4. An understanding of critical views of global civil society. 5. An overview of how global civil society, and scholarly work about global civil society, has evolved and changed over time.   In addition, students who successfully complete this module should gain the following transferable skills:   * The ability to learn independently and to assume responsibility for the learning process. * Broad academic skills in the areas of critical reading and analysis, library and online research, note-taking and time management. * Confidence in participating respectfully in class discussion and dialogue. * Skills in written academic argument and confidence in crafting academic papers of an appropriate standard of written academic English. * Understanding of issues relating to academic research – evaluating research sources, research methodologies, citation of research materials, management of materials and the avoidance of plagiarism and intellectual dishonesty. | 8 |
| Sociologia economica e del lavoro  Finalità dell’insegnamento è far sì che gli studenti acquisiscano conoscenze e comprendano le connessioni fra istituzioni, corpi intermedi, individui e strutture sociali secondo la prospettiva istituzionalista. Questo approccio teorico e metodologico nelle scienze sociali è comune ad economia e sociologia ed ha avuto importanti sviluppi nel campo della sociologia economica e delle relazioni economiche e di potere. Il corso è articolato in due parti: la prima ha carattere introduttivo alle basi teoriche e metodologiche della prospettiva istituzionalista, declinata allo studio della sociologia economica, dei mercati del lavoro e del lavoro umano, mentre la seconda parte è finalizzata all’applicazione pratico-metodologica attraverso la preparazione di articoli di ricerca empirica teoricamente orientata, così da permettere agli studenti di sperimentare in prima persona il legame indispensabile fra argomentazioni teoriche (spesso macro) e ricerca microbasata (gli attori essendo individui, famiglie o imprese/organizzazioni). | 8 |
| Sociologia dell'organizzazione  Il corso si propone rendere studentesse e studenti consapevoli della pervasività delle organizzazioni nella società contemporanea, di delineare i principali contributi e le prospettive emergenti negli studi organizzativi, di offrire strumenti e chiavi di lettura per interpretare le caratteristiche e i processi delle organizzazioni, intese come costruzioni sociali, e per analizzarle criticamente. | 8 |
| Sociologia politica  Il corso presenta riflessioni teoriche ed empiriche su alcune aree di ricerca centrali nella sociologia politica. Si focalizzerà in particolare sulla partecipazione politica e l’azione collettiva. Per ognuna di queste due aree, il corso discuterà le principali teorie esplicative. Gli studenti acquisiranno le competenze analitiche e teoriche per interpretare tali fenomeni e approfondiranno alcuni casi empirici. | 8 |
| Academic Freedom and Human Rights: European and International Perspectives (J. Monnet module) | 8 |
| Analisi dei conflitti | 8 |

Un insegnamento a scelta
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Major issues in international politics  L'obiettivo di questo corso è quello di esplorare i modi in cui i processi e le strutture globali stanno cambiando la politica interna e internazionale. Le questioni centrali sono concentrati sulla comprensione di come la natura del potere politico e la sua organizzazione sta cambiando e sta rispondendo alle pressioni che vengono da oltre lo stato. Il corso rafforzerà la comprensione delle teorie della politica internazionale, cercando in una serie di questioni globali, come la politica del cibo, commercio ed energia, casi studi che illustrano l'intreccio tra la political interna e internazionale. | 8 |
| Sviluppo e istituzioni: analisi comparata | 8 |
| Politica, Democrazia e Costituzione | 8 |
| The European Union and its neighbours | 8 |

Un insegnamento a scelta
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Relazioni internazionali e diritti umani  Il corso ha come obiettivo quello di spiegare quando, come e perché i diritti umani sono diventati uno standard da rispettare nelle relazioni internazionali, con effetti potenzialmente dirompenti sulla nozione di sovranità. Tuttavia, molto spesso i diritti umani sono manipolati e usati per fini che non sono la dignità umana e la giustizia sociale. A conclusione del corso, lo/la studente sarà in grado di comprendere le dinamiche politiche, di indentificare gli attori cruciali e di far emergere i dilemmi della complessa relazione tra stati, arena internazionale e rispetto dei diritti umani universali. Per questo insegnamento 6 crediti sono considerati tra le attività affini e 2 crediti tra i crediti a scelta. | 8 |
| Storia europea e internazionale  Obiettivo del corso è che gli studenti acquisiscano conoscenza dei principali snodi della storia europea e internazionale dal 1945 a oggi, nonché una metodologia storica per riflettere sui meccanismi di decodificazione dei processi legati alla globalizzazione. Inoltre, il corso fornirà anche alcune conoscenze di base sul tema del rapporto tra politica internazionale e mass media in prospettiva storica. Alla fine del corso gli studenti saranno chiamati a ragionare sui concetti, sugli eventi chiave e sulle trasformazioni della storia europea e internazionale degli ultimi settant'anni, in una prospettiva diacronica e comparata.  Per questo insegnamento 6 crediti sono considerati tra le attività affini e 2 crediti tra i crediti a scelta. | 8 |
| Diritto internazionale dei conflitti armati  Il corso intende presentare agli studenti le norme relative all’uso della forza armata nel diritto internazionale e i problemi connessi alla loro applicazione. Dopo una breve parte introduttiva dedicata alla disciplina del ricorso alla forza nelle relazioni internazionali (jus ad bellum), l’oggetto principale del corso riguarderà le norme che limitano la scelta dei mezzi e dei metodi di combattimento e che proteggono le persone e i beni coinvolti nei conflitti armati internazionali e non-internazionali (diritto umanitario - jus in bello). | 6 |
| Epistemologia delle scienze sociali  Conoscenza dei concetti fondamentali dell'epistemologia delle scienze sociali (parte generale); la differenza fra sistemi fragili, robusti e antifragili (parte monografica).  Per questo insegnamento 6 crediti sono considerati tra le attività affini e 2 crediti tra i crediti a scelta. | 8 |

Competenze linguistiche. Un insegnamento a scelta tra i seguenti
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Francese B1  Scopo di queste attività è sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, interagire in una conversazione e produrre un testo utilizzando un linguaggio semplice. Livello previsto per l’esame: B1 | 4 |
| Spagnolo B1  Scopo di queste attività è sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, interagire in una conversazione e produrre un testo utilizzando un linguaggio semplice. Livello previsto per l’esame: B1 | 4 |
| Tedesco B1  Scopo di queste attività è sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, interagire in una conversazione e produrre un testo utilizzando un linguaggio semplice. Livello previsto per l’esame: B1 | 4 |

Le lingue proposte si possono sostituire con il da riconoscimento di un' altra lingua livello B1, verificata sia in forma scritta che orale.

Secondo anno - Percorso Cooperazione e sviluppo
-----------------------------------------------

Insegnamenti obbligatori
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Metodologia e tecniche della ricerca sociale  Il corso si propone i seguenti obiettivi: fornire agli studenti strumenti concettuali di comprensione dei principali problemi epistemologici relativi alle scienze sociali; illustrare i più comuni approcci metodologici, collegandoli ai paradigmi teorici sottostanti; fornire le conoscenze di base sulle principali tecniche di ricerca empirica | 12 |
| Diritto internazionale  Il corso di diritto internazionale mira a fornire una conoscenza delle caratteristiche di fondo dell’ordinamento giuridico internazionale | 6 |
| Storia delle istituzioni politiche  Gli obiettivi formativi che si intendono conseguire consistono nella conoscenza del quadro diacronico e problematico relativo alla formazione dello stato moderno e nell’acquisizione della consapevolezza del ruolo e del funzionamento delle istituzioni politiche, sotto il profilo costituzionale e amministrativo, nella storia moderna e contemporanea | 8 |
| Politica comparata  Il corso analizza le istituzioni, il sistema partitico e i partiti dei sistemi politici, con particolare riferimento alle democrazie consolidate | 8 |
| Sociologia delle relazioni internazionali  Il corso si prefigge il compito di fare acquisire agli studenti la strumentazione teorica e metodologica necessaria per comprendere il comportamento degli stati nelle relazioni internazionali | 8 |
| Istituzioni della cooperazione internazionale  Il corso si prefigge di introdurre gli studenti al ruolo delle istituzioni internazionali che si occupano di cooperazione e sviluppo | 8 |
| Competenze di lingua inglese. Un livello a scelta tra i seguenti:   * Seminario: Specialist English for International Studies(docente CLA presso il Dipartimento di Sociologia e Ricerca Sociale) * Competenze linguistiche – Inglese C1 (docente CLA) * Competenze linguistiche – Inglese C2 (docente CLA)   Per i livelli C1 e C2 saranno riconosciuti, se non ancora sostenuti, i crediti relativi a Inglese B1 previsto al 1° anno, i 6 crediti obbligatori del 2° anno. Per il livello C2 saranno riconosciuti anche 2 crediti per attività a scelta. Informazioni su come raggiungere le competenze linguistiche alla pagina [Lingue straniere](lingue-straniere) | 6 |

Terzo anno - Percorso Cooperazione e sviluppo
---------------------------------------------

Insegnamenti obbligatori
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Politica economica internazionale  Lo scopo del corso è fornire agli studenti una conoscenza di base delle tendenze dell'economia mondiale e della teoria della politica economica in un contesto di apertura internazionale, finalizzata ad acquisire una comprensione critica delle fondamentali scelte di politica economica contemporanea | 8 |
| Sociologia dello sviluppo internazionale  Il corso mira a introdurre gli studenti alle principali tendenze di lungo periodo dello sviluppo globale | 8 |
| Crediti a scelta  Completare la formazione con attività formative a scelta che vengano incontro agli interessi degli studenti (insegnamenti o altre attività formative quali seminari di credito, laboratori, eccetera) | 16 |
| Prova finale  Obiettivo della prova finale è dimostrare di aver acquisito una padronanza nelle materie oggetto di studio del corso di laurea tale da consentire allo studente lo svolgimento di un elaborato contenente spunti originali e critici su di un argomento specifico. | 4 |

Un insegnamento a scelta
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Movimenti sociali, politica e società  L’ obiettivo del corso è l’introduzione alle teorie principali che permettono di spiegare ed interpretare dinamiche di azione di protesta e i movimenti sociali. In particolare, alla fine del corso, gli studenti/le studentesse:   1. apprenderanno i concetti e i modelli teorici principali per definire, distinguere ed interpretare i movimenti sociali, azioni di singoli gruppi, o altre forme di conflitto sociale orientate a cambiamenti sociali, politici o culturali. 2. Saranno capaci di collegare i casi di studio discussi nella letteratura scientifica con gli elementi teorici trattati durante il corso. 3. Acquisiranno alcune competenze analitiche di base per interpretare fenomeni ed evidenze empiriche della società contemporanea alla luce dei concetti e delle teorie trattate. | 8 |
| Networks and culture  Il corso descrive l'approccio della prospettiva relazionale, rappresentata dalla Social Network Analysis, per lo studio delle relazioni sociali, degli scambi comunicativi e delle produzioni culturali, Scopo dell’insegnamento è che i partecipanti acquisiscano conoscenze riguardo l'approccio teorico e metodologico della SNA e comprendano l'impatto delle differenze culturali sulla struttura e organizzazione della comunicazione. Fra i contenuti del corso, in particolare verra approfondita la relazione fra tecnologia e organizzazione sociale e le diverse forme di connessione fra individui e fra strutture sociali (organizzazioni, istituzioni e gruppi informali) nelle relazioni economiche e di potere.  Il corso è articolato in due parti: la prima ha carattere introduttivo alle basi teoriche e metodologiche della prospettiva relazionale, mentre la seconda parte è finalizzata all’applicazione pratica attraverso la progettazione e la realizzazione di un progetto di gruppo. Al termine dell’insegnamento, lo studente/essa sarà in grado di a) identificare e comprendere i concetti di base dell’insegnamento; b) illustrare un ambito di applicazione delle teorie e dei metodi appresi; c) descrivere ed analizzare empiricamente un problema/fenomeno sociale attraverso la prospettiva relazionale. | 8 |
| Sociologia della religione  Come tutti i fenomeni culturali anche quello religioso tende ad essere non problematizzato ed a riassumersi nelle evidenze che si materializzano sotto i nostri occhi. In realtà i fenomeni religiosi hanno un ruolo fondativo e strutturante, sono cioè fonti di agire normativo che cambia il volto di intere società. Scopo principale del corso è proprio quello di acquisire una simile consapevolezza. | 8 |
| Academic Freedom and Human Rights: European and International Perspectives (J. Monnet module) | 8 |
| Salute, società e culture  Il corso si propone di fornire i principali riferimenti teorici ed investigativi utili a comprendere come la salute e la malattia sono un fenomeno complesso, frutto dell'interazione tra aspetti biologici, psicologici, sociali e culturali. Sulla base di un tale approccio multidimensionale, l'obiettivo del corso è quello di focalizzare i percorsi entro cui le scienze sociali divengono una base irrinunciabile per interventi socio-sanitari di natura integrata, con particolare riferimento a progetti e servizi orientati a persone di cultura non occidentale. | 8 |

Un insegnamento a scelta
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Major issues in development and cooperation  Il corso si propone di introdurre gli studenti ad alcuni dei principali dibattiti riguardo il fondamenti politico-economici che sottendono i processi di cooperazione a livello internazionale per sostenere dinamiche di crescita e sviluppo. | 8 |
| Politiche di sviluppo europee e governance globale  Il corso si propone di fornire una prospettiva europea allo studio della cooperazione allo sviluppo e di introdurre gli studenti alle tecniche di stesura di policy report utili per lavorare nella cooperazione. Affronta questioni centrali nel dibattito sulla cooperazione quali le implicazioni del commercio internazionale per la promozione di sviluppo, diritti umani e democrazia. Il metodo didattico adottato è volto a favorire il collegamento tra il mondo accademico e il mondo del lavoro, rafforzando competenze degli studenti utili per lavorare nella cooperazione e fornendo un’opportunità di dialogo tra studenti e ONG. | 8 |
| Sviluppo e istituzioni: analisi Comparata | 8 |

Un insegnamento a scelta

Se l'insegnamento è da 8 crediti, 6 crediti sono computati tra le attività affini e 2 crediti tra i crediti a scelta


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Studi urbani  Il corso introduce alle principali prospettive teoriche e metodologiche che esaminano le società urbane. Sarà quindi analizzata e posta in questione la classica dicotomia sociologica urbano-rurale, considerando come diversamente si è evoluto lo spazio urbano nel corso del tempo e le dinamiche storiche che ne hanno determinato i mutamenti. Processi di segregazione urbana, immigrazione, sprawl, città globali e gentrification costituiranno gli specifici focus di approfondimento del corso. Alla fine del corso gli studenti dovranno essere in grado di relazionare sugli spazi urbani e rurali, dimostrando di: saper discernere tra diversi fenomeni, approcci teorici e livelli interpretativi; aver acquisito capacità di decostruzione e interpretazione critica e documentata dei fenomeni; formulare enunciati coerenti e analisi, citando dati, ricerche e teorie di riferimento; redigere un testo scritto che, in maniera chiara, esaustiva, documentata e consequenziale, affronti e sviluppi diverse tematiche affrontate durante in corso. | 8 |
| Epistemologia delle scienze sociali  Conoscenza dei concetti fondamentali dell'epistemologia delle scienze sociali (parte generale); la differenza fra sistemi fragili, robusti e antifragili (parte monografica). | 8 |
| Antropologia culturale  Il corso si propone d’introdurre gli studenti agli sviluppi storici e ai cambiamenti teorici della disciplina antropologica, a partire dai primi decenni del XX secolo fino all’epoca contemporanea. Le attività di classe mirano inoltre a generare una conoscenza di base sul rapporto fra teoria antropologica e metodo etnografico, nonché alla presentazione e discussione di ricerche etnografiche contemporanee. | 8 |
| Geografia economica e politica  L'obiettivo principale del corso è di fornire gli strumenti teorici e analitici della geografia economica e politica finalizzati alla comprensione di attuali fenomeni sociali, politici ed economici nella loro forma spaziale. Nello specifico il corso si focalizzerà sulla relazione tra spazio e potere con riferimento ai temi dello sviluppo, della territorialità, delle risorse, dei conflitti e di altri argomenti chiave della disciplina. Al termine del corso gli studenti e le studentesse avranno acquisito la conoscenza delle principali teorie della geografia economica e politica, e la capacità di affrontare autonomamente e in modo critico le principali questioni geo-politiche e geo-economiche dell'attualità. I risultati di apprendimento attesi includono: Conoscenza e comprensione degli aspetti spaziali dei fenomeni contemporanei e delle relazioni esistenti tra la dimensione locale e l'economia globale, così come tra lo spazio e la politica; Familiarità con i metodi e gli strumenti della geografia economica e politica; Abilità di comprendere e utilizzare correttamente i concetti chiave della disciplina (es. scala geografica, regioni, stato nazione, confini e frontiere); Capacità di sviluppare analisi critica e giudizio autonomo. Gli studenti e le studentesse saranno in grado inoltre di mettere in relazione la comprensione critica della relazione tra lo spazio geografico e i fenomeni contemporanei con le sfere delle scienze politiche, della sociologia e delle relazioni internazionali. | 8 |
| Sociologia dell'ambiente  Il corso si propone di raggiungere i seguenti obiettivi formativi:   * Introdurre gli studenti alla conoscenza delle questioni chiave trattate dalla sociologia dell’ambiente * Approfondire le principali teorie sociologiche e gli strumenti concettuali elaborati per analizzare il rapporto tra società e ambiente * Analizzare le principali problematiche ambientali che caratterizzano la contemporaneità, quali i rischi ambientali, i conflitti ambientali, la transizione energetica.   Al completamento di questo corso gli studenti dovranno mostrare:   * Capacità di analisi utilizzando i principali paradigmi teorici sviluppati dalla sociologia dell’ambiente; * La conoscenza delle questioni chiave nel campo della sociologia dell’ambiente * La capacità di discutere criticamente le problematiche ambientali utilizzando la letteratura sociologica rilevante.   Inoltre, la partecipazione attiva degli studenti a questo corso permetterà di:   * sviluppare le capacità di confronto dialettico con gli altri studenti; * sviluppare le competenze analitiche attraverso la presentazione di argomenti teorici ed empirici * migliorare la capacità di ricerca bibliografica attraverso gli strumenti bibliotecari e internet disponibili. | 8 |

Competenze linguistiche. Un insegnamento a scelta tra i seguenti
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Francese B1  Scopo di queste attività è sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, interagire in una conversazione e produrre un testo utilizzando un linguaggio semplice. Livello previsto per l’esame: B1 | 4 |
| Spagnolo B1  Scopo di queste attività è sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, interagire in una conversazione e produrre un testo utilizzando un linguaggio semplice. Livello previsto per l’esame: B1 | 4 |
| Tedesco B1  Scopo di queste attività è sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, interagire in una conversazione e produrre un testo utilizzando un linguaggio semplice. Livello previsto per l’esame: B1 | 4 |

Le lingue proposte si possono sostituire con il riconoscimento di un'altra lingua livello B1, verificata sia in forma scritta che orale









[Iscriversi](/it/l/servizio-sociale/iscriversi "Iscriversi")
------------------------------------------------------------


Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I candidati e le candidate che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.









 






 

