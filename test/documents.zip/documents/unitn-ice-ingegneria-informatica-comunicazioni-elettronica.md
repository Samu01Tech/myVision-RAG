

* **Livello**: Laurea
* **Classe** del corso**:** **L-8**
* Classe delle lauree in **Ingegneria dell’informazione**
* **Lingua in cui si tiene il corso**: Italiano e inglese
* **Durata**: 3 anni
* **Modalità di accesso**: accesso a **numero programmato**, con superamento di una prova di ammissione
* **Sede**: Dipartimento di Ingegneria e Scienza dell'Informazione, via Sommarive 9, 38123 Povo - TRENTO (TN).

Il corso di laurea in Ingegneria Informatica, delle Comunicazioni ed Elettronica (ICE) unisce **tre importanti discipline nella classe Ingegneria dell’Informazione** (L8): Ingegneria Informatica, Ingegneria dell’Informazione e delle Comunicazioni, Ingegneria Elettronica. Il corso condivide un nucleo cross-disciplinare di tematiche di insegnamento ed offre **due percorsi**, uno in italiano ed uno interamente in inglese, entrambi hanno una durata di tre anni e richiedono l'acquisizione di 180 crediti:

* [Cosa si studia - percorso in italiano](cosa-si-studia-percorso-italiano)
* [Cosa si studia - percorso in inglese](cosa-si-studia-percorso-inglese)

Obiettivi formativi
-------------------

Il corso di studio in Ingegneria Informatica, delle Comunicazioni ed Elettronica si propone di formare figure professionali dotate di competenze generali nell'area dell'Ingegneria dell'Informazione e, a seconda dell’orientamento scelto, di competenze specifiche nell'ambito dell’informatica, delle telecomunicazioni e dell’elettronica.

Le aree di apprendimento interessate al raggiungimento degli obiettivi formativi sono:

* matematica e fisica
* economia e organizzazione aziendale
* ingegneria informatica
* tecnologie e sistemi per le telecomunicazioni
* dispositivi e circuiti elettronici.

Ai corsi di base in tali tematiche si aggiungono corsi di specializzazione per l'acquisizione di maggiori competenze metodologiche o professionalizzanti.

Il corso di studi è **fortemente project-based**: si basa sull'uso degli strumenti didattici dei laboratori e promuove attività per la progettazione di dispositivi e di software.

Sbocchi professionali
---------------------

Il corso di studio in Ingegneria Informatica, delle Comunicazioni, ed Elettronica si propone di formare ingegneri con competenze specifiche nei settori dell'Information and Communications Technology (ICT). L'ICT è un motore di crescita economica, come risulta evidente dal fatto che in questo settore sia valore aggiunto che occupazione crescono a ritmi molto superiori rispetto al tasso di crescita dell'industriale globale. La figura professionale formata dal corso è tipicamente l'ingegnere che sia in grado di lavorare in team ed affrontare e risolvere problemi, in base al percorso di specializzazione scelto, nei settori dell'informatica, delle telecomunicazioni e dell’elettronica utilizzando metodi, tecniche e strumenti innovativi.

Questa figura professionale risponde adeguatamente alle esigenze di mercato, che spesso non richiedono una specializzazione relativa ad un singolo settore, ma una comprensione più ampia dei sistemi, delle metodologie e delle tecnologie dell'intera area dell'informazione, oltre alla capacità di cogliere le relazioni fra le varie discipline e di trattare professionalmente problemi interdisciplinari.

Il corso di studio offre un piano formativo coerente con il profilo delle seguenti figure professionali:

* Tecnici laureati di sistemi software
* Tecnici laureati di sistemi di elaborazione delle informazioni
* Tecnici laureati per le telecomunicazioni
* Progettisti di sistemi per l’elaborazione e la rice-trasmissione delle informazioni
* Tecnici laureati elettronici
* Progettisti di architetture e sistemi digitali
* Progettisti di circuiti analogici e di condizionamento del segnale
* Sviluppatori hardware/software di sistemi embedded ed integrati.

Secondo gli sbocchi professionali classificati dall'ISTAT, i laureati in Ingegneria Informatica, delle Comunicazione ed Elettronica possono intraprendere una delle seguenti professioni:

* Ingegneri elettronici – (2.2.1.4.1)
* Ingegneri progettisti di calcolatori e loro periferiche – (2.2.1.4.2)
* Ingegneri in telecomunicazioni – (2.2.1.4.3)
* Tecnici Informatici telematici e delle telecomunicazioni – (3.1.2).

Dopo la laurea ICE è possibile iscriversi all’esame di stato per conseguire l’**Abilitazione Nazionale** e l'iscrizione all'Albo Professionale per l'esercizio delle seguenti professioni:

* Ingegnere dell'Informazione Junior
* Perito Industriale Laureato.

Accesso a ulteriori studi
-------------------------

La laurea in Ingegneria Informatica, delle Comunicazioni ed Elettronica (ICE) fornisce le conoscenze necessarie per **accedere direttamente alle lauree magistrali** offerte dall’Università degli Studi di Trento

* laurea magistrale in [Informatica](https://offertaformativa.unitn.it/node/1383)
* laurea magistrale in [Ingegneria dell’Informazione](https://offertaformativa.unitn.it/en/lm/information-engineering)
* laurea magistrale in [Artificial Intelligence Systems](https://offertaformativa.unitn.it/en/lm/artificial-intelligence-systems)
* laurea magistrale in [Data Science](https://offertaformativa.unitn.it/en/lm/data-science)
* laurea magistrale in [Quantitative and Computational Biology - UniTrento](https://offertaformativa.unitn.it/en/lm/quantitative-and-computational-biology)
* laurea magistrale in [Human Computer Interaction](https://offertaformativa.unitn.it/en/lm/human-computer-interaction)
* laurea magistrale in [Mechatronics Engineering](https://offertaformativa.unitn.it/it/lm/mechatronics-engineering).

In Italia permette inoltre di accedere direttamente alle lauree magistrali in **Ingegneria Informatica** e in **Ingegneria Elettronica**.








Dall'**anno accademico 2022/2023** il corso di laurea offre **un percorso in italiano** e **un percorso in inglese**: entrambi durano 3 anni e prevedono 180 crediti.

Il percorso in italiano prevede:

* una prima sequenza di corsi comuni e di base
* una formazione cross-disciplinare tra le aree di Informatica, Elettronica e delle Comunicazioni, all'interno della quale si scelgono corsi caratterizzanti in ciascuna delle tre aree
* un percorso curriculare specifico a scelta con specializzazione in una delle tre aree: Informatica, Comunicazioni, Elettronica.

Corsi comuni e di base
----------------------

Attività didattiche obbligatorie comuni a tutti i percorsi curriculari, 72 crediti
| Attività didattiche | crediti |
| --- | --- |
| Analisi matematica 1 | 12 |
| Geometria e algebra lineare | 6 |
| Programmazione 1 | 12 |
| Analisi matematica 2 | 6 |
| Fisica | 12 |
| Calcolo delle Probabilità | 6 |
| Programmazione 2 | 6 |
| Organizzazione e Gestione Aziendale | 6 |
| Fisica 2 | 6 |

Formazione cross-disciplinare
-----------------------------

Attività didattiche cross-disciplinari obbligatorie comuni a tutti i percorsi, 36 crediti
| Area didattica | Attività didattiche | crediti |
| --- | --- | --- |
| Informatica | Sistemi di elaborazione (Modulo 1: Introduction to Machine Learning) | 6 |
| Informatica | Sistemi di elaborazione (Modulo 2: Calcolatori) | 6 |
| Comunicazioni | Fondamenti di comunicazioni (Modulo 1: Elaborazione dei segnali) | 6 |
| Comunicazioni | Fondamenti di comunicazioni (Modulo 2: Reti) | 6 |
| Elettronica | Fondamenti di Elettronica Digitale (Modulo 1: Reti logiche) | 6 |
| Elettronica | Fondamenti di Elettronica Digitale (Modulo 2: Circuiti elettronici digitali) | 6 |

Percorsi
--------

Percorso Ingengeria Informatica: 6 crediti di corso obbligatorio di percorso più 36 crediti a scelta tra gli altri corsi
| Tipo attività | Attività didattiche Percorso Informatica | crediti |
| --- | --- | --- |
| Corso obbligatorio di percorso | Databases | 6 |
| Corsi a scelta | Ingegneria del software | 12 |
| Corsi a scelta | Operating Systems | 12 |
| Corsi a scelta | Fundamentals of robotics | 12 |
| Corsi a scelta | Introduction to Computer & Network Security | 6 |
| Corsi a scelta | Embedded Software for the Internet of Things | 6 |
| Corsi a scelta | Programmazione avanzata | 6 |
| Corsi a scelta | Fundamentals of parallel programming | 6 |
| Corsi a scelta | Ingegneria del software | 6 |

Percorso Ingengeria delle Comunicazioni: 6 crediti di corso obbligatorio di percorso più 36 crediti a scelta tra gli altri corsi
| Tipo attività | Attività didattiche Percorso Comunicazioni | crediti |
| --- | --- | --- |
| Corso obbligatorio di percorso | Campi elettromagnetici | 6 |
| Corsi a scelta | Trasmissione di Segnali Digitali | 6 |
| Corsi a scelta | Elaborazione dei segnali 2 | 6 |
| Corsi a scelta | Vision and recognition | 6 |
| Corsi a scelta | Tecnologie Multimediali | 6 |
| Corsi a scelta | Next generation networks | 6 |
| Corsi a scelta | Digital signal coding | 6 |
| Corsi a scelta | Remote Sensing Systems and Analysis | 6 |

Percorso Ingegneria Elettronica: 6 crediti di corso obbligatorio di percorso più 36 crediti a scelta tra gli altri corsi 
| Tipo attività | Attività didattiche Percorso Elettronica | crediti |
| --- | --- | --- |
| Corso obbligatorio di percorso | Analog electronics | 6 |
| Corsi a scelta | Progettazione e prototipazione di sistemi elettronici | 6 |
| Corsi a scelta | Campi elettromagnetici | 6 |
| Corsi a scelta | Advanced logic design | 6 |
| Corsi a scelta | Laboratorio di systems on chip | 6 |
| Corsi a scelta | High-Frequency Circuits for Systems-on-Chip | 6 |
| Corsi a scelta | Introduction to Parallel Computing | 6 |
| Corsi a scelta | Basics of optoelectronics | 6 |
| Corsi a scelta | Strumentazione ed elettronica industriale | 6 |
| Corsi a scelta | Introduction to embedded systems | 6 |

Esami a scelta libera, tirocinio, inglese e prova finale
--------------------------------------------------------

Il corso di laurea si completa per tutti i percorsi con le seguenti attività didattiche
| Attività didattiche | crediti |
| --- | --- |
| Crediti scelti liberamente fra i corsi offerti dall’Università di Trento | 12 |
| Tirocinio | 9 |
| Inglese | 3 |
| Prova finale | 6 |








Dall'**anno accademico 2022/2023** il corso di laurea offre **un percorso in italiano** e **un percorso in inglese**: entrambi durano 3 anni e prevedono 180 crediti.

Il percorso in Inglese prevede, accanto ad una prima sequenza di corsi comuni, una formazione interdisciplinare, integrando percorsi che caratterizzano ciascuna delle tre aree: Informatica, Comunicazioni, Elettronica.

Attività didattiche comuni e di base
------------------------------------

Attività didattiche obbligatorie , 72 crediti
| Attività didattiche | crediti (ECTS) |
| --- | --- |
| Calculus 1 | 12 |
| Geometry and Linear Algebra, in inglese | 6 |
| Computer Programming | 12 |
| Calculus 2 | 6 |
| Physics | 12 |
| Probability | 6 |
| Computer Programming 2 | 6 |
| Business organization and management | 6 |
| Physics 2 | 6 |

Formazione cross-disciplinare
-----------------------------

Attività didattiche cross-disciplinari obbligatorie, 42 crediti
| Aree | Attività didattiche | crediti (ECTS) |
| --- | --- | --- |
| Computer Engineering | Processing systems (Module 1: Introduction to machine learning) | 12 |
| Computer Engineering | Processing systems (Module 2: Computer Architectures) |
| Computer Engineering | Databases | 6 |
| Communications Engineering | Fundamentals of communication (Module 1: Signal processing) | 12 |
| Communications Engineering | Fundamentals of communication (Module 2: Networking) |
| Electronic Engineering | Fundamentals of electronics (Module 1: Logic Networks) | 6 |
| Electronic Engineering | Fundamentals of electronics (Module 2: Analog electronics) | 6 |

Aree
----

Area Informatica: 12 crediti a scelta fra i seguenti
| Attività didattiche | crediti (ECTS) |
| --- | --- |
| Advanced programming | 6 |
| Operating Systems | 12 |
| Fundamentals of robotics | 12 |
| Software engineering | 12 |
| Embedded Software for the Internet of Things | 6 |

Area Ingegneria delle Comuniczioni: 12 crediti a scelta fra i seguenti
| Attività didattiche | crediti (ECTS) |
| --- | --- |
| Next generation networks | 6 |
| Digital signal coding | 6 |
| Vision and recognition | 6 |
| Remote sensing systems and image: analysis | 6 |

Area Ingegneria Elettronica: 12 crediti a scelta fra i seguenti
| Attività didattiche | crediti (ECTS) |
| --- | --- |
| Advanced logical design | 6 |
| High-frequency circuits for systems on chips | 6 |
| Digital electronic circuits | 6 |
| Introduction to parallel computing | 6 |
| Laboratory of systems on chips | 6 |
| Digital electronic circuits | 6 |

Esami a scelta libera, tirocinio, lingua straniera e prova finale
-----------------------------------------------------------------

Il corso di laurea si completa per tutti i percorsi con le seguenti attività didattiche
| Attività didattiche | crediti (ECTS) |
| --- | --- |
| Crediti scelti liberamente fra i corsi offerti dall’Università di Trento | 12 |
| Tirocinio | 9 |
| Lingua inglese livello C1 o Lingua italiana (per i cittadini non di madrelingua italiana) | 3 |
| Esame finale | 6 |








Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).







### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.










 

