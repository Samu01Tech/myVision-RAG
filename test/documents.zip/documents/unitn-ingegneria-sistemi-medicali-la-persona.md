

Il corso di laurea in Ingegneria dei sistemi medicali per la persona è un corso **interateneo** offerto dall’**Università di Trento** con l'**Università di Verona** (sede amministrativa) e l’**Università di Modena - Reggio Emilia**.

* Titolo di Studio: Laurea in Ingegneria dei sistemi medicali per la persona
* Classe di Laurea MIUR: L8 Classe delle lauree in ingegneria dell'informazione
* Durata: 3 anni
* Lingua del corso: Italiano
* Sede del corso: [Università degli Studi di Verona](https://www.corsi.univr.it/?ent=cs&id=1001&menu=home&lang=it)

Obiettivo del corso
-------------------

Il corso di laurea vuole preparare dei professionisti in grado di sviluppare e gestire apparati e servizi innovativi basati su tecnologie informatiche ed ingegneristiche che supportino sia il personale socio-sanitario che i pazienti nella prevenzione e cura delle malattie. A tal riguardo, la conoscenza dei modelli organizzativi sanitari e il rispetto e l'attenzione alla persona saranno centrali.

Cosa si studia
--------------

Le conoscenze di base classiche della **formazione ingegneristica** e **bioingegneristica** con quelle di **robotica**, **Intelligenza Artificiale**, sistemi di **controllo e monitoraggio remoto**, problematiche di **sicurezza** ed **etica**, caratterizzano i due percorsi didattici fruibili.

L'iter formativo include nel terzo anno un **progetto applicativo** che coinvolga diverse discipline specifiche del profilo scelto dallo studente o dalla studentessa, svolto **in collaborazione con le industrie** del settore biomedicale.

**La didattica del corso sarà in modalità mista** (blended) per favorire la partecipazione di studenti e studentesse e l’interazione fra i tre atenei.

Cosa si diventa
---------------

Oltre a garantire la continuazione degli studi in corsi di laurea magistrale in Ingegneria nei settori della Ingegneria elettronica, Informatica, Industriale e Biomedica e tra queste quelle erogate dalle Università di Trento, Verona e Modena Reggio-Emilia, il laureato potrà trovare occupazione in aziende pubbliche e private del settore biomedico, farmaceutico e biotecnologico. Previo superamento dell'esame di stato, il laureato potrà altresì iscriversi all'albo degli ingegneri biomedici e clinici, sezione B.

Piano di studio
---------------

Il piano di studi, in linea con la classe di laurea (L8 Informatica), è strutturato per fornire una solida formazione ingegneristica. Lo studente a partire dal secondo anno dovrà scegliere tra uno dei due curricula disponibili:

* Dispositivi e Robot
* Segnali e Dati

[Insegnamenti previsti nei 3 anni](ingegneria-sistemi-medicali-la-persona/cosa-si-studia)

Accesso e iscrizione
--------------------

Il corso è ad acceso libero.

Per iscriversi è necessario avere

* un diploma di scuola secondaria superiore (o altro titolo di studio estero riconosciuto idoneo)
* un’adeguata preparazione nell’ambito della matematica di base, che sarà verificata tra le [conoscenze iniziali](https://www.corsi.univr.it/?ent=cs&id=1001&menu=Iscriversi&tab=requisiti&lang=it).

[Come iscriversi e costi](https://www.corsi.univr.it/?ent=cs&id=1001&menu=Iscriversi&tab=comeiscriversi&lang=it)

Contatti
--------

[Segreterie studenti dell'Università di Verona](https://www.corsi.univr.it/?ent=cs&id=1001&menu=contatti&lang=it)








Piano di studio
---------------

Il piano di studio, in linea con la classe di laurea (L8 Informatica), è strutturato per fornire una solida formazione ingegneristica. Dal secondo anno studenti e studentesse dovranno scegliere tra uno dei due curricula disponibili:

* [Dispositivi e Robot](#dispositivi-robot)
* [Segnali e Dati](#segnali-dati)

Per il percorso completo si veda il [piano didattico nel sito dell'Università di Verona](https://www.corsi.univr.it/?ent=cs&id=1001&menu=studiare&tab=insegnamenti&lang=it).

Curriculum Dispositivi e Robot
------------------------------


### Primo anno


| Attività formativa | Crediti (CFU) |
| --- | --- |
| Linguaggi e strumenti di programmazione con laboratorio | 12 |
| Anatomia e fisiologia | 12 |
| Algebra lineare e geometria | 9 |
| Analisi matematica 1 | 6 |
| Architetture di computer e introduzione alle reti con laboratorio | 9 |
| Chimica inorganica e organica | 6 |
| Meccanica e termodinamica | 6 |


### Secondo anno


| Attività formativa | Crediti (CFU) |
| --- | --- |
| Analisi 2: applicazioni e metodi matematici | 12 |
| Elettronica analogica e digitale con laboratorio | 12 |
|
| Elementi di meccanica con laboratorio | 9 |
| Elettromagnetismo e ottica | 6 |
| Introduzione all’analisi dei sistemi e dei segnali con laboratorio | 9 |
| Scienza dei Materiali | 6 |


### Terzo anno


| Attività formativa | Crediti (CFU) |
| --- | --- |
| Strumentazione biomedicale | 6 |
| Etica e psicologia | 6 |
| Principi di robotica e applicazioni alla chirurgia | 6 |
| Sviluppo integrato di dispositivi e robot collaborativi per l’industria biomedicale | 6 |
| Sistemi e controlli automatici | 6 |
| A scelta dello studente | 6 |
| Insegnamento in alternativa | 6 |
| Lingua inglese competenza linguistica | 3 |
| Progettazione e sviluppo di tecnologie medicali | 9 |
| Prova finale | 6 |

Curriculum Segnali e Dati
-------------------------


### Primo anno


| Attività formativa | Crediti (CFU) |
| --- | --- |
| Linguaggi e strumenti di programmazione con laboratorio | 12 |
| Anatomia e fsiologia | 12 |
| Algebra lineare e geometria | 9 |
| Analisi matematica 1 | 6 |
| Architetture di computer e introduzione alle reti con laboratorio | 9 |
| Chimica inorganica e organica 6 Meccanica e termodinamica | 6 |


### Secondo Anno


| Attività formativa | Crediti (CFU) |
| --- | --- |
| Analisi 2: applicazioni e metodi matematici | 12 |
| Elettronica analogica e digitale con laboratorio | 12 |
| Elementi di meccanica con laboratorio | 9 |
| Elettromagnetismo e ottica | 6 |
| Introduzione all’analisi dei sistemi e dei segnali con laboratorio | 9 |
| Informatica medica | 6 |


### Terzo Anno


| Attività formativa | Crediti (CFU) |
| --- | --- |
| Strumentazione biomedicale | 6 |
| Etica e psicologia | 6 |
| Acquisizione e analisi di immagini biomediche | 6 |
| Metodi e dispositivi per la telemedicina | 6 |
| Metodi, tecniche di misura e sensori | 6 |
| Insegnamenti a scelta dello studente | 6 |
| Insegnamento in alternativa | 6 |
| Lingua inglese competenza linguistica | 3 |
| Progettazione e sviluppo di tecnologie medicali | 9 |
| Prova finale | 6 |






