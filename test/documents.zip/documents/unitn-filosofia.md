

Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/57/filosofia)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)
* [Orienta: tutti i servizi](http://orienta.unitn.it)
* [Scegliere UniTrento](http://www.unitn.it/ateneo/4/perche-scegliere-unitrento)




* **Livello**: Laurea di primo livello
* **Classe** del corso: **L-5 - Filosofia**
* Lingua in cui si tiene il corso: **italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Lettere e Filosofia, via Tommaso Gar 14, 38122 Trento.

Il corso di laurea in Filosofia è un programma di studio della durata di tre anni che mira a fornire una solida formazione filosofica per preparare gli studenti ai corsi di laurea magistrale in filosofia e ad altri corsi di laurea magistrale affini e, al contempo, per garantire loro gli strumenti concettuali fondamentali e le conoscenze necessarie per accedere, in fasi successive della loro formazione o durante la loro professione, ad ambiti non strettamente filosofici.

In particolare il corso è progettato per formare laureati che siano in possesso delle **conoscenze teoriche** (di contenuti, metodi, strumenti) proprie delle diverse discipline previste, ma anche delle capacità di **applicare** tali conoscenze **a problematiche specifiche** di ordine strettamente filosofico e a questioni più generali proprie della vita e del mondo attuale, che, seppur non strettamente speculative, presentano tuttavia implicazioni filosofiche.

Dopo il conseguimento della laurea in Filosofia, pertanto, lo studente non solo avrà maturato un ampio bagaglio di conoscenze nei diversi settori della filosofia, ma sarà dotato anche di **spirito critico** e di una **mentalità aperta** e sarà capace di leggere la realtà in cui vive e di interagire con essa in maniera dinamica, flessibile e creativa.

Per conseguire tali obiettivi, l’offerta formativa del corso è tale da permettere allo studente di costruire diverse [carriere](http://offertaformativa.unitn.it/it/l/filosofia/studiare-e-frequentare):

* la carriera **Logica e filosofia delle scienze** si propone di esplorare il territorio di confine tra le conoscenze di tipo matematico e quelle di tipo filosofico in particolare e umanistico in generale. Il piano di studio dedica ampio spazio all’indagine delle discipline filosofiche di carattere logico- linguistico;
* la carriera **Etica, politica e scienze delle religioni** si concentra sui grandi nodi della riflessione teoretica, etico-politica e teologica. Si privilegia in questo caso un approccio di tipo critico- ermeneutico a uno più classico di tipo storico. La presenza di insegnamenti di pensiero ebraico e islamico (oltre a quelli dell’area di storia del Cristianesimo) conferisce agli interessi nell’ambito religionistico un respiro ampio e una dimensione comparativa;
* la carriera **Storia della filosofia, scienze storiche e scienze umane** mira ad approfondire la conoscenza del pensiero filosofico nella sua evoluzione storica, dalle sue prime attestazioni nell’antichità al dibattito novecentesco e contemporaneo. Tutti i grandi periodi della storia della filosofia occidentale (filosofia antica, medievale, rinascimentale, moderna, tardo-moderna e contemporanea) sono analizzati nei loro caratteri specifici e attraverso la lettura dei grandi classici del pensiero. Lo studio della storia della filosofia è integrato da altri corsi filosofici di primaria importanza (come Estetica) e da una serie di corsi volti a esaminare temi, metodi e statuto teorico di alcune scienze umane (psicologia, pedagogia, sociologia);
* lo studente può decidere di optare per un piano di studio libero (individualizzato), che deve essere valutato e approvato dal Coordinatore dell'Ambito didattico (ADIF), in coerenza con il Regolamento didattico del corso.

Il percorso formativo si articola in **lezioni**, **seminari**, **esercitazioni**e **lettorati**finalizzati all’acquisizione di conoscenze di base nelle aree sopra definite e delle correlate competenze metodologiche. Le conoscenze di una lingua dell’Unione europea differente dall’italiano, già verificate all’ingresso, saranno consolidate con un corso specifico. Questa offerta formativa è supportata e integrata da una serie di altre attività (tirocini, stage) e da varie iniziative (lectures, seminari, giornate di studio, convegni internazionali) sempre aperte alla partecipazione degli studenti. Il corso di laurea in Filosofia garantisce un [ampio ventaglio di scelte per un'esperienza di studio all'estero](http://offertaformativa.unitn.it/it/l/filosofia/andare-allestero).

### Obiettivi formativi

Il corso di laurea si propone di fornire una **preparazione filosofica completa**, approfondendo gli ambiti tradizionali della ricerca filosofica (teoretico, etico, religioso, politico, estetico, logico ed epistemologico) e lo studio rigoroso della storia del pensiero dall’antichità ai nostri giorni.  

Per raggiungere questo obiettivo, le lezioni saranno dedicate allo studio dei temi fondamentali del **pensiero filosofico** e all’esame dei **testi classici** (dall’antichità al Novecento), letti criticamente in lingua originale e/o in traduzione e analizzati alla luce di tutti i necessari ausili bibliografici e storiografici.  

Ci si prefigge in questo modo non solo di far conoscere agli studenti le fonti della tradizione filosofica occidentale, ma anche di far loro acquisire quegli **strumenti filologici**, **storici** e **concettuali** indispensabili per coglierne ed apprezzarne l’alta dignità umanistica. Una parte dell’insegnamento verterà su aspetti metodologici ed esaminerà le strutture argomentative tipiche dell’**indagine filosofica** sia dal punto di vista storico sia da quello logico. Pur valorizzando la specificità dei concetti e dei metodi della ricerca filosofica, il corso è aperto ad approfondimenti interdisciplinari.  

Accanto ai tradizionali insegnamenti di area filosofica, il corso presenta anche insegnamenti affini di altre aree (pedagogica, psicologica, sociologica, religionistica, scientifico-matematica, linguistica, letteraria e storica).

### Profili professionali

La possibilità di scegliere tra diversi piani degli studi (consigliati o liberi), l’approfondimento della conoscenza di almeno una lingua straniera e la frequenza di stage, tirocini e altre attività formative specifiche permettono agli studenti del corso di laurea in Filosofia di accedere a diversi settori professionali.  

Il corso di laurea triennale in Filosofia fornisce gli strumenti formativi utili a una comprensione e intepretazione della realtà in costante trasformazione sia dal punto di vista culturale che da quello sociale. Le principali funzioni della figura professionale sopradescritta possono essere animazione e promozione interculturale, attività di supporto all'editing e alla programmazione editoriale, supporto alla gestione di risorse umane in Istituzioni pubbliche e aziende private. Le competenze collegate alla funzione sono le capacità di analisi dei bisogni e di interazioni in situazioni complesse, di lettura e organizzazione di testi, di valorizzazione e gestione dei gruppi di lavoro, di comunicazione e di relazioni con il pubblico.  

Gli sbocchi occupazionali previsti sono individuabili nelle associazioni pubbliche e del privato sociale (non-profit), nell'editoria e giornalismo, nelle biblioteche, nelle aziende di promozione turistica e del territorio, nei centri per il dialogo interreligioso e interculturale, nelle imprese private per la selezione e gestione del personale.  

Il corso prepara alla professione di:

* assistenti di archivio e di biblioteca
* tecnici dell'acquisizione delle informazioni
* tecnici delle pubbliche relazioni
* tecnici delle biblioteche
* tecnici del reinserimento e dell'integrazione sociale
* tecnici dei servizi per l'impiego

### Studi che si possono intraprendere dopo la laurea

La laurea triennale in Filosofia fornisce le conoscenze necessarie per accedere:

* alle lauree magistrali della classe di Scienze filosofiche (LM-78) (presso l’Ateneo di Trento è attivata la laurea magistrale in [Filosofia e linguaggi della modernità](http://offertaformativa.unitn.it/it/lm/filosofia-e-linguaggi-della-modernita/il-corso))
* alle lauree magistrali della classe di Relazioni Internazionali (LM-52) (la laurea magistrale in [Studi Europei ed Internazionali](http://offertaformativa.unitn.it/it/lm/studi-europei-e-internazionali) dell’Università di Trento, previo superamento di un test di ingresso)
* alle lauree magistrali della classe di Scienze cognitive (LM-55) (presso l’Università di Trento è attivata la laurea magistrale in [Human-Computer Interaction](http://offertaformativa.unitn.it/it/lm/human-computer-interaction))
* a varie altre lauree magistrali dell’ambito delle scienze umane e sociali (ad es. alle lauree magistrali delle classi di [Scienze storiche](http://offertaformativa.unitn.it/it/lm/scienze-storiche))








Il corso di studi Filosofia propone **3 carriere**:

* Logica e filosofia delle scienze
* Etica, politica e scienze delle religioni
* Storia della filosofia, scienze storiche e scienze umane.

Le carriere tipo sono piani di studio consigliati già approvati. L'elenco completo delle carriere tipo è disponibile alla pagina [Regolamenti e manifesti](regolamenti-e-manifesti).

In alternativa puoi scegliere un piano di studio libero, che deve essere valutato e approvato dal Coordinatore dell'Ambito didattico, in coerenza con il Regolamento didattico del corso.

Di seguito trovi la struttura del corso definita dal **Regolamento didattico**, sulla base del quale vengono costruite le carriere tipo.

Insegnamenti obbligatori
------------------------

| Insegnamento | Crediti (CFU) |
| --- | --- |
| Filosofia morale  Obiettivi del corso sono: a) l'acquisizione di una conoscenza generale della filosofia morale nel suo sviluppo storico; b) la comprensione dei suoi più significativi paradigmi teorici e lo sviluppo di un lessico adeguato; c) la capacità di leggere e interpretare i testi classici della filosofia morale attraverso un lavoro di contestualizzazione storica, di individuazione delle strutture teoriche fondamentali e di discussione critica delle loro implicazioni pratiche | 12 |
| Storia della filosofia antica  Sulla base di alcuni prerequisiti generali di conoscenza, relativi alla storia del pensiero antico, ellenistico e romano, l’insegnamento si propone di condurre gli studenti all’acquisizione delle seguenti competenze e capacità: 1) comprendere e saper collocare nel contesto storico appropriato problematiche filosofiche rilevanti per il pensiero antico; 2) conoscere e saper usare una metodologia appropriata alla lettura e all’interpretazione di testi filosofici antichi. A questo scopo, l’attività didattica si organizzerà ogni anno intorno ad una problematica specifica, scegliendo un testo di riferimento come base per fornire strumenti metodologici adeguati ad una corretta interpretazione | 6 |
| Storia della filosofia dal Tardoantico al Medioevo  Gli obiettivi formativi del corso consistono nella conoscenza della storia del pensiero filosofico nell’età tardo-antica, patristica e medievale nei suoi contenuti principali, nelle sue articolazioni interne e nei suoi nessi con altri saperi (teologia, scienze, mistica, ermetismo), con particolare riguardo ai dibattiti intorno al rapporto tra riflessione razionale e pensiero religioso all’interno delle diverse aree linguistico-culturali. Il corso si propone di fornire le competenze ermeneutiche necessarie per una autonoma lettura e comprensione delle opere dei maggiori autori tarodantichi e medievali (Plotino, Agostino, pseudo-Dionigi-pseudo-Areopagita, Boezio, Scoto Eriugena, Anselmo, Abelardo, Avicenna, Averroè, Maimonide, Alberto Magno, Bonaventura da Bagnoregio, Tommaso d’Aquino, Sigieri di Brabante, Enrico di Gand, Duns Scoto, Guglielmo di Ockham) e gli strumenti interpretativi per un’analisi critica della tradizione storiografica. Lo studente acquisirà infine una chiara consapevolezza dei fondamenti metodologici e della specificità terminologiche e concettuali della disciplina. | 6 |
| Filosofia politica  Obiettivi del corso sono: a) l'acquisizione di una conoscenza generale della filosofia politica nel suo sviluppo storico; b) la comprensione dei suoi più significativi paradigmi teorici e lo sviluppo di un lessico adeguato; c) la capacità di leggere e interpretare i testi classici della filosofia politica attraverso un lavoro di contestualizzazione storica, di individuazione delle strutture teoriche fondamentali e di discussione critica delle loro implicazioni pratiche | 12 |
| Filosofia teoretica  Obiettivo del corso è avviare gli studenti alla comprensione e all'approfondimento di un problema filosofico fondamentale, attraverso l’analisi storico-teoretica dei concetti ad esso afferenti. A tal fine saranno proposti testi di riferimento che hanno creato su tale problema filosofico una tradizione. Il corso prevede anche il lettorato su due classici del pensiero filosofico | 12 |
| Storia della filosofia dal Rinascimento all'Illuminismo - LT  Sulla base della conoscenza generale della storia del pensiero dell’Umanesimo, del Rinascimento e della modernità fino all’Illuminismo, l’insegnamento si propone di fornire la capacità, in primo luogo, di comprendere e collocare nel loro contesto storico le diverse problematiche filosofiche e i diversi autori; in secondo luogo, di leggere e interpretare i testi filosofici e di discutere criticamente le tematiche in essi trattate. In ciascun corso saranno affrontati uno o più dei seguenti autori, tutti comunque affrontati anche attraverso gli strumenti di carattere manualistico: Cusano, Alberti, Valla, Ficino, Pico, Pomponazzi, Erasmo, Machiavelli, Moro, Telesio, Bruno, Campanella, Montaigne, Bacone, Hobbes, Cartesio, Pascal, Spinoza, Malebranche, Leibniz, Vico, Locke, Berkeley, Hume, Voltaire, Diderot, Rousseau, Kant. | 12 |
| Storia della filosofia dall'Idealismo all'Età Contemporanea  Sulla base della conoscenza generale della storia del pensiero del periodo che va dall’idealismo alla contemporaneità, l’insegnamento si propone di fornire la capacità, in primo luogo, di comprendere e collocare nel loro contesto storico le diverse problematiche filosofiche e i diversi autori; in secondo luogo, di leggere e interpretare i testi filosofici e di discutere criticamente le tematiche in essi trattate. Tra gli autori che saranno di volta in volta affrontati nei singoli corsi, verranno privilegiati – in virtù della loro importanza – i seguenti: Fichte, Schelling, Hegel, Schleiermacher, Schopenhauer, Kierkegaard, Feuerbach, Marx, Nietzsche, Simmel, Bergson, Husserl, Weber, Scheler, Cassirer, Jaspers, Heidegger, Wittgenstein, Sartre, Merleau-Ponty, Foucault. | 12 |
| A scelta  Acquisizione di conoscenze finalizzate ad ampliare l'ambito di competenze o ad a approfondire temi specifici | 24 |
| Prova di informatica  Pre-requisito per la prova finale da sostenere con modalità stabilite dall’Ambito Didattico | - |
| Tirocinio o ulteriori attività formative  Gli obiettivi formativi del tirocinio consistono nella capacità di applicare le proprie conoscenze specifiche anche a realtà e contesti non strettamente legati alla didattica tradizionale in aula | 6 |
| Prova finale  Gli obiettivi formativi della prova finale risiedono nell’acquisizione della padronanza delle forme di scrittura proprie dei lavori scientifici, della capacità di utilizzo coerente delle nozioni acquisite nel triennio, delle fonti e del materiale bibliografico, nonché della capacità di trattazione critica dell’oggetto del proprio lavoro | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Prova linguistica - Inglese  Raggiungimento di una conoscenza grammaticale, sintattica e semantica di una lingua straniera dell'ambito dell'Unione Europea corrispondente al livello B1 e tale da permettergli di utilizzare testi in tale lingua appartenenti alle discipline filosofiche e a quelle ad esse affini | 6 |
| Prova linguistica - Francese  Raggiungimento di una conoscenza grammaticale, sintattica e semantica di una lingua straniera dell'ambito dell'Unione Europea corrispondente al livello B1 e tale da permettergli di utilizzare testi in tale lingua appartenenti alle discipline filosofiche e a quelle ad esse affini | 6 |
| Prova linguistica - Tedesco  Raggiungimento di una conoscenza grammaticale, sintattica e semantica di una lingua straniera dell'ambito dell'Unione Europea corrispondente al livello B1 e tale da permettergli di utilizzare testi in tale lingua appartenenti alle discipline filosofiche e a quelle ad esse affini | 6 |
| Prova linguistica - Spagnolo  Raggiungimento di una conoscenza grammaticale, sintattica e semantica di una lingua straniera dell'ambito dell'Unione Europea corrispondente al livello B1 e tale da permettergli di utilizzare testi in tale lingua appartenenti alle discipline filosofiche e a quelle ad esse affini | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Sociologia della scienza  Gli obiettivi formativi che si intendono conseguire sono: a) una panoramica su questo settore della sociologia e sulle sue interazioni con altre aree disciplinari; b) l'applicazione di tale quadro concettuale ai dibattiti contemporanei tra scienza e società | 6 |
| Storia del cristianesimo e delle chiese I  Acquisizione delle conoscenze di base per lo studio della storia del cristianesimo e delle Chiese e introduzione ai fenomeni di lungo periodo che ne hanno caratterizzato la bimillenaria vicenda | 6 |
| Storia del pensiero sociologico  Il corso si ripropone di presentare i principali autori del pensiero sociologico, assieme ad una rassegna delle principali ricerche che hanno segnato la storia della sociologia | 6 |
| Introduzione alla pedagogia  L’insegnamento si propone di far conoscere agli studenti e alle studentesse le principali basi teoriche, procedurali ed empiriche per le competenze pedagogiche, educative e formative utili alla persona, anche nelle prospettive di genere, nei rapporti con la società e con riferimento a bisogni educativi emergenti nel nostro tempo | 6 |
| Pedagogia interculturale  L’insegnamento si propone di aiutare gli studenti e le studentesse in vista dei seguenti obiettivi:  - sapersi orientare nella realtà dell’educazione in contesti multiculturali attraverso la conoscenza delle principali teorie pedagogiche e dei principali approcci metodologici alla formazione interculturale;  - saper individuare la specificità della pedagogia interculturale nell’ambito delle discipline pedagogiche e delle scienze dell'educazione;  - saper riconoscere le dimensioni pedagogiche implicate nell’articolazione monocultura-multicultura-intercultura;  - saper apprezzare i fondamenti e i valori delle relazioni educative in prospettiva interculturale;  Saranno trattati i seguenti argomenti:  - le sfide educative connesse ai fenomeni migratori nella società globale;  - le specifiche qualità delle relazioni tra persone nella prospettiva interculturale;  - educare all’intercultura nelle relazioni familiari, scolastiche, sociali;  - educazione interculturale nella prospettiva dell’educazione alla cittadinanza globale  (secondo le indicazioni provenienti dalle istituzioni nazionali e internazionali);  - pensatori e testimoni per l’intercultura. | 6 |
| Pedagogia della socialità digitale  A partire da una breve introduzione sull’evoluzione dei media e delle tecnologie digitali verificatasi nel corso degli ultimi decenni, il corso approfondirà il significato dell’espressione “educazione digitale”, con particolare riferimento ai contesti di vita della famiglia, della scuola, del lavoro e del tempo libero. Particolare attenzione verrà rivolta all’analisi delle dinamiche relazionali prodotte attraverso i social network, che hanno condotto a definire il paradigma della “società informazionale” o “iperconnessa”. All’interno di questo nuovo paradigma sociale il corso si propone di riflettere, tra gli altri argomenti, sul tema della “post-verità”, sulle nuove e impulsive forme di dialogicità come gli hate speech, sull’importanza crescente assunta dalla cosiddetta web reputation, verificando da un punto di vista pedagogico come tale orizzonte digitalizzato dell’esistenza incida sulla costruzione dell’identità personale, in particolare nei cosiddetti “nativi digitali”, e quali siano gli sviluppi più recenti delle teorie pedagogiche in questo campo | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Filosofia della religione  Il corso si propone di introdurre gli studenti alla specificità della “filosofia della religione”, proponendo lo studio e l’approfondimento di autori significativi e di tematiche in cui trovino insieme espressione la radicalità della domanda filosofica e l’autonomia oltre che la peculiarità della religione. Obiettivo finale del corso è altresì quello di evidenziare l’esistenza di un ambito specifico di ricerca, la “filosofia della religione”, diverso da quello di altri ambiti della filosofia e delle teologie ma al contempo aperto al rapporto con essi | 6 |
| Ermeneutica filosofica  Obiettivo del corso è far acquisire agli studenti la conoscenza degli indirizzi principali nell’attuale teoria filosofica dell’interpretazione, a partire dalla sua fondazione storica con riferimento all’esegesi dei testi religiosi e alla successiva evoluzione come modalità teorica peculiare nella storia del pensiero filosofico | 6 |
| Ontologia  Il corso di ontologia per la laurea triennale parte dalla questione generale di “che cosa c’è?” e il suo compito è quello di elaborare una teoria generale di concetti come identità, dipendenza, essere parte, essere causa, durare nel tempo. Si propone di definire ciò che Husserl chiamava una teoria degli oggetti in quanto tali, o anche una teoria dell’essere in quanto essere, in senso aristotelico. Il corso di ontologia si chiederà qual è la relazione tra l’oggetto e le sue proprietà e porrà le basi per un approccio a ciò che esiste in base alle sue caratteristiche e alle sue leggi | 6 |
| Gnoseologia  Il corso si propone di introdurre gli studenti alle principali tematiche relative al problema del rapporto conoscitivo tra uomo e realtà, da un lato esaminandone le radici biologiche e antropologiche, dall'altro analizzando nella loro autonomia le acquisizioni logico-cognitive del pensiero. Il suo obiettivo è inoltre di permettere agli studenti di muoversi autonomamente tra le più rilevanti declinazioni storiche e metodologiche della riflessione sulla conoscenza | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Storia greca II  Acquisizione delle conoscenze di base relativamente alle principali problematiche metodologiche e storiografiche della disciplina, con particolare riferimento agli aspetti politico-istituzionali e socioculturali, nonché alle rappresentazioni otto-novecentesche della società e della politica greche | 6 |
| Storia romana II  Una solida conoscenza di base dello sviluppo diacronico della storia romana dall'età arcaica al primo principato, oppure dal primo principato all'epoca tardoantica; una buona padronanza dei principali aspetti istituzionali e politici, come pure delle più rilevanti tematiche di ambito sociale, economico e culturale del mondo romano | 6 |
| Pensiero ebraico I - LT  Il corso si prefigge di fornire agli studenti le categorie fondamentali per comprendere il giudaismo da un punto di vista ebraico, ossia di cogliere le origini tra storia e mito, l'evoluzione culturale e le principali interpretazioni del complesso sistema di credenze e di pratiche degli ebrei così come è stato trasmesso dalla stessa tradizione ebraica. Il giudaismo non è solo una religione; è piuttosto una "civiltà", e come tale ammette approcci diversi e plurali. Il corso intende introdurre a questa pluralità e al contempo affinare gli strumenti per una conoscenza diretta dei principi e dei simboli ebraici a partire dalle fonti e dai classici di questa trimillenaria cultura | 6 |
| Linguistica storica  Acquisizione di conoscenze dei metodi della linguistica storica attraverso l'esame dello studio comparativo delle lingue della famiglia indoeuropea e del gruppo romanzo. | 6 |
| Storia medievale II  Acquisizione di conoscenze di base relative ai quadri politici e istituzionali, al lessico specifico, alle tecniche di esegesi delle fonti e alla conoscenza dei principali indirizzi storiografici | 6 |
| Storia moderna II  Il corso introduce allo studio della Storia moderna e intende fornire agli studenti una conoscenza generale dei temi della storia moderna fra XV e XIX secolo. Ha lo scopo di fornire gli strumenti analitici per orientarsi nelle vicende istituzionali, sociali e culturali dell’Europa moderna, cercando di porle in relazione con la storia delle civiltà non europee. | 6 |
| Storia contemporanea II  Il modulo intende fornire agli studenti un’ampia conoscenza dei temi della storia contemporanea (europea ed extraeuropea tra XVIII e XIX secolo) con un taglio diacronico e problematico che metta in luce le radici storiche profonde delle grandi questioni del presente | 6 |
| Storia delle istituzioni politiche  Acquisizione di conoscenze e competenze storico-politico-costituzionali sulle origini delle istituzioni politiche (Parlamento, Governo, magistratura, ecc.) da cui scaturisce la forma di governo dell’età contemporanea | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Pensiero islamico  Il corso si prefigge di ricostruire le linee fondamentali del pensiero teologico, mistico, filosofico e politico dell'Islam, sia in età classica sia in età contemporanea. Il fine è di dimostrare la molteplicità delle voci che si sono affermate nell'Islam per fornire di questa civiltà un'immagine non essenzialista ma plurale, in cui vengano valorizzate tutte le componenti costitutive, anche nella prospettiva di comprenderne l'evoluzione presente e futura | 12 |
| Storia delle religioni  Il corso intende offrire agli studenti conoscenze storiche e linee interpretative per comprendere il fenomeno religioso come esperienza antropologica globale, suggerendo metodi di studio multidisciplinari di natura storico-comparativa ed ermeneutica. I temi trattati prediligeranno le grandi religioni mondiali, con particolare riguardo alle tradizioni monoteistiche del bacino mediterraneo, e si baseranno sull’analisi delle fonti e dei testi sacri a quelle tradizioni, compresi quali documenti storico-letterari di civiltà in continua evoluzione | 12 |
| Estetica generale  Il corso di estetica generale si propone la presentazione delle principali tradizioni filosofiche e delle relative scuole di pensiero interpretative dei fenomeni dell'esteticità e della espressione, con particolare riguardo ai problemi dello sviluppo di nuove teorie e concezioni nel contesto delle ricerche di antropologia filosofica, aesthetics in practice, filosofia della performance, teorie della comunità e del design, teoria degli artefatti | 12 |
| Elementi di fisica moderna e intelligenza artificiale  La prima parte del corso di propone di fornire agli studenti una visione panoramica, rigorosa anche se non formale/tecnica delle maggiori questioni che sono state affrontate dai fisici a partire dalle grandi rivoluzioni del XX secolo. La seconda parte del corso si propone di introdurre gli studenti all’evoluzione storica, ai problemi, ai metodi, ed alle principali implicazioni delle ricerche sull’Intelligenza Artificiale. Entrambe le parti presteranno particolare attenzione alla dimensione concettuale ed epistemologica delle rispettive aree scientifiche. | 12 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Storia della scienza e delle tecniche  Scopo del corso è introdurre gli studenti alla storia della scienza, mostrando quale rilevanza essa abbia avuto nella formazione e nell'identità culturale dell'Europa moderna e contemporanea | 6 |
| Antropologia filosofica  L’insegnamento di Antropologia filosofica intende stimolare negli studenti la riflessione sulla complessità della condizione umana, nella quale interagiscono, integrandosi tra loro, componenti biologiche, culturali e spirituali. Coerentemente con l’antropologia filosofica tedesca del XX secolo, l’insegnamento è inoltre finalizzato a riguadagnare un’immagine unitaria dell’uomo al di là delle scissioni disciplinari (in primo luogo tra filosofia e scienza, ma anche tra scienze diverse); a tal fine funge da filo conduttore l’indagine del rapporto dell’uomo con la sua sfera vitale, un ambito di indagine in cui l’interesse teorico per la specificità dell’essere umano si unisce ad istanze etiche estremamente attuali. L’insegnamento di antropologia filosofica si caratterizza quindi per un’elevata interdisciplinarità, che non ne pregiudica però la piena appartenenza al pensiero filosofico contemporaneo | 6 |
| Filosofia della storia  Il corso si prefigge l’obiettivo di offrire una panoramica complessiva sul significato, la funzione e le prospettive della nozione di filosofia della storia, ovvero di una riflessione filosofica sullo statuto, gli svolgimenti e le finalità della storia umana esaminata nelle sue implicazioni morali, religiose, politiche e sociali. Particolare attenzione viene riservata al metodo della storia dei concetti e alla lettura critica di classici della disciplina, al fine così di perfezionare la conoscenza del lessico specialistico e di affinare la capacità interpretativa necessaria per la comprensione | 6 |
| Medioevo teologico  Il corso di Medioevo teologico mira a enucleare la portata propriamente filosofica del pensiero teologico medievale, in quanto genuino ed originale contributo alla storia della ragione nella sua genesi e nei suoi effetti. Mediante l’approfondimento di autori e di problematiche rilevanti (ad es. predestinazione, teodicea, cristologia, escatologia e soteriologia) la loro contestualizzazione storico-intellettuale, l’analisi diretta dei testi e lo studio della letteratura secondaria si forniranno gli strumenti per una adeguata definizione dei rapporti fra filosofia e teologia nel loro differenziarsi metodologico, ma anche nel necessario intreccio tematico. | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Linguistica generale I  Il corso intende rendere accessibili agli studenti che provengono dalle scuole superiori le basi di una disciplina nuova, che richiede tecniche e prospettive di analisi diverse da quelle abituali. Perciò verranno presentati i termini, le nozioni e i procedimenti fondamentali per un'introduzione alla linguistica contemporanea e ai recenti metodi di analisi del linguaggio (suoni, parole e frasi), in modo da fornire gli strumenti di base necessari per affrontare e comprendere i criteri linguistici per la produzione di materiali scritti e parlati, sia in italiano che in altre lingue | 12 |
| Storia greca I  Acquisizione delle conoscenze di base relative allo sviluppo diacronico della storia greca fino alla conquista romana dei regni ellenistici, nonché ai quadri istituzionali e socio-economici della civiltà greca nel Mediterraneo. Consapevolezza dei profili generali dei fondamenti metodologici, della terminologia disciplinare e della problematica delle fonti storiche per la storia greca | 12 |
| Storia romana I  Il corso (Introduzione alla storia di Roma dall'età arcaica al V secolo d. C.) intende fornire le informazioni e i concetti indispensabili alla conoscenza e alla comprensione dei principali problemi della storia romana dal formarsi del sistema repubblicano alla fase tardoimperiale. Il corso illustrerà le linee di sviluppo della storia romana dall'età protorepubblicana a quella tardoimperiale, con particolare attenzione all'evoluzione politica e istituzionale dello stato romano in rapporto con la sua espansione, nel Lazio, in Italia e in tutto il Mediterraneo, fino all'età della crisi del sistema imperiale unitario | 12 |
| Storia medievale I  Il corso introduce allo studio della Storia Medievale ed è articolato in due parti, la prima delle quali ha carattere propedeutico e si propone di dotare gli studenti di conoscenze di base relative a quadri politici e istituzionali, lessico specifico, tecniche di esegesi delle fonti e conoscenza dei principali indirizzi storiografici. La seconda parte si propone, invece, di approfondire alcuni aspetti centrali della società medievale attraverso la lettura e il commento di fonti scritte e iconografiche o di pagine di storiografia, con l’obiettivo di far acquisire agli studenti gli strumenti critici per comprendere il lessico e gli schemi interpretativi con cui i contemporanei in età medievale lessero il loro tempo | 12 |
| Storia moderna I  Il corso introduce allo studio della Storia moderna ed è articolato in due parti. Nella prima parte intende fornire agli studenti una conoscenza generale dei temi della storia moderna fra XV e XIX secolo. Ha lo scopo, in primo luogo, di fornire gli strumenti analitici per orientarsi nelle vicende istituzionali, sociali e culturali dell’Europa moderna, cercando di porle in relazione con la storia delle civiltà non europee. Nella seconda parte affronta in modo monografico tematiche centrali della storia moderna attraverso la presentazione di fonti di vario tipo e della storiografia, allo scopo di far acquisire allo/la studente gli strumenti critici necessari per comprendere i vari aspetti dell’epoca trattata e le loro rappresentazioni | 12 |
| Storia contemporanea I  Analizzare e comprendere processi storici complessi nel tempo (inserendo l'analisi di tempi storici più brevi in un'ottica di lungo periodo) e nello spazio (raccordando la storia nazionale con quella europea e internazionale), cogliendo la complessità e articolazione degli eventi storici, ma essendo in grado di individuare i nodi causali più significativi | 12 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Agiografia I  Il corso fornisce le nozioni fondamentali relative all’agiografia latina, con particolare riferimento ai suoi aspetti letterari, storici e linguistici; introduce inoltre ai fondamenti della critica testuale nella sua applicazione all’agiografia latina | 6 |
| Elementi di geometria  Il corso si propone di fornire un'introduzione elementare ai concetti e ai metodi della geometria greca classica (Euclide, Archimede, Apollonio, Diofanto) e ai loro sviluppi matematici in età moderna (geometria analitica, calcolo infinitesimale, geometrie non euclidee, teoria dei numeri). | 6 |
| Storia della scienza e delle tecniche II  Attraverso lo studio dei testi relativi a tematiche specifiche della storia della scienza - come , ad esempio, la nozione di tempo, il concetto di razza oppure quello di manipolazione - il corso si propone di mostrare le interrelazioni tra scienza e società nel loro divenire storico | 6 |
| Storia della pedagogia  Gli insegnamenti di area pedagogica mirano a fornire le basi degli studi in ambito educativo, analizzando i concetti fondamentali ed i vari approcci interpretativi, offrendo le conoscenze più importanti relative alle problematiche contemporanee ed ai collegamenti storici, curando il rapporto fra teoria e pratica e tenendo presente la dimensione internazionale accanto a quella locale e nazionale. Si focalizza l'attenzione su temi come: educazione, formazione degli insegnanti, relazionalità, approccio sperimentale, rapporti tra educazione, persona e società, stimolando gli studenti nell'acquisire competenza, capacità critica, metodo di ricerca, al fine di un’impostazione più consapevole e valida dell’opera educativa | 6 |
| Psicologia sociale  Acquisire una conoscenza sufficientemente approfondita e articolata delle strutture e dei processi di costruzione e rappresentazione della realtà sociale, dei concetti chiave che descrivono il funzionamento dei gruppi e i riflessi che i processi di gruppo hanno in termini di dinamiche sociali, nonché di quelli relativi alle relazioni interpersonali e all'influenza sociale | 6 |
| Psicologia dello sviluppo  Comprensione dello sviluppo in chiave processuale ed ecologica. Costruzione di un quadro di riferimenti teorici e metodologici aggiornato, in cui sapersi orientare | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Sociologia della religione  Il corso si ripropone di fornire agli studenti una presentazione dei concetti costitutivi della sociologia delle religioni, assieme ad una presentazione delle linee interpretative del rapporto tra religione e modernità | 6 |
| Logica  Gli obiettivi formativi del corso consistono nell'acquisizione di strumenti logici ed epistemologici tali da permettergli di sapersi orientare in modo consapevole e critico di fronte a problematiche teoriche di ordine specificamente scientifico | 6 |
| Filosofia della scienza  Il corso si propone di offrire un’introduzione alle principali tematiche che definiscono la filosofia della scienza. Le tematiche affrontate includono il problema dell’induzione, la nozione di progresso scientifico, il metodo sperimentale, il tema dell’unità della scienza e le implicazioni etiche della ricerca scientifica | 6 |
| Filosofia del linguaggio  Sulla base del dibattito apertosi nelle science cognitive il corso offre gli elementi di base per la comprensione dei processi percettivi, cognitivi e linguistici coinvolti nella categorizzazione del linguaggio. Il corso presenta le tipologie di categorizzazione tassonomica, di base, prototipica e radiale, mostrando come i concetti nascano dall’adattamento del materiale di stimolo a stampi di forma relativamente semplice o categorie, che colgono elementi strutturali generici degli oggetti di cui facciamo esperienza e che nominiamo nel linguaggio naturale | 6 |
| Pensiero ebraico II - LT  Il corso si prefigge l’approfondimento di tematiche storiche, linguistiche ed etico-teologiche del giudaismo classico come emergono dallo studio multi-disciplinare delle fonti ebraiche (Tanakh, talmudim, midrashim, codici halakhici, testi liturgici e responsa rabbinici) allargando l’orizzonte alle forme moderne del pensiero ebraico (soprattutto poesia, romanzo e trattazione filosofica), ai fini di trasmettere allo/la studente le categorie di pensiero peculiari alla tradizione religiosa ebraica e di permettere un approccio ermeneutico e comparativo maturo alle suddette fonti | 6 |
| Storia del teatro e dello spettacolo II  Acquisire le conoscenze di base per un approccio storico-critico alla disciplina, offrendo gli strumenti metodologici per analizzare i singoli elementi che costituiscono l'evento teatrale nel suo complesso attraverso l'interpretazione dei documenti letterari e iconografici | 6 |
| Sociologia dei processi culturali e comunicativi  Utilizzare gli strumenti della sociologia dei processi culturali e comunicativi per la comprensione degli attuali contesti socio-culturali a livello locale, nazionale e internazionale | 6 |









[Iscriversi](/it/l/beni-culturali/iscriversi "Iscriversi")
----------------------------------------------------------


Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 





 

