

Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/83/filologia-e-critica-letteraria)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)
* [Orientamento individuale](https://orienta.unitn.it/come-scegliere/31/colloqui-informativi-individuali)




* **Livello**: Laurea di primo livello
* **Classe** del corso: **L-10 - Lettere**
* Lingua in cui si tiene il corso: **italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Lettere e filosofia, via Tommaso Gar 14, 38122 Trento.

Il corso intende fornire agli studenti una solida formazione umanistica centrata tanto sugli studi di carattere letterario e linguistico-filologico quanto su quelli di carattere storico, indagati nelle loro correlazioni.

Lo studio dei testi letterari, delle fonti e dei documenti si colloca dunque in un quadro attento alla storia della civiltà dall’età classica a quella contemporanea. L’integrazione dei metodi degli studi classici, italianistici, filologici e storici mette capo a una preparazione culturale ampia, organica e non frammentata.

Alla luce dei propri interessi e delle proprie inclinazioni, gli studenti possono elaborare il loro piano di studi facendo riferimento a tre carriere che affrontano il sapere umanistico con un approccio tradizionale modernamente ripensato: **Lettere classiche**, **Lettere moderne**, **Storia**. Possono però anche optare per un **piano di studio libero** (individualizzato) che dovrà essere valutato e approvato dal Coordinatore dell'Ambito didattico, in coerenza con il Regolamento didattico del corso.

Gli studenti vengono costantemente stimolati alla riflessione critica e alla partecipazione attiva non solo durante le lezioni in aula ma anche attraverso numerose iniziative e attività collaterali: **seminari**, **conferenze**, **congressi**. Inoltre, le convenzioni con università straniere consentono agli studenti di trascorrere**un semestre all’estero** per affinare le loro conoscenze linguistiche e, soprattutto, per fare un’esperienza che si rivela spesso cruciale per la loro vita futura.

### Obiettivi formativi

Il Corso di laurea in Studi storici e filologico - letterari intende raggiungere obiettivi formativi che si caratterizzano nell’ambito letterario classico, moderno e in quello storico.

L’**ambito classico** intende fornire una formazione che garantisca una conoscenza critica della civiltà letteraria dell’antichità e del relativo contesto storico anche in riferimento ai suoi sviluppi tardo antichi e romanzi. Il conseguimento di tale obiettivo implica la capacità di accostarsi direttamente, in modo consapevole, agli strumenti interpretativi e linguistici, ai testi e alle fonti originali.

L’**ambito moderno** intende fornire una formazione sistematica e articolata che garantisca una conoscenza critica della civiltà letteraria italiana nell’intero suo sviluppo storico. Si sottolinea, anche qui, la necessità di accostarsi direttamente, in modo consapevole, ai testi delle varie epoche e tipologie, acquisendo la conoscenza dei relativi strumenti teorici, ermeneutici e linguistici.

L’**ambito storico** intende fornire una formazione sistematica e articolata che garantisca una conoscenza critica della storia della civiltà nell’intero suo sviluppo, con particolare attenzione per il contesto europeo. Il conseguimento di tale obiettivo implica la capacità di accostarsi direttamente, in modo consapevole, ai testi e ai documenti delle varie epoche e tipologie, acquisendo la conoscenza dei relativi strumenti teorici, ermeneutici e linguistici.

### Profili professionali

Grazie alle competenze culturali, comunicative e relazionali, nonché alle capacità critiche e interpretative che promuove, il corso di laurea in Studi storici e filologico - letterari offre idonea base per l’accesso al lavoro o a specifici percorsi professionalizzanti negli ambiti dell’amministrazione, della gestione delle risorse umane, della comunicazione e della divulgazione culturali, anche nei settori editoriale, museale e bibliotecario.

### Studi che si possono intraprendere dopo la laurea

La laurea triennale in Studi storici e filologico-letterari fornisce le conoscenze necessarie per accedere alle lauree magistrali.  

Quelle attivate presso l'Ateneo di Trento sono le seguenti:

* laurea magistrale interateneo Trento-Verona in [Scienze storiche](http://offertaformativa.unitn.it/it/lm/scienze-storiche#overlay-context=it/l/mediazione-linguistica-turismo-e-culture)
* laurea magistrale in [Filologia e critica letteraria](http://offertaformativa.unitn.it/it/lm/filologia-e-critica-letteraria#overlay-context=it/lm/scienze-storiche)
* laurea magistrale in [Quaternario, preistoria e protostoria](http://offertaformativa.unitn.it/it/lm/quaternario-preistoria-e-archeologia#overlay-context=it/l/beni-culturali)








Il corso di studi Studi storici e filologico-letterari propone **3 carriere**:

* **Lettere moderne**
* **Lettere classiche**
* **Storia**

Le carriere tipo sono piani di studio consigliati già approvati. L'elenco completo delle carriere tipo è disponibile alla pagina [Regolamenti e manifesti](regolamenti-e-manifesti).  

In alternativa puoi scegliere un **piano di studio libero**, che deve essere valutato e approvato dal Coordinatore dell'Ambito didattico, in coerenza con il Regolamento didattico del corso.

Di seguito trovi la struttura del corso.

Insegnamenti obbligatori
------------------------

| Insegnamento | Crediti (CFU) |
| --- | --- |
| Letteratura italiana I  Acquisizione dei fondamentali strumenti bibliografici di accesso alla disciplina. Acquisizione di adeguate nozioni metriche, filologiche e critiche di approccio al testo letterario. Conoscenza delle linee fondamentali della tradizione letteraria italiana dalle Origini al Risorgimento. Capacità di analisi e interpretazione di testi fondamentali tra Due e primo Cinquecento | 12 |
| Storia romana I  Una solida conoscenza di base dello sviluppo diacronico della storia romana dall'età arcaica all'epoca tardoantica; una buona padronanza dei principali aspetti istituzionali e politici, come pure delle più rilevanti tematiche di ambito sociale, economico e culturale del mondo romano | 12 |
| Letteratura latina I  Conoscenza della storia della letteratura latina dalle origini al secolo V compreso, con particolare riguardo ai generi letterari, agli autori e ai testi più significativi analizzati nei loro aspetti linguistici, stilistici, metrici e storicoculturali. Conoscenza delle principali metodologie critiche e dei principali strumenti bibliografici per lo studio della letteratura latina | 12 |
| A scelta libera | 12 |
| Prova linguistica – Inglese, Francese, Spagnolo, Tedesco  Acquisizione del livello B1 tramite l’offerta del CLA (Centro Linguistico di Ateneo) o certificazioni sostitutive riconosciute dal CLA | 5 |
| Prova di informatica  Pre-requisito per la prova finale le informazioni sono disponibili sul sito [www.testcenter.unitn.it/ecdl/lettere-e-filosofia](http://www.testcenter.unitn.it/ecdl/lettere-e-filosofia) e art. 8 del Regolamento didattico del corso di studio | - |
| Italiano scritto  Scopo di questa didattica è l’educazione linguistica alla variabilità dell'italiano in diversi contesti di scrittura, esperiti con esercizi di comprensione e di riscrittura finalizzati all'individuazione di specifiche strategie comunicative e convenzioni editoriali | 1 |
| Prova finale  Acquisizione, dimostrando una buona abilità di espressione scritta, della capacità di impiegare gli strumenti bibliografici e di ricerca fondamentali nel trattare un argomento circoscritto, pertinente alla disciplina, anche senza particolari acquisizioni originali | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 o 2 esami (totale 12 CFU) a scelta tra | Filologia romanza I  Il corso introduce allo studio delle lingue e delle letterature del medioevo romanzo e all'analisi filologico-linguistica di testi di particolare rilevanza storico-culturale | 6 |
| Filologia romanza  Il corso introduce allo studio delle lingue e delle letterature del medioevo romanzo e all'analisi filologico-linguistica di testi di particolare rilevanza storico-culturale | 12 |
| Linguistica italiana  Il corso introduce allo studio delle strutture linguistiche dell’italiano e dei dialetti italiani, antichi e moderni, secondo una prospettiva storica; intende inoltre fornire gli strumenti essenziali per l’analisi linguistico-filologica di testi letterari e non letterari di particolare importanza | 6 |
| Storia della lingua italiana I – LT  Acquisizione di strumenti di analisi linguistica applicati a testi scritti e parlati, comuni e d'autore, antichi e moderni, all'interno di prospettive geografiche, sociali, stilistiche, e di una periodizzazione che dia conto del processo di formazione della lingua italiana | 6 |
| Linguistica generale - LT  Il corso intende rendere accessibili agli studenti che provengono dalle scuole superiori le basi di una disciplina nuova, che richiede tecniche e prospettive di analisi diverse da quelle abituali nello studio letterario e storico. Perciò verranno presentati i termini, le nozioni e i procedimenti fondamentali per un'introduzione alla linguistica contemporanea e ai recenti metodi di analisi del linguaggio (suoni, parole e frasi), in modo da fornire gli strumenti necessari per affrontare materiali scritti e parlati, sia in italiano che in altre lingue | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 o 3 esami (totale 24 CFU) a scelta tra | Storia greca I (esame da 12 CFU) - prima parte  Acquisizione delle conoscenze di base relative allo sviluppo diacronico della storia greca fino alla conquista romana dei regni ellenistici, nonché ai quadri istituzionali e socio-economici della civiltà greca nel Mediterraneo. Consapevolezza dei profili generali dei fondamenti metodologici, della terminologia disciplinare e della problematica delle fonti storiche per la storia greca | 6 |
| Storia della filosofia dal Rinascimento all'Illuminismo  Gli obiettivi formativi del corso consistono nell'acquisizione della conoscenza delle linee di fondo e dei principali contenuti della storia del pensiero filosofico tra la fine dell'età medievale e l'inizio dell'età moderna, con particolare riferimento al rapporto tra Umanesimo e Rinascimento da un lato e tra Rinascimento e Riforma dall'altro. Un'attenzione specifica viene riservata alla lettura e all'analisi critica dei testi così come alla discussione della tradizione storiografica | 6 |
| Storia della filosofia antica  Sulla base di alcuni prerequisiti generali di conoscenza, relativi alla storia del pensiero antico, ellenistico e romano, l’insegnamento si propone di condurre gli studenti all’acquisizione delle seguenti competenze e capacità: 1) comprendere e saper collocare nel contesto storico appropriato problematiche filosofiche rilevanti per il pensiero antico; 2) conoscere e saper usare una metodologia appropriata alla lettura e all’interpretazione di testi filosofici antichi. A questo scopo, l’attività didattica si organizzerà ogni anno intorno ad una problematica specifica, scegliendo un testo di riferimento come base per fornire strumenti metodologici adeguati ad una corretta interpretazione | 6 |
| Geostoria  Sviluppare un approccio critico e analitico ai meccanismi spaziali, alle relazioni tra le società e il loro ambiente e ai processi geostorici di organizzazione e gestione dello spazio. | 12 |
| Geografia - LT  Capacità di comprendere i meccanismi spaziali, le relazioni tra le società e il loro ambiente, i processi di divisione, organizzazione e sistemazione dello spazio | 6 |
| Storia di una regione in età moderna  Acquisizione della conoscenza della storia della realtà regionale tra età moderna e contemporanea, comprese le informazioni necessarie per l'individuazione e lo studio delle sue fonti specifiche, con particolare attenzione per i collegamenti stabilitisi nel tempo con le altre regioni di area sia italiana sia tedesca | 6 |
| Storia d'Europa nell'Ottocento  Acquisizione di conoscenze della storia europea ottocentesca; particolare attenzione sarà rivolta alle politiche di espansione imperiali, cercando di porre in luce i legami di reciprocità e di scontro che si crearono fra le madrepatrie europee e le loro conquiste coloniali | 6 |
| Storia della scienza e delle tecniche - LT  Acquisizione di conoscenze di base relative agli sviluppi storici delle scienze dal Cinquecento al Novecento e alla loro incidenza sulla cultura e la società | 6 |
| Storia del cristianesimo e delle chiese I  Acquisizione delle conoscenze di base per lo studio della storia del cristianesimo e delle Chiese e introduzione ai fenomeni di lungo periodo che ne hanno caratterizzato la bimillenaria vicenda | 6 |
| Storia del cristianesimo e delle chiese  Acquisizione delle conoscenze di base per lo studio della storia del cristianesimo e delle Chiese e introduzione ai fenomeni di lungo periodo che ne hanno caratterizzato la bimillenaria vicenda | 12 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Letteratura italiana II  Conoscenza dei principali codici letterari (stilistici, retorici, metrici) e della loro dimensione storica. Capacità di analisi e interpretazione di testi fondamentali della tradizione letteraria italiana dell'età moderna | 6 |
| Letteratura italiana contemporanea I - LT  Acquisizione di una solida conoscenza delle dinamiche storico-culturali della letteratura italiana contemporanea e degli strumenti per la comprensione di un testo letterario nei suoi aspetti specifici di forma, stile e contenuto | 6 |
| Filologia italiana II  Acquisizione delle nozioni di base dell'attività filologica necessarie per lo studio delle modalità di trasmissione dei testi letterari in volgare e per la conoscenza delle metodologie finalizzate all'allestimento di un'edizione critica | 6 |
| Filologia italiana I (esame da 12 CFU) - prima parte  Acquisizione delle nozioni di base dell'attività filologica necessarie per lo studio delle modalità di trasmissione dei testi letterari in volgare e per la conoscenza delle metodologie finalizzate all'allestimento di un'edizione critica. Acquisizione delle competenze necessarie ad approfondire un caso significativo di filologia d'autore o a ricostruire la tradizione di un testo o ad affrontare questioni metodologiche dell'attività filologica | 6 |
| Letterature comparate I (esame da 12 CFU) - prima parte  Gli obiettivi formativi della disciplina sono quelli di fornire una conoscenza adeguata del fenomeno letterario dal punto di vista sovranazionale, offrendo al contempo una panoramica dei diversi approcci metodologici sviluppati dalla critica letteraria nel corso del XX secolo | 6 |
| Letterature comparate II  Gli obiettivi formativi della disciplina sono quelli di fornire una conoscenza adeguata del fenomeno letterario dal punto di vista sovranazionale, offrendo al contempo una panoramica dei diversi approcci metodologici sviluppati dalla critica letteraria nel corso del XX secolo | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 o 3 esami (totale 18 CFU) a scelta tra | Letteratura greca I  Acquisizione di conoscenze disciplinari di storia della letteratura greca e di capacità di lettura e di analisi di testi latini sul piano linguistico, stilistico, metrico, letterario e storico-culturale | 12 |
| Filologia latina  Acquisizione delle nozioni disciplinari di base della materia, a partire dalla storia del libro nell'antichità e dalla storia della trasmissione dei classici dal mondo antico all'età della stampa, e delle conoscenze metodologiche di base relative all'allestimento e alla fruizione di un'edizione critica | 6 |
| Letteratura latina medievale I LT  Acquisire ampie competenze nell'ambito della letteratura latina medievale dal VI al XIV secolo, con particolare riguardo ai principali generi letterari, agli autori e ai testi più significativi; acquisire competenze nel campo della lingua e della filologia mediolatina | 6 |
| Agiografia I  Acquisizione delle nozioni fondamentali relative all'agiografia latina, con particolare riferimento ai suoi aspetti letterari, storici e linguistici; acquisizione dei fondamenti della critica testuale nella sua applicazione all'agiografia latina | 6 |
| Linguistica italiana I  Il corso introduce allo studio delle strutture linguistiche dell’italiano e dei dialetti italiani, antichi e moderni, secondo una prospettiva storica; intende inoltre fornire gli strumenti essenziali per l’analisi linguistico-filologica di testi letterari e non letterari di particolare importanza | 12 |
| Storia della lingua italiana  Acquisizione di strumenti di analisi linguistica applicati a testi scritti e parlati, comuni e d'autore, antichi e moderni, all'interno di prospettive geografiche, sociali, stilistiche, e di una periodizzazione che dia conto del processo di formazione della lingua italiana | 12 |
| Elementi di archivistica  Acquisire conoscenze in merito ai principi e problemi generali dell'archivistica, disciplina volta allo studio delle modalità di produzione, conservazione e inventariazione di complessi documentari di età medievale, moderna e contemporanea | 6 |
| Bibliografia e biblioteconomia  Acquisizione delle competenze di base volte al reperimento, alla valutazione, all'uso e alla citazione delle risorse documentarie; analisi dei principi e delle modalità della descrizione catalografica e del sistema bibliotecario come gestione integrata dei vari servizi di cui si compone (consultazione, informazione, orientamento) | 6 |
| Metodologia della ricerca storica I  Acquisizione della conoscenza della storia come disciplina e dei principali strumenti tecnici e concettuali della ricerca storica. Conoscenza dei lineamenti fondamentali dei principali orientamenti storiografici e delle loro metodologie, come anche delle più importanti tipologie di fonti | 6 |
| Archivistica I  Acquisire conoscenze in merito ai principi e problemi generali dell'archivistica, disciplina volta allo studio delle modalità di produzione, conservazione e inventariazione di complessi documentari di età medievale, moderna e contemporanea; analizzare le forme e i contenuti della documentazione archivistica in relazione a un singolo archivio oggetto di studio monografico, esaminandone funzioni e struttura; l’attività didattica verrà in parte svolta in archivio allo scopo di acquisire familiarità con la documentazione, in funzione dell’analisi formale, delle metodologie di ordinamento e della critica delle fonti | 12 |
| Paleografia II  Acquisizione di una conoscenza della metodologia e dell'analisi paleografica e delle basilari nozioni per l'approccio e l’esegesi/decodifica della scrittura latina e del suo materiale concretizzarsi | 6 |
| Paleografia I  Acquisizione di una conoscenza della metodologia e dell'analisi paleografica e delle basilari nozioni per l'approccio e l’esegesi/decodifica della scrittura latina e del suo materiale concretizzarsi | 12 |
| Elementi di archivistica II  Analizzare le forme e i contenuti della documentazione archivistica in relazione a un singolo archivio oggetto di studio monografico, esaminandone funzioni e struttura; l’attività didattica verrà in parte svolta in archivio allo scopo di acquisire familiarità con la documentazione, in funzione dell’analisi formale, delle metodologie di ordinamento e della critica delle fonti. | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 o 3 esami (totale 24 CFU) a scelta tra | Storia greca I - seconda parte  Acquisizione delle conoscenze di base relative allo sviluppo diacronico della storia greca fino alla conquista romana dei regni ellenistici, nonché ai quadri istituzionali e socio-economici della civiltà greca nel Mediterraneo. Consapevolezza dei profili generali dei fondamenti metodologici, della terminologia disciplinare e della problematica delle fonti storiche per la storia greca | 6 |
| Archeologia e storia dell'arte greca e romana  Acquisire le conoscenze necessarie per l'analisi e la comprensione di temi e problemi inerenti all'archeologia ed alla storia dell'arte classica | 12 |
| Archeologia e storia dell'arte greca  Acquisire le conoscenze necessarie per l'analisi e la comprensione di temi e problemi inerenti all'archeologia ed alla storia dell'arte greca | 6 |
| Topografia antica  Il corso di Topografia antica punta ad offrire una corretta metodologia di studio, anche attraverso l'interpretazione delle fonti antiche, delle problematiche dell'organizzazione e gestione dello spazio nell'antichità. Lo/la studente sarà condotto a maturare le competenze necessarie a decodificare nel paesaggio moderno i segni di quello antico, sia sotto il profilo territoriale che quello umano | 6 |
| Storia dell'arte moderna IV  Acquisire la conoscenza e la comprensione dell'opera d'arte nel suo contesto storico-geografico, economico-politico, socio-culturale e agevolare la lettura del testo visivo attraverso l'analisi iconografica, iconologica e stilistica delle opere esaminate | 6 |
| Storia dell'arte contemporanea III  Acquisire i fondamentali strumenti critici e storici della disciplina; capacità di analisi delle principali correnti artistiche e di lettura delle opere degli artisti più significativi della storia dell'arte del XIX e XX secolo | 6 |
| Storia del teatro e dello spettacolo II  Acquisire le conoscenze di base per un approccio storico-critico alla disciplina, offrendo gli strumenti metodologici per analizzare i singoli elementi che costituiscono l'evento teatrale nel suo complesso attraverso l'interpretazione dei documenti letterari e iconografici | 6 |
| Storia medievale II  Acquisizione di conoscenze di base relative ai quadri politici e istituzionali, al lessico specifico, alle tecniche di esegesi delle fonti e alla conoscenza dei principali indirizzi storiografici | 6 |
| Storia medievale I  Acquisizione di conoscenze di base relative ai quadri politici e istituzionali, al lessico specifico, alle tecniche di esegesi delle fonti e alla conoscenza dei principali indirizzi storiografici. Conoscenza di alcuni aspetti generali, di lungo periodo, della società medievale, con l’obiettivo di far acquisire agli studenti gli strumenti critici per comprendere gli schemi interpretativi con cui gli uomini del medioevo lessero il loro tempo | 12 |
| Storia moderna I  Acquisizione di una conoscenza generale dei temi della storia moderna fra XV e XIX secolo, nonché degli strumenti analitici necessari per orientarsi nelle vicende istituzionali, sociali e culturali dell'Europa moderna, per comprendere fonti di vario tipo e rapportarsi criticamente alla storiografia. Acquisizione della conoscenza monografica di una tematica centrale della storia moderna, attraverso l’esame di fonti di vario tipo e della storiografia, per comprenderne criticamente i vari aspetti e collegarli alla mentalità del tempo | 12 |
| Storia moderna II  Acquisizione di una conoscenza generale dei temi della storia moderna fra XV e XIX secolo, nonché degli strumenti analitici necessari per orientarsi nelle vicende istituzionali, sociali e culturali dell'Europa moderna, per comprendere fonti di vario tipo e rapportarsi criticamente alla storiografia | 6 |
| Storia contemporanea IV  Acquisizione di un'ampia conoscenza dei temi della storia contemporanea (europea ed extraeuropea tra XVIII e XX secolo) con un taglio diacronico e problematico che evidenzi le radici storiche profonde delle grandi questioni del presente. | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 3 o 4 esami (totale 30) a scelta tra | Letteratura greca II  Consolidamento delle conoscenze dei lineamenti della storia letteraria greca. Acquisizione degli strumenti ermeneutici di base attraverso l'analisi di testi letterari rappresentativi della cultura greca | 6 |
| Filologia greca  Il corso intende introdurre gli studenti ai principi della critica testuale, alle sue finalità storiche e letterarie; le testimonianze della tradizione diretta e indiretta saranno accostate nell'ambito di una più completa esegesi dei testi | 6 |
| Storia del teatro latino  Conoscenza dello sviluppo della storia del teatro latino dall'età arcaica a quella tardoantica attraverso la lettura dei suoi principali testi nei loro aspetti sia critico-letterari sia scenici, con riferimento anche al Fortleben medievale, moderno e contemporaneo | 6 |
| Letteratura latina medievale  Acquisire ampie competenze nell'ambito della letteratura latina medievale dal VI al XIV secolo, con particolare riguardo ai principali generi letterari, agli autori e ai testi più significativi; acquisire competenze nel campo della lingua e della filologia mediolatina | 12 |
| Agiografia  Acquisizione delle nozioni fondamentali relative all'agiografia latina, con particolare riferimento ai suoi aspetti letterari, storici e linguistici; acquisizione dei fondamenti della critica testuale nella sua applicazione all'agiografia latina | 12 |
| Letteratura italiana contemporanea  Acquisizione di una solida conoscenza delle dinamiche storico-culturali della letteratura italiana contemporanea e degli strumenti per la comprensione di un testo letterario nei suoi aspetti specifici di forma, stile e contenuto | 12 |
| Filologia italiana I (esame da 12 CFU) - seconda parte  Acquisizione delle nozioni di base dell'attività filologica necessarie per lo studio delle modalità di trasmissione dei testi letterari in volgare e per la conoscenza delle metodologie finalizzate all'allestimento di un'edizione critica. Acquisizione delle competenze necessarie ad approfondire un caso significativo di filologia d'autore o a ricostruire la tradizione di un testo o ad affrontare questioni metodologiche dell'attività filologica | 6 |
| Letterature comparate I (esame da 12 CFU) - seconda parte  Gli obiettivi formativi della disciplina sono quelli di fornire una conoscenza adeguata del fenomeno letterario dal punto di vista sovranazionale, offrendo al contempo una panoramica dei diversi approcci metodologici sviluppati dalla critica letteraria nel corso del XX secolo | 6 |
| Glottologia  Il corso intende fornire le informazioni fondamentali sulle lingue e sui gruppi linguistici che costituiscono la famiglia indoeuropea e sulle caratteristiche della lingua originaria ricostruita sulla base dalla loro comparazione. Ci si prefigge inoltre di introdurre gli studenti alla conoscenza della storia e dei metodi della linguistica storica | 6 |
| Linguistica generale I  Il corso intende rendere accessibili agli studenti che provengono dalle scuole superiori le basi di una disciplina nuova, che richiede tecniche e prospettive di analisi diverse da quelle abituali nello studio letterario e storico. Perciò verranno presentati i termini, le nozioni e i procedimenti fondamentali per un'introduzione alla linguistica contemporanea e ai recenti metodi di analisi del linguaggio (suoni, parole e frasi), in modo da fornire gli strumenti necessari per affrontare materiali scritti e parlati, sia in italiano che in altre lingue. Nella seconda parte del corso si approfondiranno aspetti lessicali | 12 |
| Storia moderna III  Acquisizione della conoscenza monografica di una tematica centrale della storia moderna, attraverso l’esame di fonti di vario tipo e della storiografia, per comprenderne criticamente i vari aspetti e collegarli alla mentalità del tempo | 6 |
| Storia dell'Europa orientale  Acquisizione di conoscenze sulla storia dell’Impero zarista, dell’Unione Sovietica, della spazio post-sovietico e su temi dalla forte rilevanza comparativa, con una particolare attenzione al mondo musulmano. Acquisizione di strumenti utili alla comprensione della storia degli imperi multinazionali e coloniali in età moderna e contemporanea, e dell’esperienza comunista novecentesca | 6 |
| Storia contemporanea I  Acquisizione di un'ampia conoscenza dei temi della storia contemporanea (europea ed extraeuropea tra XVIII e XX secolo) con un taglio diacronico e problematico che evidenzi le radici storiche profonde delle grandi questioni del presente | 12 |
| Storia economica  Acquisizione di una chiave di lettura storica dei fenomeni economici, che consenta di cogliere le loro complessità, nonché l'interrelazione tra i fatti economici e quelli di natura istituzionale e politica, al di là delle interpretazioni puramente teoriche | 6 |
| Storia delle istituzioni politiche  Acquisizione di conoscenze e competenze storico-politico-costituzionali sulle origini delle istituzioni politiche (Parlamento, Governo, magistratura, etc.) da cui scaturisce la forma di governo dell’età contemporanea | 6 |
| Storia delle istituzioni politiche – LT  Acquisizione di conoscenze e competenze storico-politico-costituzionali sulle origini delle istituzioni politiche (Parlamento, Governo, magistratura, etc.) da cui scaturisce la forma di governo dell’età contemporanea | 12 |









Dall'anno accademico 2025/2026 il corso di laurea cambierà denominazione: chi volesse iscriversi al corso, deve candidarsi al bando di ammissione TOLC-SU per la **laurea in Lettere e Storia**.

---





[Iscriversi](/it/l/beni-culturali/iscriversi "Iscriversi")
----------------------------------------------------------


Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 






