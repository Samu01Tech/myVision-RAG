

Livello: laurea di primo livello  

Classe del corso: L9, Ingegneria Industriale  

Lingua in cui si tiene il corso: Italiano  

Modalità di accesso: accesso a numero programmato, con superamento di una prova di ammissione  

Sede: Dipartimento di Ingegneria Industriale, Via Sommarive, 9 - 38123 Povo, Trento

L’accesso alla laurea in Ingegneria industriale è a numero programmato: per iscriverti al corso devi superare una prova di ammissione, che puoi svolgere indipendentemente dalla scuola superiore che hai frequentato.

Le informazioni sull’ammissione di ogni anno accademico e su come prepararsi al test  sono pubblicate alla pagina [Iscriversi](https://offertaformativa.unitn.it/it/l/ingegneria-industriale/iscriversi).

Struttura del corso
-------------------

Nel 1° anno è previsto un programma comune dove si approfondiscono gli insegnamenti di base: matematica, chimica, fisica, informatica

Dal 2° anno si introduce lo studio di discipline caratterizzanti (materiali, metallurgia, meccanica, elettronica, programmazione) e a partire dal secondo semestre puoi scegliere un settore dell’ingegneria industriale approfondire in base ai tuoi interessi e perfezionare durante il 3° anno.

Puoi scegliere fra 3 curricula innovativi, pensati per preparare laureati per le richieste del mercato del lavoro di un settore in continua evoluzione.

1. Materiali per l’industria sostenibile: approfondisce lo studio dei materiali tradizionali e di quelli innovativi, del ciclo di vita dei prodotti, delle tecnologie di trasformazione e dei processi di produzione nell’ottica della sostenibilità. Fornisce competenze di base dell'ingegneria dell’informazione per far comprendere le potenzialità offerte dalle tecnologie informatiche e il loro impatto nelle realtà produttive.
2. Robotica e Meccatronica: è finalizzato alla formazione di ingegneri orientati all’industria manifatturiera di nuova generazione. Si sofferma sullo studio di sottosistemi di differente natura, come quelli di tipo meccanico, elettrico, elettronico e informatico, arrivando a toccare le principali specificità dell’ingegneria dell’informazione. Particolare enfasi è data ai sistemi meccatronici, alla robotica e alle macchine intelligenti.
3. Gestionale: fornisce le conoscenze di base utili agli ingegneri industriali per interpretare le sfide dell’organizzazione e della gestione aziendale proprie degli impianti produttivi di ultima generazione. La preparazione verte principalmente sulle tecniche e le tecnologie di gestione e sul controllo degli impianti industriali complessi, con uno sguardo rivolto all’evoluzione del futuro.

Per i contenuti e la struttura dei 3 curricula vai alla pagina [Cosa si studia](https://offertaformativa.unitn.it/it/l/ingegneria-industriale/cosa-si-studia).

Cosa puoi fare dopo la laurea triennale
---------------------------------------

La laurea triennale ti fornisce la preparazione ideale per proseguire la tua formazione scegliendo uno dei tre corsi di laurea magistrale proposti dal Dipartimento

* [Materials Engineering](https://offertaformativa.unitn.it/it/lm/materials-engineering)
* [Mechatronics Engineering](https://offertaformativa.unitn.it/it/lm/mechatronics-engineering)
* [Management and Industrial Systems Engineering](https://offertaformativa.unitn.it/it/lm/management-industrial-systems-engineering)

o quelli proposti da altri atenei, per specializzarti in un settore specifico dell’ingegneria industriale. Vedrai così accrescere le tue possibilità di lavorare in contesti diversi, quali aziende, start up, centri di ricerca ed enti pubblici, a livello nazionale e internazionale.

Ti potrai occupare di aspetti come

* progettazione
* produzione
* controllo qualità
* assistenza tecnico-commerciale
* sviluppo e ricerca
* organizzazione e gestione

e potrai veder evolvere la tua carriera passando da un profilo tecnico a uno manageriale.

I laureati in ingegneria industriale a UniTrento sono ampiamente richiesti: **il tasso di occupazione sfiora il 100%**.

Questa formazione, infine, ti fornisce le competenze per avviare una tua attività imprenditoriale o per lavorare come libero professionista, se ciò rientra tra le tue aspirazioni.









Il corso di laurea in Ingegneria industriale è un percorso di studio flessibile che offre una solida preparazione di base per accedere alle lauree magistrali e permette di approfondire già una specifica branca dell’ingegneria industriale scegliendo fra uno dei 3 curricula disponibili.

Parte comune
------------

Dall’inizio del 1° anno e fino a metà del 2° il percorso di studio è comune: si studiano le discipline scientifiche di base, come matematica, fisica, chimica e informatica e si inizia ad approfondire conoscenze più specifiche nell’ambito dell’ingegneria industriale, come ad esempio materiali, meccanica, elettronica, programmazione, organizzazione aziendale.

[Parte comune](parte-comune)

Curriculum
----------

Il curriculum specifico si approfondisce dalla metà del 2° anno e fino alla fine del 3° e si può scegliere tra:

* [Materiali per l’industria sostenibile](materiali-industria-sostenibile)
* [Robotica e Meccatronica](robotica-e-meccatronica)
* [Gestionale](gestionale).

Nel 3° anno questa formazione si può **approfondire in base ai propri interessi** inserendo nel percorso alcuni corsi a scelta.

Questo percorso permette di ricevere una **preparazione propedeutica flessibile**per proseguire gli studi in un ampio ventaglio di lauree magistrali.









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).







### OFA

Solo nel caso in cui si svolgesse una sessione di ammissione integrativa (terza sessione), i candidati e le candidate che partecipano a questa sessione potranno essere ammessi con un **punteggio inferiore alla soglia minima prevista,** fino al raggiungimento del numero programmato annuale.

Questi candidati saranno ammessi con specifici Obblighi Formativi Aggiuntivi (OFA): per recuperarli, gli studenti e le studentesse dovranno **superare l'esame dell'insegnamento di Analisi e Geometria** (mod.1 - Analisi matematica e mod.2 - Geometria e algebra lineare) prima di sostenere qualsiasi altro esame.







### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.







Lingua inglese
--------------

Il corso si svolge in italiano, ma per accedere è necessario dimostrare di avere un minimo di conoscenza della lingua lnglese, pari al livello B1: si può fare durante il test di ammissione o con una prova, entro la fine del 1° anno di corso, oppure presentando un certificato linguistico che si ha già, come indicato in alla pagina [Lingue straniere - Requisiti linguistici di ammissione al corso](lingue-straniere).







Preparazione di base
--------------------

Per affrontare bene il percorso di studio e la prova di ammissione sono importanti alcune conoscenze di base nell’ambito della Matematica, della Fisica e della Chimica

### Matematica

* **Aritmetica e algebra**:
  + proprietà e operazioni sui numeri (interi, razionali, reali)
  + valore assoluto
  + potenze e radici
  + logaritmi ed esponenziali
  + calcolo letterale
  + polinomi (operazioni, decomposizione in fattori)
  + equazioni e disequazioni algebriche di primo e secondo grado
  + sistemi di equazioni di primo grado.
* **Geometria**:
  + segmenti e angoli (loro misura e proprietà)
  + rette e piani
  + luoghi geometrici notevoli
  + proprietà delle principali figure geometriche piane
  + proprietà delle principali figure geometriche solide.
* **Geometria analitica e funzioni**:
  + coordinate cartesiane
  + concetto di funzione
  + equazioni di rette e di semplici luoghi geometrici
  + grafici e proprietà delle funzioni elementari.
* **Trigonometria**:
  + grafici e proprietà delle funzioni trigonometriche
  + principali formule trigonometriche (addizione, sottrazione, duplicazione, bisezione)
  + relazioni fra elementi di un triangolo.

### Fisica e Chimica

Conoscenza delle nozioni elementari sulle **grandezze fisiche** e sulla **struttura della materia**

### Tutorato e corso di matematica

Per avviarsi bene allo studio delle discipline del primo anno il DII (Dipartimento di Ingegneria Industriale) offre:

* alcuni [corsi di tutorato](https://www.dii.unitn.it/108/tutorato), realizzati con la collaborazione di studenti tutor appositamente selezionati
* un corso di matematica a distanza ‘on demand’ che si può chiedere di frequentare  prima di iniziare le lezioni del 1° anno per rafforzare i concetti di base.








 

