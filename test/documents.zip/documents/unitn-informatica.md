
[![](https://offertaformativa.unitn.it/file/offertaformativa/bollinosmall2020.png "Certificazione della qualità dei contenuti delle lauree in Informatica GRIN")](https://www.grin.cloud/certificazione-qualita-contenuti "Certificazione della qualità dei contenuti delle lauree in Informatica GRIN")



* **Livello**: Laurea di primo livello
* **Durata**: 3 anni
* **Classe**del corso: **L-31 - Scienze e Tecnologie informatiche**
* **Lingua** in cui si tiene il corso: sono previsti un percorso **in lingua italiana** e un **percorso in lingua inglese.**
* **Modalità di accesso**: accesso a numero **programmato**, con superamento di una prova di ammissione
* **Sede**: Dipartimento di Ingegneria e Scienza dell'Informazione, via Sommarive 5, 38123 Povo (TN).

Il corso
--------

L'Informatica è una disciplina a cavallo **fra le Scienze e l'Ingegneria**:

* dalle Scienze eredita la **curiosità**: per esempio quella di capire cosa significa risolvere problemi in modo automatico, anche dal punto di vista filosofico
* dall'Ingegneria eredita il **rigore metodologico** nel risolvere i problemi.

L'Informatica è oggi vista come una delle “tre gambe” su cui si reggono le Scienze moderne (assieme alla teoria e alla sperimentazione) .

**L'informatica è pervasiva** nella vita delle società umane e genera buona parte della ricchezza delle economie occidentali. Per lavorare allo sviluppo di questo settore occorre una solida base di conoscenze teoriche, ma anche la capacità di usare strumenti "pratici" in grado di rendere la progettazione e lo sviluppo del software un'attività di livello industriale.

* Il Corso di Laurea in Informatica forma professionisti e ricercatori forti in entrambi questi aspetti: corsi teorici e corsi pratici (di laboratorio) si alternano o si integrano durante tutto il ciclo di studi.
* I laureati e le laureate in Informatica dell’Università di Trento trovano lavoro mediamente in 2 mesi (fonte: Almalaurea), spesso anche prima di laurearsi. I lavori relativi all'Informatica sono nella lista dei primi cinque lavori più ricercati in Italia.

Il corso di laurea in Informatica dell'Università di Trento ha alcune caratteristiche, che lo avvicinano molto alle più prestigiose realtà europee e mondiali:

* il corpo docente è **giovane e dinamico**.
* Quasi tutti i docenti e le docenti sono molto **attivi nella ricerca** e rinomati nel loro settore, come dimostrano gli indici da bibliometrici quali Google Scholar e numerosi riconoscimenti internazionali.
* Il Dipartimento di Informatica a Trento ha una forte spinta verso **l'internazionalizzazione**: il 20% dei nostri docenti e circa il 40% degli studenti delle lauree magistrali provengono dall'estero. Essere immersi in un ambiente internazionale permette di confrontarsi fin da giovanissimi con problematiche globali, anche dal punto di vista culturale, e poter partecipare a programmi ERASMUS avvalendosi della fitta rete di collaborazioni internazionali dei docenti.
* I **contatti con l'industria** sono molto stretti e permettono di svolgere importanti esperienze di stage e di trovare lavoro facilmente. Ogni anno si svolgono gli **ICT days**, dove gli studenti e le studentesse entrano in contatto con le aziende, e dove verranno svolti veri e propri colloqui di lavoro.
* Il percorso formativo è stato progettato in modo da dare giusto spazio sia alle esigenze formative di base e sia alla conoscenza e alla padronanza delle tecnologie più recenti.

Per questi motivi il corso di Informatica ha un valore riconosciuto anche dai primi posti nelle classifiche nazionali e ha ottenuto il  [bollino GRIN](http://www.grin-informatica.it/opencms/opencms/grin/didattica/bollino.html), assegnato da GRIN (Gruppo di Informatica, l'associazione dei professori universitari di informatica) e AICA (Associazione Italiana per l'Informatica ed il Calcolo Automatico) per la **qualità dei contenuti** delle lauree triennali e magistrali di informatica.

Obiettivi formativi
-------------------

Il Corso di Laurea in Informatica forma persone con solide basi ed un ampio spettro di competenze nel settore della scienza e della tecnologia dell'informazione.

Il laureato o la laureata in informatica è un professionista con la capacità di

* analizzare **sistemi complessi** (aziende, servizi, sistemi naturali ed artificiali)
* identificare i **processi cruciali** in maniera sistematica
* proporre **modelli e soluzioni realizzabili** tramite tecnologie e sistemi informatici.

La mentalità che si sviluppa laureandosi in Informatica, approfondendo strumenti e metodi scientifici di tipo universale, permette di inserirsi rapidamente in contesti di lavoro diversi, adattandosi alla rapida innovazione che caratterizza il settore.

Dopo la laurea
--------------

### Lavoro

La struttura del corso di laurea permette sia di accedere ai livelli superiori di studio in area informatica, che di entrare direttamente nel mondo del lavoro al termine della laurea di primo livello (attraverso una solida formazione tecnica nel nei vari campi dell’informatica, ad esempio delle reti, dei sistemi, della gestione e rappresentazione dei dati).

Il laureato e la laureata in Informatica possono accedere ad attività lavorative nell'ambito della progettazione, organizzazione, sviluppo, gestione e mantenimento di sistemi informatici.

Per gli studenti interessati, che proseguono il curriculum verso la laurea magistrale, si aprono carriere di tipo dirigenziale, dove una solida competenza sui principi della complessità e della soluzione dei problemi si sposa con capacità di interazione, di lavoro di squadra, di proposta innovativa. In questo campo lo spazio dato alle capacità individuali è massimo: l’informatica è tuttora un settore dove aziende innovative create da giovani intraprendenti battono spesso sul tempo e sulla qualità imprese ben più consolidate. Il corso prepara alle professioni di:

* tecnici programmatori
* tecnici amministratori di reti e di sistemi telematici
* tecnici amministratori di basi di dati
* tecnici esperti in applicazioni.

### Studio

La laurea di primo livello in Informatica fornisce le conoscenze necessarie per accedere:

* alla laurea magistrale in [Computer Science](http://offertaformativa.unitn.it/it/lm/informatica)e simili
* alla laurea magistrale in [Information Engineering](https://offertaformativa.unitn.it/en/lm/information-engineering) e simili
* alla laurea magistrale in [Artificial Intelligence Systems](http://offertaformativa.unitn.it/en/lm/artificial-intelligence-systems) e simili
* alla laurea magistrale in [Data Science](http://offertaformativa.unitn.it/en/lm/data-science) e simili
* alla laurea magistrale in [Human-Computer Interaction](http://offertaformativa.unitn.it/it/lm/human-computer-interaction)
* alla laurea magistrale in [Quantitative and Computational Biology](http://international.unitn.it/mqcb).

È inoltre possibile, tramite scelta oculata del proprio piano di studio, accedere a lauree magistrali “affini” quali la laurea magistrale in Matematica, in Economia e Management









Il corso prevede una articolazione in percorsi nei 3 anni, per un totale di 180 crediti.

Dall'anno accademico 2024/2025 è offerto **in italiano** e **in inglese**, con due percorsi analoghi per contenuti e finalità, diversi solo per la lingua.  

Nel percorso in italiano alcuni insegnamenti, in particolare quelli a scelta, si possono svolgere in inglese.

Si può inoltre scegliere un piano di studio personalizzato che deve rispettare l’ordinamento e il regolamento didattico e deve essere approvato da una commissione.

Questo corso è indicato sia per coloro che intendano proseguire gli studi con un corso di studio magistrale in materie informatiche o affini, sia per coloro che intendano concludere gli studi al termine del corso di laurea in Informatica.

**Insegnamenti obbligatori**
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Analisi matematica 1 | 12 |
| Geometria e algebra lineare | 6 |
| Programmazione 1 | 12 |
| Calcolatori | 6 |
| Fondamenti matematici per l'informatica | 6 |
| Probabilità e statistica | 6 |
| Programmazione 2 | 6 |
| Programmazione Funzionale | 6 |
| Algoritmi e strutture dati | 12 |
| Ingegneria del software | 12 |
| Basi di dati | 6 |
| Reti | 6 |
| Sistemi operativi | 12 |
| Logica computazionale | 6 |
| Fisica | 6 |
| Linguaggi formali e compilatori | 12 |
| Introduction to machine learning | 6 |

**12 crediti a scelta tra i seguenti insegnamenti**
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Introduzione alla programmazione per il Web | 6 |
| Human Computer Interaction (in inglese) | 6 |
| Reti logiche | 6 |
| Fondamenti di elaborazione dei segnali | 6 |
| Introduction to Computer and Network Security (in inglese) | 6 |
| Sistemi informativi | 6 |
| Programmazione avanzata | 6 |
| Laboratorio di programmazione per sistemi mobili e tablet | 6 |
| Optimization Techniques (in inglese) | 6 |
| Analisi Matematica 2 | 6 |
| Altri insegnamenti a scelta libera | 12 |

**Altre attività obbligatorie**
| Insegnamento | Crediti (CFU) |
| --- | --- |
| Tirocini formativi e di orientamento | 9 |
| Inglese B1 | 3 |
| Prova finale | 6 |









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).







### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 

