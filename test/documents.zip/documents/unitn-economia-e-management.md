

Il mondo dell’economia, dei mercati, delle imprese è in rapida e profonda trasformazione e il modo migliore per affrontarlo è disporre di una **solida e approfondita padronanza delle conoscenze economiche e manageriali**. Questo corso di laurea è rivolto a studenti ambiziosi che, fin dall'immatricolazione, sentono il desiderio di intraprendere un **percorso di studi che prosegue con la laurea magistrale** al fine di acquisire una **specializzazione di alto livello**.

La laurea in Economia e management è un corso interclasse, nelle **due classi di laurea**:

* classe **L-33** classe delle lauree in **Scienze economiche**
* classe **L-18** classe delle lauree in **Scienze dell’economia della gestione aziendale**

Devi scegliere la classe di laurea al momento dell'immatricolazione. Puoi modificare questa scelta fino alla fine del 2° anno.

La laurea in Economia e Management si articola inoltre in **due percorsi**:

* **Economia e Management**- **in italiano**
* **Economics and Management** - **in inglese**

Obiettivi formativi
-------------------

### Obiettivi formativi comuni

Il percorso Generale e il percorso Economics e Management hanno molti obiettivi in comune:

* offrire una **solida preparazione metodologica** di base nelle **scienze economiche e manageriali**
* mettere in grado lo studente di padroneggiare in maniera corretta e aggiornata gli **strumenti di analisi economica**, dando particolare spazio all’acquisizione di **strumenti matematici e statistici**
* fornire una formazione aperta all'**apprendimento continuo** e all’**innovazione dei saperi**

### Il percorso Economics and Management

L’obiettivo del nuovo percorso Economics and Management è quello di selezionare studenti e studentesse interessati ad un **corso innovativo**, sia sul piano della **didattica** che di quello dei **contenuti**, e con una spiccata disposizione verso la **dimensione internazionale**. In particolare, questo percorso si caratterizza per una **migliore e più profonda interazione tra le materie quantitative (matematica, statistica), quelle economiche e l’informatica**. Ciò fornisce competenze e strumenti per l’**elaborazione di grandi quantità di dati e informazioni** con l’obiettivo di definire **scenari**, **modelli** e **simulazioni** in grado di **guidare il processo decisionale**.

L’attivazione di un percorso in lingua **inglese**, inoltre, completa l’offerta formativa del dipartimento di Economia e Management, già ricca di corsi di laurea magistrale in lingua inglese. Con il percorso Economics and Management il dipartimento è in grado ora di proporre un **intero percorso di studio in inglese dalla laurea triennale quella magistrale** e, parallelamente, anche di aprirsi agli **studenti internazionali**.

### Obiettivi formativi specifici

Gli obiettivi formativi specifici di ciascun percorso possono essere approfonditi alle pagine:

[Cosa si studia - percorso Economia e Management](https://offertaformativa.unitn.it/it/l/economia-e-management/cosa-si-studia-percorso-economia-e-management)  

[Cosa si studia - percorso Economics and Management](https://offertaformativa.unitn.it/it/l/economia-e-management/cosa-si-studia-percorso-economics-and-management)  


Profili professionali
---------------------

Il laureato può scegliere tra molte opportunità per sviluppare le proprie scelte vocazionali in campi diversi, tutte contraddistinte da un elevato livello formativo e professionale multidisciplinare.

Il corso prepara a professioni specialistiche in aziende di varie dimensioni, come ad esempio:

* tecnici degli **affari generali**
* tecnici addetti all’**organizzazione** e al **controllo della produzione**
* **professioni intermedie finanziario-assicurative**
* tecnici del **marketing**

Studi dopo la laurea
--------------------

Lo sbocco naturale del corso è la prosecuzione degli studi, al fine di valorizzare le conoscenze e le capacità di tipo metodologico acquisite nel corso della laurea magistrale.

Il Dipartimento di Economia e Management offre un’ampia scelta di corsi sia in inglese che in italiano:

* [Behavioral and Applied Economics](https://international.unitn.it/bea)
* [Economics](https://international.unitn.it/mec)
* [European Master in Business Studies (EMBS)](https://international.unitn.it/embs)
* [Finanza](https://offertaformativa.unitn.it/it/lm/finanza)
* [Innovation management](https://international.unitn.it/main)
* [International management](https://international.unitn.it/mim)
* [Management](https://offertaformativa.unitn.it/it/lm/management)
* [Management della sostenibilità e del turismo](https://offertaformativa.unitn.it/it/lm/management-della-sostenibilita-e-del-turismo)







In questa pagina trovi elencate le **attività didattiche elencate per ogni anno**, come previste nel regolamento didattico del corso.  

Per conoscere nel dettaglio i contenuti puoi consultare:

* il **Regolamento didattico e le tabelle allegate con le regole e la struttura generale del corso** alla pagina [Norme e Regolamenti](https://offertaformativa.unitn.it/it/l/economia-e-management/norme-e-regolamenti)
* gli **schemi di piani di studio con le attività formative attivate ogni anno accademico** alla pagina [Studiare e frequentare](https://offertaformativa.unitn.it/it/l/economia-e-management/studiare-e-frequentare).

Primo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Analisi dei dati e Statistica  Conoscenze: strumenti quantitativi per lo studio, la descrizione, l’interpretazione e la previsione di un qualsivoglia fenomeno attraverso rappresentazioni grafiche, misure di sintesi, metodi e tecniche inferenziali; costruzione di modelli di base e scenari relativi ad applicazioni in ambito economico (micro e macro) e del management. Abilità: rappresentare dati economico-aziendali tramite loro sintesi numeriche e grafiche; costruire semplici modelli in grado di esprimere le relazioni tra le grandezze coinvolte; analizzare le tendenze di fondo relative a un fenomeno, cogliere e misurare l’intensità delle relazioni tra le variabili determinanti; elaborare brevi report statistici. | 8 |
| Introduzione all'economia  Conoscenze: basi concettuali, terminologiche e teoriche della scienza economica, utilizzando un approccio che integra temi microeconomici e temi macroeconomici; problemi e concetti fondamentali della teoria economica, in relazione gli aspetti che definiscono la struttura di un sistema economico nelle sue diverse dimensioni: pubblica e privata, reale e finanziaria, interna e internazionale. Fondamenti di analisi storica dell'economia. Abilità: accostarsi al ragionamento economico dominando terminologia e concetti fondamentali. | 12 |
| Matematica  Conoscenze: strumenti fondamentali necessari ad una analisi quantitativa dell'economia, quali il calcolo differenziale per le funzioni di una o più variabili, l'algebra lineare e l'ottimizzazione libera e vincolata. Abilità: capacità di formalizzare un problema in termini matematici; capacità di impiegare in modo appropriato gli strumenti del calcolo differenziale e dell'ottimizzazione. | 12 |
| Introduzione al diritto  Conoscenze in materia di sistema delle fonti del diritto, soggetti giuridici e relative situazioni soggettive attive e passive, organizzazione e funzionamento delle istituzioni pubbliche che producono e applicano il diritto, modalità e strumenti di regolazione dei rapporti giuridici fra soggetti privati, sistema della tutela e istituzioni della giustizia. Capacità: individuare e collocare correttamente le fonti giuridiche che disciplinano i rapporti fra i soggetti economici; inquadrare i soggetti economici nell’intreccio dei diritti e degli obblighi connessi all’esercizio della loro attività; individuare le modalità e gli strumenti attraverso cui le istituzioni pubbliche condizionano l’andamento dell’economia; utilizzare le principali tecniche interpretative per la soluzione di problemi giuridici; riconoscere i principali mezzi di tutela giurisdizionale. | 12 |
| Economia e Misurazione aziendale  Conoscenze: tipologie di aziende; governo, organizzazione e modello di funzionamento economico delle aziende di produzione; sistema delle rilevazioni inteso a misurare il grado di efficienza dei processi attraverso i quali le aziende producono valore. I concetti di valore e risultato. I fondamenti della contabilità aziendale, dell'analisi finanziaria e del controllo di gestione. Procedimenti di determinazione delle misure di sintesi delle grandezze economiche, finanziarie e patrimoniali. Capacità: redigere i principali documenti e rapporti utilizzati nella comunicazione economico-finanziaria verso l'interno e l'esterno dell'azienda, ovvero il bilancio d'esercizio, le analisi di bilancio, i budget. | 8 |
| Storia dei sistemi economici  Conoscenze: cosa sono i sistemi economici, come si differenziano, quali sono le variabili (ambientali, sociali, culturali e istituzionali) che incidono sui processi di sviluppo nel lungo periodo; comprendere le motivazioni che stanno alla base delle scelte degli attori economici e come queste dipendano dal contesto di riferimento; interpretare il significato di alcune cruciali cesure della storia dell’economia - la rivoluzione industriale, la globalizzazione, le grandi crisi finanziarie - valutandone le conseguenze di lungo periodo; leggere i fondamenti della teoria economica alla luce della realtà storica. Abilità: essere in grado di interpretare i fatti economici tenendo conto della loro natura complessa; individuare i fattori cruciali nei processi di sviluppo; riuscire a mettere in relazione i concetti fondamentali della teoria con la realtà storica dei sistemi economici." | 6 |
| Test di informatica  Lo studente dovrà dimostrare di saper utilizzare gli applicativi informatici di produttività personale (Open Office, Microsoft Office, etc.) a livello ECDL Base o ECDL Start (o equivalente) - 4 moduli base. | 0 |
| Test di matematica  Test che verifica la padronanza degli strumenti di base della logica e della matematica tra le quali: calcolo algebrico elementare: potenze, valore assoluto, polinomi, equazioni e disequazioni di 1° e 2° grado; nozioni fondamentali di geometria analitica: retta, circonferenza, parabola, ellisse e iperbole. | 0 |


### Un test di lingua a scelta

È obbligatorio superare il test di lingua entro il primo anno, in quanto propedeutico al sostenimento degli esami del secondo anno.  

**Il test di inglese B1 è comunque obbligatorio per poter poi superare la Prova di lingua Inglese del terzo anno.**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Test di Inglese B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. Obbligatorio per poter superare la Prova di lingua Inglese del terzo anno. | 0 |
| Test di Francese B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |
| Test di Spagnolo B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |
| Test di Tedesco B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |

Secondo anno
------------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Laboratorio di analisi dei mercati  Conoscenze: le principali variabili che descrivono l’andamento di un mercato (volumi, fatturato, prezzi unitari) e loro interpretazione; le determinanti della domanda (popolazione, redditi, prezzi di beni complementi/sostituti); la struttura dell’offerta di mercato, il contesto competitivo e i metodi per il loro studio (quote imprese, indici di concentrazione, barriere all’entrata, determinanti dei costi e possibilità di differenziazione); la struttura e il posizionamento di una specifica impresa e le scelte strategiche operate dalla stessa. Abilità: comprendere, presentare ed elaborare dati; utilizzare dati a fini interpretativi,riconoscendone il contenuto informativo ed utilizzando le conoscenze teoriche apprese nei corsi di base per comprendere le possibili cause dei fenomeni; in particolare, descrivere, elaborare e confrontare dati economici di base; interpretare e distinguere i dati/fenomeni che si riferiscono alla domanda di mercato da quelli che si riferiscono all’offerta; fornire un quadro chiaro sia dell’andamento del mercato, che della domanda e dell’offerta, distinguendo variazioni di lungo periodo da variazioni congiunturali; distinguere il punto di vista dell’analisi economica del mercato dal punto di vista della singola impresa; elaborare un rapporto. | 8 |
| Finanza aziendale  Conoscenze: strumenti per impostare efficientemente le decisioni finanziarie di un'impresa al fine di creare valore a vantaggio dei proprietari e dei creditori; modelli di valutazione dei rischi sopportati dai finanziatori; criteri di valutazione dei progetti di investimento; decisioni riguardanti la struttura delle fonti di finanziamento e la sua composizione per strumenti. Abilità: analizzare le scelte di investimento e delle fonti di finanziamento; valutare la posizione finanziaria di un'impresa. | 8 |
| Organizzazione aziendale  Conoscenze: strumenti concettuali e terminologici per interpretare il fenomeno organizzativo in chiave di soluzione a problemi di interdipendenza tra decisori, evidenziandone i caratteri relazionali e di processo. Abilità: interpretare i principali problemi di governance, coordinamento e struttura, e riconoscere i sintomi che li caratterizzano. | 8 |
| Microeconomia  Conoscenze: approfondimento ed ampliamento delle nozioni di base della microeconomia acquisite in precedenza; strumenti per l’analisi dei comportamenti economici di imprese e famiglie (teoria del consumatore ed equilibrio generale di puro scambio; teoria della produzione e dei costi), e del funzionamento dei mercati perfetti e imperfetti (teoria dei mercati); elementi basilari della teoria delle decisioni in condizioni d'incertezza, dell'informazione asimmetrica e della teoria dei giochi. Abilità: individuare gli elementi fondamentali per l'analisi del comportamento dei singoli soggetti e del modo in cui le scelte individuali interagiscono sui mercati; riconoscere ed analizzare le varie forme di mercato; applicare alcuni principi della microeconomia al mondo reale. | 8 |
| Macroeconomia  Conoscenze: approfondimento ed ampliamento delle nozioni di base della macroeconomia acquisite in precedenza; teorie della crescita e delle fluttuazioni, e loro risvolti in tema di occupazione e inflazione; nozioni delle principali teorie neo-classiche e neo-keynesiane e prescrizioni per le politiche macroeconomiche da esse derivanti. Abilità: elaborare ed analizzare i principali dati ed indicatori macroeconomici relativi ai temi trattati; sul piano teorico, acquisire le nozioni delle principali teorie neo-classiche e neo-keynesiane, comprendendo le loro complementarietà e differenze, le loro relazioni coi dati e con le principali prescrizioni per le politiche macroeconomiche. | 8 |
| Economia pubblica  Conoscenze: richiami di economia del benessere. Le decisioni collettive. Le giustificazioni e i limiti dell’intervento pubblico (fallimenti del mercato). La teoria delle imposte. L’ordinamento tributario: aspetti economici ed istituzionali. La spesa pubblica: aspetti generali, sanità e previdenza. La finanza pubblica e i saldi di bilancio. Abilità: conoscere le motivazioni e le principali attività svolte dal settore pubblico nei sistemi economici moderni; essere in grado di applicare le teorie sviluppate dall'economia pubblica per comprendere il funzionamento del settore pubblico nel mondo reale; utilizzare l'analisi economica per discriminare fra modelli alternativi utili ad interpretare l'evidenza osservata sul settore pubblico e sulla finanza pubblica in diversi contesti; comprendere l’impatto in termini di efficienza e di equità della politica economica di governo in un determinato paese. | 6 |
| Diritto della regolazione  Conoscenze in materia di sistema delle fonti che regolano il diritto dell’economia; organizzazione e funzionamento delle istituzioni pubbliche che intervengono nella regolazione dell’economia; procedure attraverso cui viene operata la regolazione pubblica dell’economia; contenuti delle principali regolazioni di settore. Abilità: individuare ed utilizzare correttamente le fonti giuridiche nazionali e comunitarie; comprendere le modalità e gli strumenti di intervento dei poteri pubblici nella regolazione giuridica dei rapporti economici; comprendere e gestire le dinamiche attivate dall’utilizzo degli strumenti giuridici nel governo dell’economia. | 8 |
| Statistica, probabilità e inferenza  Conoscenze: metodi statistici e loro applicazione in ambito economico-sociale; richiami di inferenza statistica: stime puntuali ed intervallari; test di significatività; confronti tra gruppi e per campioni dipendenti; analisi dell'associazione tra variabili qualitative; regressione lineare e correlazione con particolare riferimento alle stime OLS; aspetti inferenziali; relazioni lineari multivariate; modelli per variabili dipendenti qualitative: la regressione logistica semplice e multipla; la stima di massima verosimiglianza; Inferenza per i modelli di regressione logistica. Abilità: modellare le associazione tra variabili qualitative e quantitative con un approccio che enfatizza i concetti e le applicazioni in ambito economico-sociale; affrontare analisi empiriche che impiegano strumenti statistico-inferenziali con l’utilizzo del software R; impostare e sviluppare stime che fanno uso di dati binari. | 8 |

Terzo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Strategie d’impresa  Conoscenze: comprendere le modalità di formazione delle decisioni strategiche inserendole nei contesti organizzativi, analizzarne le specifiche componenti utilizzando i principali modelli di analisi strategica, valutarne l'impatto e i risultati. Abilità: analizzare casi concreti; interpretare la realtà aziendale e esprimere autonomi giudizi sul processo e sui risultati delle decisioni strategiche delle imprese; identificare alternative decisionali ponderandone i costi e i benefici scegliendo le più opportune; presentare le diverse soluzioni proposte e argomentare le scelte effettuate. | 8 |
| Economia Industriale  Conoscenze: strumenti teorici per l'analisi della dinamica delle imprese e dei settori industriali con particolare attenzione ai mercati oligopolistici, ovvero dei mercati caratterizzati da una forte interazione strategica tra le imprese. Abilità: comprendere i modelli dell’economia industriale e applicarli all’analisi di situazioni reali; analizzare strategie quali la diversificazione dei prodotti, la pubblicità, l'attività di ricerca e sviluppo, ecc., che le imprese possono adottare per competere efficacemente su mercati imperfettamente competitivi. | 6 |
| Prova di lingua Inglese  Livello di conoscenza B1 attivo. E' obbligatorio superare il test di inglese B1 da CFU del primo anno. | 6 |
| Insegnamenti a libera scelta dello studente  E’ consigliato l’inserimento nel piano degli studi di un insegnamento al primo anno e un al terzo anno entrambi da 6 crediti. | 12 |
| Prova finale | 4 |


### 2 insegnamenti a scelta tra


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Contabilità, bilancio e principi contabili  Conoscenze in materia di: sistemi contabili nell'ambito del sistema informativo aziendale; tecnica contabile di formazione del bilancio d'esercizio, valutazioni di bilancio con riferimento alle principali fonti normative: codice civile, principi contabili nazionali e principi contabili internazionali. L'utilizzo del dato contabile nell'analisi finanziaria dell'impresa. Abilità: aver acquisito le basi della tecnica contabile; essere in grado di redigere bilanci di impresa con riferimento alle operazioni ordinarie; di valutare la rispondenza dei bilanci alle norme giuridiche e ai principi contabili; di analizzare bilanci sotto il profilo economico e finanziario | 8 |
| Econometrics (in inglese)  Obiettivo: lo scopo del corso è quello di fornire le nozioni di base relative al modello di regressione lineare semplice e multipla applicato sia a dati di tipo microeconomico sia a dati di tipo macroeconomico. Conoscenze: il modello di regressione lineare semplice e multipla. Concetti necessari per l'interpretazione delle stime e delle verifiche di ipotesi relativamente a semplici modelli econometrici, con particolare attenzione alla tipologia dell'informazione statistica campionaria disponibile, sezionale o storica. Il modello di regressione lineare semplice e multipla in relazione sia a dati di tipo microeconomico sia a dati di tipo macroeconomico. Abilità: impiegare e verificare le potenzialità degli strumenti metodologici acquisiti stimando alcune semplici relazioni economiche di interesse. | 8 |
| Economia dell'innovazione  Conoscenze: nozioni di base relative a determinanti, processi ed effetti economici dell’innovazione a livello di impresa (dimensione e forme di mercato), di settore economico (regimi tecnologici e sistemi settoriali di innovazione) e di sistema economico nazionale (crescita, occupazione e politiche economiche). Abilità: comprendere il ruolo delle caratteristiche economiche di imprese e mercati per l’introduzione e la diffusione dell’innovazione ed analizzare i suoi effetti economici, in particolare in termini di crescita economica ed occupazione. | 8 |
| Modelli matematici per le applicazioni economiche  Conoscenze: strumenti matematici per l’analisi e la formulazione di modelli per alcune classi di problemi di decisione; algoritmi in grado di risolvere in modo ottimale tali problemi. Abilità: capacità di formalizzare correttamente alcuni problemi decisionali; capacità di applicare metodi di soluzione algoritmici ed euristici. | 8 |
| Matematica finanziaria  Conoscenze: concetti fondamentali della matematica finanziaria necessari per valutare la redditività e la rischiosità delle operazioni finanziarie con dati certi; criteri decisionali per la scelta tra progetti finanziari aleatori. Abilità: capacità di svolgere correttamente calcoli finanziari; capacità di impostare problemi finanziari e di delinearne soluzioni. | 8 |
| Modelli di decisione per la gestione  Conoscenze: la struttura dei principali problemi decisionali d'impresa; modelli di ottimizzazione e di euristiche nelle decisioni aziendali; integrazione dei diversi modelli di decisione per la gestione e delle diverse euristiche. Abilità: affrontare un problema decisionale rappresentandone correttamente la struttura e i vincoli; impiegare in modo integrato diversi modelli per simulare l'istruzione di una decisione gestionale; comunicare e presentare un lavoro di istruzione di una decisione. | 8 |
| Economia del lavoro e della famiglia  Conoscenze: nozioni di base relative al comportamento dei soggetti che operano nel mercato del lavoro (gli individui e le famiglie, le imprese, lo Stato) e alla loro interazione. Concetti di base inerenti il mercato del lavoro (disoccupazione, partecipazione, offerta di lavoro) e la struttura dell'occupazione. Cause della disoccupazione e modelli di determinazione dei salari. Abilità: comprendere le interazioni tra il mercato del lavoro e gli altri mercati e analizzare gli effetti delle politiche del lavoro sull’occupazione, sui salari, e sull’offerta di lavoro da parte delle famiglie. | 8 |
| Marketing  Conoscenze: conoscenze di base necessarie per assumere decisioni nel campo del Marketing in aziende profit e non profit. Collocazione la funzione di marketing rispetto alle altre funzioni aziendali imprese appartenenti al settore B&C. Abilità: capacità di impostare le principali politiche di marketing; capacità di formulare, a un livello iniziale, un piano di marketing. | 8 |


### 1 insegnamento a scelta tra


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Laboratorio sull’economia italiana  Conoscenze: contabilità della crescita; famiglie, imprese, banche, sistema pubblico ed estero. Il saldo del sistema pubblico. Il saldo dei conti con l’estero. Abilità: individuare ed utilizzare correttamente alcune fonti statistiche della contabilità nazionale; elaborare ed analizzare i principali dati ed indicatori sui temi trattati; reperire, costruire ed elaborare informazioni sul sistema economico italiano allo scopo di redigere un rapporto che descriva ed interpreti specifiche caratteristiche dell’economia italiana; utilizzare un data-base a tale scopo. | 8 |
| Laboratorio di strategia e digitale  Obiettivo: Il laboratorio intende fornire strumenti di analisi critica del ruolo del digitale nell’ideazione e realizzazione di strategie e modelli di business di incumbent e start-up. I casi di transizione digitale (incumbent) saranno dunque accostati a quelli di born-digital (start-up) per comprenderne differenze e implicazioni. Conoscenze: Il laboratorio ha natura multidisciplinare in attuazione del principio di intelligenza connettiva. Questa richiede - tra l’altro - la capacità di utilizzare concetti provenienti da discipline apparentemente distanti per comprendere la complessità di fenomeni aziendali. Abilità: Il laboratorio intende rafforzare il senso critico e la capacità di costruire ragionamenti logicamente coerenti - basati sull’analisi di dati - da esporre in pubblico così da favorire ulteriormente lo sviluppo di competenze tecniche e dialettiche | 8 |
| Laboratorio di economia finanziaria  Obiettivo: fornire opportunità di applicazione delle nozioni principali di finanza acquisite nei corsi di area economica e aziendale, mediante analisi di dati di livello aggregato, settoriale o aziendale, studi di casi, elaborazioni di scenari previsionali, anche simulativi. Conoscenze: comprensione e analisi applicativa dei principali dati finanziari nazionali, settoriali e aziendali; interrelazioni tra variabili finanziarie e attività economica; tecniche di pianificazione e gestione finanziaria; profili di rischio finanziario delle imprese e degli intermediari finanziari. Abilità: elaborazione dei dati finanziari funzionali alla previsione del loro impatto economico; soluzione di problemi di pianificazione e gestione finanziaria; analisi di sostenibilità finanziaria e strumenti di gestione del rischio. | 8 |
| Laboratorio di analisi di bilancio  Obiettivo: il laboratorio intende fornire strumenti analitici e conoscenza critica per valutare, in chiave comparata, le performance economiche, patrimoniali e finanziarie delle imprese, attraverso gli strumenti dell’analisi di bilancio (per indici e per flussi). Conoscenze: il laboratorio ha natura pluridisciplinare, in quanto integra le conoscenze di natura strategica e organizzativa con quelle di analisi contabile del dato. In particolare il laboratorio permetterà di analizzare l’impatto delle decisioni strategico aziendale sulle performance economico-aziendali delle imprese. Abilità: il laboratorio intende rafforzare il senso critico, le capacità di costruire ragionamenti partendo dall’analisi di bilancio condotta e permettere agli studenti di analizzare banche dati per l’estrapolazione delle informazioni di bilancio necessarie. Verranno quindi sviluppate competenze tecnico-analitiche di comprensione e analisi del dato e competenze critico-strategico di individuazione degli impatti contabili delle scelte strategiche. | 8 |





[![application/pdf](/sites/all/modules/contrib/alfresco/images/filetypes/pdf.gif "application/pdf")Caratteristiche delle classi di laurea L-33 e L-18](/alfresco/download/workspace/SpacesStore/369194b7-9aaf-455a-aeba-262cc7a2fb71/caratteristiche_classe_l33_e_l18.pdf)(PDF | 137 KB)  
 last update 28/05/2020 






È un **corso interclasse**, accreditato cioè in entrambe le classi di laurea:

* Classe **L-33** classe delle lauree in **Scienze economiche**
* Classe **L-18** classe delle lauree in **Scienze dell’economia della gestione aziendale**

Quando ti immatricoli dovrai indicare una delle due classi di laurea. Questa scelta è modificabile fino a prima dell’iscrizione al terzo anno.

Il percorso Economics and Management si pone **obiettivi innovativi** sia sul piano degli insegnamenti proposti, in particolare l’**informatica**, sia per le metodologie con cui viene svolta la **didattica**.

**Informatica**. E’ previsto un corso di informatica al primo anno con l’obiettivo di fornire agli studenti gli **elementi di base della programmazione strutturata**, utilizzando alcuni dei linguaggi di programmazione che hanno maggiore diffusione al momento (R, Matlab, Python) con un’enfasi sulle **applicazioni alle scienze economiche e manageriali**. L’acquisizione di competenze in materia di programmazione strutturata è alla base delle **applicazioni computer-intensive** indispensabili in ambito economico, manageriale e finanziario. L’obiettivo è facilitare l’approccio ai **nuovi settori delle discipline economiche** aperti dallo sviluppo dei big data, dell’artificial intelligence e del machine learning.

**Didattica innovativa**. Grazie a un numero limitato di studenti il percorso è in grado di proporre diverse metodologie didattiche:

* strumenti informatici per l’insegnamento sia delle materie quantitative che di quelle economico-manageriali
* esperimenti e simulazioni nell’attività didattica
* tecnologie multimediali per l’apprendimento come corsi on-line e video-lezioni
* ‘Flipped (or inverted) approaches’ (tecniche per attivare interazione e partecipazione dello studente) preceduto da hard-learning at home
* problem-based learning
* discussione di casi di studio e attività di problem-solving nell’area accounting, finance e management, e nell’area giuridica.

Primo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Data Analysis and Statistics  Il corso ha l’obiettivo di fornire gli strumenti quantitativi per lo studio, la descrizione, l’interpretazione e la previsione di un qualsivoglia fenomeno attraverso rappresentazioni grafiche, misure di sintesi, metodi e tecniche inferenziali nonché abilitare lo studente alla costruzione di modelli di base e scenari relativi ad applicazioni in ambito economico (micro e macro) e del management. A conclusione del corso lo studente saprà rappresentare dati economico-aziendali tramite loro sintesi numeriche e grafiche, costruire semplici modelli in grado di esprimere le relazioni tra le grandezze coinvolte, analizzare le tendenze di fondo relative a un fenomeno, cogliere e misurare l’intensità delle relazioni tra le variabili determinanti ed elaborare brevi report statistici. | 8 |
| Introduction to Economics  L’obiettivo del corso è di fornire una conoscenza solida delle nozioni di base della moderna teoria economica. Il corso si basa su un approccio integrato alle teorie micro e macro economiche. Tutti gli aspetti della struttura fondamentale dei sistemi economici verrà presa in esame, in tutte le sue dimensioni: pubbliche e private, reali e monetarie, nazionali e internazionali. Il corso fornirà anche delle nozioni di base di storia economica. Al termine del corso lo studente sarà in grado di: affrontare lo studio dei fenomeni economici con una solida preparazione di base dei concetti della teoria economica contemporanea; applicare in modo critico le nozioni apprese nel corso delle lezioni, comprendendo sia i punti di forza che i limiti degli approcci che sono proposti. | 12 |
| Mathematics  Il corso ha l’obiettivo di avvicinare agli studenti ai concetti e ai metodi necessari per comprendere, descrivere e analizzare la struttura matematica dei fenomeni economico-manageriali. A tal proposito, nel corso delle lezioni, sarà posta particolare attenzione ai fondamenti del calcolo differenziale per le funzioni di una o più variabili, alle procedure di ottimizzazione libera e vincolata nonché alle basi dell’algebra lineare. Le conoscenze acquisite saranno poi elaborate e tradotte in strumenti operativi tramite esercitazioni in aula. A conclusione del corso ci si attende che lo studente sappia utilizzare in modo appropriato gli strumenti della geometria, del calcolo differenziale e dell'ottimizzazione acquisiti nell’analisi/formulazione di modelli per i diversi fenomeni incontrati nell’economia e nel management. | 12 |
| Introduction to Law and Regulation  Alla fine del corso, gli studenti conosceranno gli aspetti principali delle istituzioni pubbliche con particolare attenzione ad ambiti quali i servizi finanziari e bancari, public utilities, e regolamentazione ambientale e sicurezza. Inoltre, comprenderanno il ruolo del diritto privato nella strutturazione dei mercati, specialmente per quel che concerne gli entitlement sul commercio e movimento di risorse, e l’assegnazione di rischi e responsabilità. Gli studenti impareranno i principi basilari di diritto pubblico e diritto privato in una prospettiva sovranazionale e comparatistica. Comprenderanno anche gli stretti legami tra questi principi giuridici e le istituzioni economiche. | 12 |
| Introduction to Financial Accounting  Il corso ha l’obiettivo di fornire una prima introduzione ai concetti ed agli strumenti di economia aziendale e sistemi di rendicontazione economico-finanziaria con particolare riferimento al metodo della partita doppia, le principali scritture contabili, l’assestamento e i contenuti degli schemi di bilancio. Alla fine del corso, gli studenti saranno in grado di: riconoscere i fondamenti del bilancio d’esercizio; leggere un bilancio d’esercizio in ottica di analisi; capire l’importanza del sistema informativo all’interno dell’azienda. | 8 |
| Introduction to Computer Programming for Economics and Management  Il corso ha l’obiettivo di avvicinare gli studenti alle conoscenze e agli strumenti necessari per affrontare, in maniera metodologicamente corretta ed efficace, la programmazione strutturata. Nello specifico, si presterà attenzione a fornire conoscenze di base delle architetture di progettazione (diagrammi a blocchi o flow chart, pseudo-codifica in linguaggio naturale) e dei costrutti fondamentali (procedure di input/output, procedure iterative e ricorsive, strutture condizionali e di controllo, subroutine) che caratterizzano la progettazione e l’implementazione di un qualsivoglia codice eseguibile. A fine corso lo studente saprà, in presenza di un problema, tradurre in un codice eseguibile (in R, Python, …) un insieme di passaggi logici e istruzioni che costituiscono la soluzione. Il corso sarà corredato da un bagaglio di esempi significativi di soluzioni a problemi particolarmente rappresentativi nell’ambito delle discipline economico-manageriali. | 6 |
| Inglese B2 | 0 |
| Test di informatica  Lo studente dovrà dimostrare di saper utilizzare gli applicativi informatici di produttività personale (Open Office, Microsoft Office, etc.) a livello ECDL Base o ECDL Start (o equivalente) - 4 moduli base. | 0 |
| Test di matematica  Test che verifica la padronanza degli strumenti di base della logica e della matematica tra le quali: calcolo algebrico elementare: potenze, valore assoluto, polinomi, equazioni e disequazioni di 1° e 2° grado; nozioni fondamentali di geometria analitica: retta, circonferenza, parabola, ellisse e iperbole. | 0 |

Secondo anno
------------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Business and Competition Law  Alla fine del corso, gli studenti conosceranno i concetti basilari del diritto d’impresa e diritto della concorrenza. Inoltre, comprenderanno il ruolo del diritto di proprietà intellettuale e industriale come strumento di incentivo per l’innovazione delle imprese. Gli studenti impareranno i concetti principali di diritto d’impresa in una prospettiva sovranazionale e comparatistica. | 8 |
| Corporate Finance  Il corso ha l’obiettivo di fornire conoscenze legate alla costruzione efficiente di decisioni finanziarie di un'impresa al fine di creare valore a vantaggio dei proprietari e dei creditori. Verranno analizzati i modelli di valutazione dei rischi sopportati dai finanziatori; i criteri di valutazione dei progetti di investimento; le decisioni riguardanti la struttura delle fonti di finanziamento e la sua composizione per strumenti. Alla fine del corso, gli studenti saranno in grado di: analizzare le scelte di investimento e delle fonti di finanziamento; valutare la posizione finanziaria di un'impresa. | 8 |
| Microeconomics  Il corso di basa sulle nozioni di base della teoria microeconomica che lo studente ha appreso nel corso Introduction to Economics. L’obiettivo del corso è di rendere quelle nozioni al tempo stesso più rigorose e più ampie. Tutti gli aspetti della moderna teoria microeconomica verranno affrontati: equilibrio parziale ed equilibrio generale, concorrenza perfetta, concorrenza monopolistica ed oligopolio. Una enfasi particolare verrà posta sulla teoria della scelta in condizioni di incertezza e sulla teoria dei giochi. Al termine del corso lo studente: avrà una conoscenza a livello intermedio di tutti gli argomenti della teoria microeconomica moderna; sarà in grado di applicare in modo autonomo questi concetti allo studio di fenomeni economici concreti; sarà in grado di affrontare lo studio di argomenti avanzati di argomento microeconomico come la teoria dell’organizzazione industriale e l’economia pubblica. | 8 |
| Lab. I: Market Analysis  Il laboratorio ha l’obiettivo di fornire una prima applicazione empirica delle principali variabili che descrivono l’andamento di un mercato (volumi, fatturato, prezzi unitari); delle determinanti della domanda (popolazione, redditi, prezzi di beni complementi/sostituti); della struttura dell’offerta di mercato, il contesto competitivo e i metodi per il loro studio (quote imprese, indici di concentrazione, barriere all’entrata, determinanti dei costi e possibilità di differenziazione. Alla fine del corso, gli studenti saranno in grado di: comprendere, presentare ed elaborare dati con riferimento ai mercati, alla struttura della domanda e dell’offerta; utilizzare dati a fini interpretativi e riconoscerne il contenuto informativo utilizzando le conoscenze teoriche apprese nei corsi di base; descrivere, elaborare e confrontare dati economici di base. | 8 |
| Public Economics  Il corso si basa sulle competenze che lo studente ha acquisito nel corso Intermediate Microeconomics. Il corso ha tre obiettivi principali. In primo luogo, intende fornire una trattazione rigorosa dell’economia normativa e una introduzione alla letteratura sulle decisioni collettive. In secondo luogo, presenterà una discussione dei fallimenti del mercato e delle ragioni economiche per l’intervento dello stato in economia. Infine, presenterà la teoria moderna della tassazione. Al termine del corso lo studente sarà in grado di: comprendere e discutere in modo critico le ragioni principali per l’intervento dello stato in economia; utilizzare gli strumenti della moderna teoria microeconomica per discriminare tra modelli alternativi per interpretare l’evidenza empirica; valutare politiche pubbliche alternative alla luce di criteri di equità ed efficienza. | 6 |
| Macroeconomics  Il corso si basa sulle nozioni di base della teoria macroeconomica lo studente ha appreso nel corso Introduction to Economics. Lo scopo del corso è di rendere queste nozioni allo stesso tempo più rigorose e più ampie. Il corso coprirà argomenti come la teoria della crescita e del ciclo economico e le loro implicazioni per fenomeni macroeconomici come la disoccupazione, la disuguaglianza e l’inflazione. Sia l’approccio neoclassico che quello neokeynesiano saranno coperti dal corso, con una attenzione particolare alle loro diverse implicazioni sul piano delle politiche pubbliche. Al termine del corso lo studente sarà in grado di: accedere ai principali dati ed indicatori macroeconomici ed utilizzarli in modo critico per l’analisi di fenomeni economici reali; acquisire in modo autonomo le nozioni delle principali teorie macroeconomiche, comprendendone le complementarietà e le differenze; valutare le diverse teorie sulla base dell’evidenza empirica disponibile. | 8 |
| Organization  Il corso ha l’obiettivo di introdurre gli strumenti concettuali e terminologici per interpretare il fenomeno organizzativo in chiave di soluzione a problemi di interdipendenza tra decisori, evidenziandone i caratteri relazionali e di processo. Alla fine del corso, gli studenti saranno in grado di: interpretare i principali problemi di governo, coordinamento e struttura dell’impresa; riconoscere i sintomi che caratterizzano i principali problemi organizzativi. | 8 |
| Statistical Inference  Il corso ha l’obiettivo di avvicinare gli studenti allo studio dei moderni metodi inferenziali e alla loro applicazione in ambito economico-sociale. Cuore del corso sarà costituito dalle procedure di stima (puntuale e intervallare), dai test per la verifica di ipotesi, dall’analisi dell’associazione tra variabili qualitative e dalla regressione lineare e logistica con gli annessi aspetti inferenziali. Alla fine del corso lo studente saprà modellare l’associazione tra variabili qualitative e quantitative con un approccio che enfatizza i concetti e le applicazioni in ambito economico-sociale, affrontare analisi empiriche che impiegano strumenti statistico-inferenziali con l’utilizzo del software R, impostare e sviluppare stime che fanno uso di dati binari ed elaborare brevi report statistici relativi alle analisi svolte. | 8 |

Terzo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Industrial Economics  L’obiettivo del corso è quello di fornire le basi analitiche per la comprensione della strategia delle imprese e delle dinamiche competitive dei mercati. I temi saranno analizzati alla luce dei risultati della moderna teoria dell’organizzazione industriale, fornendo agli studenti gli schemi, i concetti e gli strumenti utili per inquadrare i problemi connessi al funzionamento dei mercati e alle decisioni delle imprese. Saranno pertanto discussi gli strumenti teorici e applicativi utili all’analisi del funzionamento delle interazioni strategiche fra le imprese e delle loro relazioni con la politica industriale e la regolamentazione a tutela della concorrenza. Al termine del corso lo studente sarà in grado di: di individuare e spiegare i fattori che influenzano la struttura dei mercati; di analizzare i comportamenti e le condotte strategiche delle imprese in contesti concorrenziali; di comprenderne le implicazioni in termini di politiche industriali, di promozione e tutela della concorrenza e di regolamentazione. Lo studente sarà inoltre in grado di analizzare e discutere i processi competitivi di specifici settori industriali, di interpretare criticamente i comportamenti delle imprese e di discuterne le implicazioni in termini di policy. Il riferimento a casi reali stimolerà la capacità dello studente di discutere su fatti concreti riferiti all'economia reale. | 6 |
| Corporate Strategy  Obiettivo del corso è fornire agli studenti gli strumenti e le capacità per analizzare e comprendere le fonti del vantaggio competitivo in settori ad elevata competitività e caratterizzati da rapidi mutamenti delle condizioni di mercato. Il corso analizzerà le basi teoriche della strategia aziendale e guiderà gli studenti nell’analisi di casi aziendali stimolando il dibattito in classe e promuovendo un approccio critico verso la risoluzione di problemi di corporate strategy. Alla fine del corso gli studenti saranno in grado di: analizzare e comprendere i diversi livelli di strategia aziendale (corporate, business e funzionale) di un’azienda; individuare mission, vision e strategia di un’azienda nonché le modalità di formazione delle decisioni strategiche; analizzare l’ambiente esterno in cui opera un’azienda e metterlo in relazione al bagaglio di risorse e competenze per valutare le basi del vantaggio competitivo; individuare e discutere i punti di forza e debolezza di una strategia; utilizzare i fondamenti teorici della strategia e saperli applicare nell’analisi di casi aziendali. | 8 |
| Economic History  Lo scopo del corso è di introdurre gli studenti allo studio dello sviluppo dei principali sistemi economici: ciò che li rende diversi e quali sono le variabili (sociali, culturali, istituzionali) che ne determinano la crescita o la stagnazione nel lungo periodo. Il corso discuterà inoltre le motivazioni sottostanti alle scelte degli attori economici e di come queste scelte sono influenzate dal contesto storico. Il corso conterrà infine una discussione approfondita di alcuni momenti fondamentali della storia economica moderna e contemporanea come la Rivoluzione Industriale, il processo di globalizzazione e le principali crisi finanziarie. Al termine del corso gli studenti saranno in grado di: valutare l’impatto degli eventi storici sui processi economici di sviluppo; isolare e comprendere le determinanti principali dei processi storici; mettere in relazione le competenze storiche acquisite nel corso delle lezioni con la teoria economica appresa in altri corsi. | 6 |
| Lab. II: Selected Topics in Economics and Management  Il corso ha tre principali obiettivi. Il primo è quello di fornire agli studenti gli strumenti necessari alla stesura di un documento scientifico (elaborato scritto): definizione di una domanda di ricerca; individuazione di un framework teorico appropriato; reperimento delle fonti di dati (di osservazione o sperimentali); predisposizione di semplici analisi empiriche; stesura di conclusioni ed implicazioni di policy. Gli studenti saranno guidati nella scelta del tema oggetto del paper che dovranno redigere alla fine del corso, attraverso una serie di lezioni introduttive a tematiche molto discusse nel dibattito pubblico e con rilevanti implicazioni economico-manageriali. A puro titolo esemplificativo: la quarta rivoluzione industriale, le disuguaglianze, la sostenibilità, i moderni sistemi finanziari. L’introduzione degli studenti a tali tematiche, che trovano poco spazio nei corsi standard, costituisce il secondo obiettivo del corso. Terzo obiettivo del corso --fortemente collegato al secondo-- sarà “fare da ponte” con temi approfonditi nei corsi di Laurea Magistrale, così da assicurare una continuità e un orientamento didattico tra la laurea triennale e le LM offerte dal Dipartimento. Alla fine del corso, gli studenti saranno in grado di: individuare i principali riferimenti bibliografici del tema oggetto dell’elaborato scritto; individuare una domanda di ricerca; reperire i dati necessari per predisporre e condurre una semplice analisi empirica sul tema; strutturare un elaborato scritto sul tema, che riporti la domanda di ricerca, la bibliografia principale, una descrizione dei dati e del loro utilizzo e alcune conclusioni e (eventuali) implicazioni di policy. | 8 |
| Insegnamenti a libera scelta | 12 |
| Academic writing | 6 |
| Final exam | 4 |


### Un insegnamento a scelta


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Financial Accounting and Accounting Standards  Il corso ha l’obiettivo di approfondire il tema del bilancio d’esercizio e del sistema informativo aziendale con particolare riferimento alle valutazioni di bilancio e applicazione delle principali fonti normative: codice civile, principi contabili nazionali e principi contabili internazionali. Alla fine del corso, gli studenti saranno in grado di: redigere e interpretare un bilancio d’esercizio d’impresa; valutare la rispondenza dei bilanci alle norme giuridiche e ai principi contabili; analizzare bilanci sotto il profilo finanziario. | 8 |
| Fundamentals of Marketing  Il corso ha l’obiettivo di fornire le conoscenze di base necessarie per assumere decisioni nel campo del Marketing in aziende profit e non profit al fine di collocare la funzione di marketing rispetto alle altre funzioni aziendali imprese appartenenti al settore B&C. Alla fine del corso, gli studenti saranno in grado di: impostare le principali politiche di marketing; formulare un piano di marketing. | 8 |
| International Economics  Obiettivo: Il corso si propone di analizzare alcuni temi di politica economica in un contesto di economia aperta. Conoscenze: ruolo ed ai compiti delle principali istituzioni internazionali che operano sul piano politico-economico; familiarizzare con il contesto e la complessità delle varie istituzioni, anche con riferimento ai problemi di coordinamento; individuare relazioni tra problemi e istituzioni. Abilità: accedere a fonti relative al funzionamento di istituzioni internazionali; espressione corretta e capacità di sostenere un dibattito in inglese. | 8 |
| Econometrics  Obiettivo: lo scopo del corso è quello di fornire le nozioni di base relative al modello di regressione lineare semplice e multipla applicato sia a dati di tipo microeconomico sia a dati di tipo macroeconomico. Conoscenze: il modello di regressione lineare semplice e multipla. Concetti necessari per l'interpretazione delle stime e delle verifiche di ipotesi relativamente a semplici modelli econometrici, con particolare attenzione alla tipologia dell'informazione statistica campionaria disponibile, sezionale o storica. Il modello di regressione lineare semplice e multipla in relazione sia a dati di tipo microeconomico sia a dati di tipo macroeconomico. Abilità: impiegare e verificare le potenzialità degli strumenti metodologici acquisiti stimando alcune semplici relazioni economiche di interesse. | 8 |








Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 

