
Link utili 
[Eventi di orientamento](https://orienta.unitn.it/)



* Tipo di corso: Laurea di primo livello
* Durata: 3 anni
* Classe del corso: L SNT2, Professioni sanitarie della riabilitazione. Il corso abilita alla professione sanitaria di “Educatore professionale”
* Lingua in cui si tiene il corso: italiano
* Modalità di accesso: programmato, con una prova di ammissione nazionale
* Frequenza delle lezioni: obbligatoria
* Sede: Dipartimento di Psicologia e Scienze Cognitive, Corso Bettini, 84 - 38068 Rovereto (TN)

Il corso di laurea in Educazione Professionale prepara una **figura professionale competente nella promozione del benessere bio-psico-sociale e dell’inclusione sociale**. L'Educatore Professionale lavora con minori, anziani, disabili, emarginati, immigrati, malati mentali, soggetti portatori di dipendenze e persone in situazioni di disagio:

* agisce sulla relazione interpersonale, sulle dinamiche di gruppo, sul sistema familiare, sul contesto ambientale e sull’organizzazione dei servizi;
* opera in un’equipe multidisciplinare in modo coordinato con altri professionisti sanitari e sociali ed in collaborazione con le risorse umane e le organizzazioni di cittadini presenti sul territorio
* formula ed attua ​specifici progetti educativi e riabilitativi per:
  + favorire uno sviluppo equilibrato della personalità
  + sviluppare le potenzialità di crescita personale
  + consentire il recupero alla vita quotidiana
  + promuovere l'inserimento e la partecipazione sociale.

Obiettivi formativi
-------------------

Il corso di studi forma laureati e laureate con competenze specifiche nei seguenti ambiti:

* **competenze relazionali**, intese come saper cogliere e gestire in maniera consapevole il processo evolutivo che si fonda nell'interazione e nel riconoscimento reciproco nell'altro e con l'altro
* **competenze educative e didattiche** nell’area interdisciplinare linguistica, umanistica e informatica, intese come saper insegnare, istruire e far apprendere abilità generali e specifiche che riguardano la globalità degli aspetti dell'individuo
* **conoscenze in ambito psicologico e sociale**, e competenze relative alla lettura di problemi e fenomeni sociali rilevanti per il lavoro educativo
* **competenze metodologiche e di programmazione e organizzazione del lavoro** in contesti territoriali che consentano l'individuazione e la messa in atto di strategie operative, modelli organizzativi e di programmazione, funzionali alla realizzazione degli obiettivi
* **competenze in ambito sanitario e di promozione della salute** finalizzate ad assolvere ai bisogni di cura e ai bisogni assistenziali di base e a promuovere progetti nell'ambito della tutela della salute
* **competenze di lavoro socio-territoriale**, favorendo azioni che promuovano il benessere collettivo.

Questa preparazione rappresenta la base per una autonomia professionale che renda questa figura capace di cogliere i bisogni socio-sanitari emergenti, di progettare interventi innovativi, e di partecipare alla costruzione e implementazione di politiche sociosanitarie in relazione alle tematiche di sua competenza.

Nel fornire le conoscenze di tipo sociale, psicologico, educativo e medico-sanitario un’attenzione particolare è data ai **nuovi bisogni emergenti nei servizi socio-sanitari,** quali:

* le nuove complessità in età evolutiva anche in termini di patologie e ai bisogni crescenti di supporto della genitorialità
* le questioni connesse ai processi di invecchiamento
* i progetti di sviluppo di autonomia abitativa e sociale che coinvolgono soggetti con disabilità o in situazione di marginalità sociale
* la conoscenza di base delle nuove problematiche o di problematiche che si manifestano in modo nuovo quali le dipendenze da gioco d’azzardo, la crescita di disturbi alimentari in adolescenza, le forme di ritiro sociale in adolescenza ed età giovanile, le dipendenze da video-giochi, da alcool e da sostanze in età sempre più precoce, l’autolesionismo.

Centrale è poi lo sviluppo di competenze come:

* la capacità di auto-aggiornarsi sulle questioni emergenti nell’ambito dei servizi socio-sanitari
* la capacità di applicare le metodologie della progettazione educativa sia a livello individuale sia a livello di comunità
* la capacità di lavorare in equipe multidisciplinari, di collaborare con altre figure professionali come gli assistenti sociali e i rappresentanti delle professioni sanitarie.

Profili e opportunità professionali
-----------------------------------

La laurea in Educazione Professionale abilita alla **professione di Educatore Professionale ordinata attraverso uno specifico Albo** all’interno della Federazione Nazionale dell’Ordine dei Tecnici Sanitari di Radiologia Medica e Professioni Sanitarie Tecniche della Riabilitazione e Prevenzione (TSRM-PSTRP).

L’Educatore Professionale svolge la propria attività professionale sia in ambito socio-educativo che in ambito sanitario presso strutture pubbliche e private come:

* Aziende Sanitarie
* Comunità locali
* Comuni
* Aziende di Servizi alla Persona
* Cooperative sociali
* Associazioni di promozione sociale.

La presenza di educatori professionali è un **requisito obbligatorio nei criteri di accreditamento** dei servizi socio-sanitari-educativi, fattore che contribuisce a mantenere alta la domanda di questa figura nel mercato del lavoro.

**Il 100% dei laureati** del corso in Educazione Professionale offerto da UniTrento negli anni 2006-2020 in collaborazione con l’Università di Ferrara **sono occupati dopo un anno** dalla laurea (fonte Almalaurea).

Studi dopo la laurea
--------------------

I laureati in Educazione Professionale possono accedere alla Laurea Magistrale in Scienze riabilitative delle Professioni Sanitarie (LM SNT2).









Il percorso formativo fornisce una **preparazione teorica di base** nelle seguenti aree

* biomedica e di promozione della salute
* psicopedagogica e sociale
* dell'educazione professionale socio sanitaria
* sociologica e dei diritti umani
* interdisciplinare linguistica e informatica.

La formazione teorica si integra in modo efficace con il **tirocinio professionalizzante di 60 crediti** presso strutture esterne sanitarie e socio-educative. A questa integrazione fra preparazione teorica e formazione pratica contribuiscono in modo significativo le figure dei **tutor**, educatori professionali iscritti all’albo, che pianificano e gestiscono le attività di preparazione del tirocinio e ne monitorano lo svolgimento presso le sedi.

La valutazione delle competenze acquisite prende in considerazione sia le conoscenze teoriche sia le abilità operative acquisite dagli studenti e dalle studentesse anche nell'ambito di corsi integrati fra più discipline.

Le modalità di svolgimento della didattica si basano su un modello educativo che promuove l'autoapprendimento e il lavoro di gruppo. Oltre alle lezioni tradizionali sono previsti:

* laboratori interattivi
* simulazioni
* attività di progetto individuali e di gruppo
* attività di approfondimento autogestite
* seminari di approfondimento
* momenti di incontro con altri professionisti dell’area sociale e sanitaria.

Attività formative previste nel 1° anno

  

  

  

| Corso integrato | Modulo | Crediti |
| --- | --- | --- |
| Il ruolo professionale nell’educazione | Il ruolo professionale dell’educatore | 3 |
| Il ruolo professionale nell’educazione | Laboratorio Il ruolo professionale dell’educatore | 3 |
| Psicopedagogia e tecniche di osservazione | Psicologia generale | 4 |
| Psicopedagogia e tecniche di osservazione | Psicologia dello sviluppo tipico e atipico e tecniche dell’osservazione | 4 |
| Psicopedagogia e tecniche di osservazione | Pedagogia sperimentale | 4 |
| Individuo e ambiente: strumenti di lettura | Individuo e ambiente: pensare sociologicamente | 6 |
| Individuo e ambiente: strumenti di lettura | Individuo e ambiente: psicologia dei gruppi e delle organizzazioni | 4 |
| Metodi e tecniche dell’intervento educativo 1 | Narrazione e scrittura per interventi educativi | 3 |
| Metodi e tecniche dell’intervento educativo 1 | Metodi e tecniche dell’intervento educativo: il progetto educativo individualizzato | 4 |
| Fondamenti biologici del comportamento | Basi anatomofisiologiche della persona | 3 |
| Fondamenti biologici del comportamento | Psicofisiologia del sistema nervoso,  processi cognitivi e affettivi, disturbi dell’apprendimento | 3 |
| Fondamenti biologici del comportamento | Principali psicopatologie e modelli di intervento | 4 |
| Tirocinio formativo 1° anno | L’attività non è suddivisa in moduli | 15 |

Attività formative previste nel 2° anno

  

  

  

| Corso integrato | Modulo | Crediti |
| --- | --- | --- |
| Metodi e tecniche dell’intervento educativo 2 | La relazione d'aiuto intersoggettiva | 5 |
| Metodi e tecniche dell’intervento educativo 2 | Educazione e promozione della partecipazione | 3 |
| Metodi e tecniche dell’intervento educativo 2 | Abilità strumentali e formative | 1 |
| Analisi dei bisogni sociosanitari | Patologie neurologiche | 2 |
| Analisi dei bisogni sociosanitari | Neuropsichiatria dell’età evolutiva: principali quadri clinici | 2 |
| Analisi dei bisogni sociosanitari | Processi di invecchiamento e bisogni sociosanitari | 2 |
| Analisi dei bisogni sociosanitari | Comportamento motorio e psicomotricità | 2 |
| Analisi dei bisogni sociosanitari | Radiologia | 1 |
| Analisi dei bisogni psicosocioeducativi | Psicopatologie e bisogni socioeducativi e prevenzione | 3 |
| Analisi dei bisogni psicosocioeducativi | Bisogni ed interventi educativi nell’ambito di famiglie e soggetti in età evolutiva | 2 |
| Analisi dei bisogni psicosocioeducativi | Bisogni ed interventi educativi nell’ambito delle dipendenze | 4 |
| Competenze linguistiche - Lingua Inglese, livello B1 | L'attività non è suddivisa in moduli | 4 |
| Lavoro socio-territoriale | Marginalità e inclusione sociale | 4 |
| Lavoro socio-territoriale | Interventi pedagogici e valutazione | 1 |
| Lavoro socio-territoriale | Laboratorio Interventi pedagogici e valutazione | 1 |
| Lavoro socio-territoriale | Prevenzione sanitaria | 3 |
| Tirocinio formativo 2° anno | L’attività non è suddivisa in moduli | 20 |

Attività formative previste nel 3° anno

  

  

  

| Corso integrato | Modulo | Crediti |
| --- | --- | --- |
| Contesto legislativo, diritto amministrativo e del terzo settore, diritti umani e principi etici | L’attività non è suddivisa in moduli | 4 |
| Tirocinio formativo 3° anno | L’attività non è suddivisa in moduli | 25 |
| Metodi di ricerca e questioni etiche nel lavoro educativo | La dimensione etica nel lavoro con le persone | 3 |
| Metodi di ricerca e questioni etiche nel lavoro educativo | La practice research in ambito educativo | 3 |
| Approcci e metodologie per la promozione della salute | Medicina narrativa per l’educazione professionale | 4 |
| Approcci e metodologie per la promozione della salute | Promozione della salute e prevenzione | 1 |
| Metodi e tecniche dell’intervento educativo 3 | Metodi di progettazione di comunità | 5 |
| Metodi e tecniche dell’intervento educativo 3 | Strumenti e tecniche della progettazione educativa individuale, di comunità e formativa | 4 |
| Corsi a scelta | L’attività non è suddivisa in moduli | 6 |
| Attività preparatoria alla tesi | L’attività non è suddivisa in moduli | 3 |
| Discussione della dissertazione | L’attività non è suddivisa in moduli | 2 |









Per l’ammissione al corso di studio è richiesto un diploma di scuola secondaria di secondo grado o altro titolo di studio conseguito all'estero e idoneo.

L'accesso al corso di studio è a **numero programmato a livello nazionale**: ogni anno viene emanata un decreto che stabilisce i contenuti del bando di ammissione emesso dall’Ateneo, la data e le modalità di svolgimento della prova di ammissione nazionale.

L'accesso al corso di laurea è a numero programmato a livello nazionale, ai sensi della Legge 264/1999. Il numero di posti per l'ammissione, le modalità e il contenuto della prova vengono stabiliti ogni anno con un decreto [Ministero dell’Università e della Ricerca](https://www.mur.gov.it/it) (MUR).  

Le conoscenze richieste per l'accesso al corso di laurea in Educazione Professionale sono definite dalle materie previste per la prova scritta nazionale di ammissione: biologia, chimica, fisica e matematica, conoscenze di cultura generale e ragionamento logico. Agli studenti e alle studentesse ammessi al corso che non raggiungano un prefissato livello di preparazione iniziale, qualora ammessi al corso saranno assegnati obblighi formativi aggiuntivi (OFA), da soddisfare entro il primo anno di corso, attraverso iniziative specifiche deliberate dagli organi competenti.

Ammissione a.a. 2024/2025
-------------------------

La prova di ammissione si svolge il **5 settembre 2024****.**

Non appena definite, le informazioni su scadenze e modalità di iscrizione alla prova di ammissione sono pubblicate alla pagina [Ammissione laurea in Educazione Professionale 2024/2025](https://infostudenti.unitn.it/it/ammissione-educazione-professionale-2024-2025).





Passaggi di corso, trasferimenti e riconoscimento crediti
---------------------------------------------------------

I candidati e le candidate che chiedono di iscriversi al corso con:

* un passaggio di corso
* un trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli

devono presentare la domanda per l'ammissione ad anni successivi secondo le modalità ed entro le scadenze indicate alla pagina [Passaggio di corso, trasferimento e riconoscimento crediti per la laurea in Educazione professionale 2023/2024](https://infostudenti.unitn.it/it/passaggio-di-corso-trasferimento-educazione-professionale-23-24).









 

