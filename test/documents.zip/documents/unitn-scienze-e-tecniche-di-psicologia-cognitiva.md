
![](https://offertaformativa.unitn.it/file/offertaformativa/europsylogo.jpg)



Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/62/scienze-e-tecniche-di-psicologia-cognitiva)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)
* [Orienta: tutti i servizi](http://orienta.unitn.it)
* [Scegliere UniTrento](http://www.unitn.it/ateneo/4/perche-scegliere-unitrento)




* **Livello**: Laurea di primo livello
* **Classe del corso**: L-24 - Scienze e tecniche psicologiche
* **Lingua** in cui si tiene il corso: italiano
* **Modalità di accesso: programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Psicologia e Scienze Cognitive, Corso Bettini, 84 - 38068 - **Rovereto** (TN)

Il corso di laurea in Scienze e Tecniche di Psicologia Cognitiva vuole fornire conoscenze di base e caratterizzanti in **diversi settori delle discipline psicologiche ed in particolare nell’ambito della psicologia cognitiva e dei processi comunicativi**.

Un elemento caratterizzante del corso di studi è la capacità di applicare le **conoscenze teoriche** della psicologia cognitiva all’ambito pratico e al contesto lavorativo. Il laureato sarà in grado di affrontare e **risolvere problemi pratici** nei quali siano coinvolte variabili psicologiche, ideando soluzioni che tengano conto delle conoscenze teoriche della psicologia. Inoltre sarà in grado di sostenere argomentazioni, basate sia sulle conoscenze teoriche sia sulle evidenze empiriche. La **capacità di raccogliere ed interpretare dati psicologici rilevanti** è un ulteriore competenza del laureato in Scienze e Tecniche di Psicologia Cognitiva. Il laureato sarà in grado di esprimere giudizi autonomi di natura tecnica, motivati dalle conoscenze teoriche e dai risultati empirici. Inoltre sarà in grado di contestualizzare tali giudizi rispetto alle questioni scientifiche, sociali o etiche del settore applicativo della psicologia.

Il laureato svilupperà la capacità di **comunicare in maniera efficace il punto di vista della psicologia** a specialisti e non specialisti. In particolare saprà descrivere un problema applicativo da una prospettiva cognitiva, e comunicare le proprie soluzioni all’interno del contesto multidisciplinare nel quale si troverà ad operare.  

Un elemento cruciale della formazione del laureato è la **capacità di apprendimento indipendente e critico**, volta a sostenere studi successivi nell’ambito della psicologia, o a sviluppare strumenti per proseguire in modo autonomo la propria formazione.

Obiettivi formativi
-------------------

Il  corso  di  laurea  in  Scienze  e  tecniche  di  psicologia  cognitiva  vuole  coniugare  **competenze psicologiche ed ergonomiche** con  il duplice obiettivo di  fornire, da una parte, una solida base metodologica per gli studenti che intendono proseguire nella  laurea magistrale  in Psicologia (attivata presso  il Dipartimento) e, dall’altra, di  creare una figura professionale con competenze di natura  tecnico-operativa nell’ambito della psicologia.

Il corso ha ottenuto la certificazione **EuroPsy** che favorisce la mobilità e il riconoscimento del titolo degli psicologi europei.

Profili professionali
---------------------

I laureati in Scienze e Tecniche di Psicologia Cognitiva possono sostenere l'esame per la **sezione B dell'Albo degli Psicologi**, previo tirocinio semestrale post laurea.

Per gli iscritti all'albo degli Psicologi sezione B (settori Ba e Bb) spettano rispettivamente i titoli professionali di:

*  dottore in tecniche psicologiche per i contesti sociali, organizzativi e del lavoro;
*  dottore in tecniche psicologiche per i servizi alla persona e alla comunità.

Tali figure professionali operano in diversi ambienti di lavoro nei quali siano richieste competenze psicologiche. In particolare, possono avere un ruolo nelle organizzazioni lavorative al fine di migliorare la comunicazione tra individui e tra gruppi, o allo scopo di orientare la scelta o la riqualificazione professionale. Infine possono avere un ruolo tecnico all'interno di contesti clinici per ciò che riguarda la caratterizzazione del quadro delle capacità cognitive sia di individui affetti da patologie sia esenti.

Esempi di tali **compiti professionali** sono:

* effettuare ricerche complesse di informazioni utilizzando la rete, eseguire sondaggi e indagini di mercato mediante questionari web-assistiti;
* coadiuvare gli esperti nella costruzione di siti e pagine web e materiali multimediali compatibili con le capacità rappresentazionali e le euristiche di esplorazione degli individui o anche in riferimento a gruppi con specifiche necessità (anziani, portatori di handicap, ecc.);
* concorrere alla elaborazione e applicazione dei test di usabilità delle pagine web e delle altre forme di interazione in ambiente internet;
* risoluzione di problemi di interazione tra singoli o tra gruppi indagando gli aspetti linguistici e/o visivi critici della comunicazione;
* utilizzazione di strumenti psicologici per l’orientamento scolastico-professionale o per la riqualificazione professionale.

Studi che si possono intraprendere dopo la laurea
-------------------------------------------------

La laurea in Scienze e Tecniche di Psicologia Cognitiva fornisce le conoscenze necessarie per accedere:

* alla [Laurea Magistrale in Psicologia](http://offertaformativa.unitn.it/it/lm/psicologia) (nei tre percorsi: Clinica, Neuroscienze e Risorse umane e organizzazioni);
* al [Master's Course in Human-Computer Interaction](http://offertaformativa.unitn.it/it/lm/human-computer-interaction);
* al [Master's Course in Cognitive Science](http://offertaformativa.unitn.it/it/node/1559).









Primo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Psicologia generale  Il corso si propone di far acquisire i principi di base della Psicologia, partendo dallo sviluppo della Psicologia come disciplina scientifica alle moderne neuroscienze. Verranno illustrate e spiegate le principali funzioni mentali, come ad esempio la percezione, la memoria, e l'apprendimento, e i relativi paradigmi sperimentali adoperati per il loro studio. Sarà inoltre messo in luce il nesso tra questi processi cognitivi e le emozioni. Il corso si propone inoltre di fornire gli strumenti concettuali necessari per una visione critica delle teorie affrontate, mettendone in luce punti di forza e debolezza. In generale sarà proposto il metodo scientifico, come approccio sistematico di base comune a tutte le discipline scientifiche. | 9 |
| Basi biologiche del comportamento  Il corso si propone di fornire alle/agli studentesse/studenti i fondamenti dello studio delle basi biologiche del comportamento. Dopo alcuni cenni di biologia della cellula animale, di genetica e di evoluzione, il corso si concentrerà sulla anatomia del sistema nervoso, sulla fisiologia della cellula nervosa, sul ruolo dei neurotrasmettitori, e sul funzionamento dei sistemi sensoriali e motori. | 9 |
| Metodi matematici per le scienze cognitive  Il corso mira a: (i) fornire strumenti matematici, computazionali e cognitivi utili per sviluppare un approccio critico e quantitativo ai fenomeni di natura psicologica; (ii) porre le basi per poter accedere con profitto agli insegnamenti di Psicometria e di Analisi dei Dati con Applicazioni Informatiche. Al termine del corso, le/i partecipanti saranno in grado di ragionare in modo quantitativo su problemi di forte interesse per la psicologia e le science cognitive, combinando nozioni di analisi matematica, algebra vettoriale e calcolo delle probabilità con strumenti di pensiero computazionale, data science e modellistica cognitiva. | 9 |
| Filosofia della scienza  Il corso si propone di fornire solidi strumenti teorico-filosofici per comprendere i processi che portano alla genesi, alla validazione e al superamento di ipotesi scientifiche. Le lezioni intendono fornire un punto di vista critico e problematico sulla ricerca scientifica, all'interno della quale non sussiste una delimitazione scontata e definita una volta per tutte fra ciò che è scienza e ciò che non lo è. Attraverso l'adozione di una prospettiva storica che ripercorre il pensiero dei principali filosofi della scienza del novecento a partire da interrogativi e problemi propri della classicità filosofica, il corso intende inoltre confrontare le/gli studentesse/studenti con un approccio che considera le teorie alla stregua di sistemi in evoluzione che non 'scoprono' da sé i propri problemi e le proprie soluzioni, ma che affrontano, in forme vecchie o nuove, problemi identificati da tradizioni teoriche precedenti, elaborando le proprie soluzioni attraverso modifiche e perfezionamenti progressivi di proposte ereditate dal passato. | 9 |
| Metodi della ricerca in psicologia  L’obiettivo del corso è di introdurre le/gli studentesse/studenti alla psicologia come scienze empirica e ai suoi principali metodi di ricerca. In particolare le studentesse e gli studenti dovrebbero conseguire i seguenti risultati formativi: acquisire le conoscenze di base sui principali metodi di ricerca in psicologia; acquisire una conoscenza di base sulle tecniche di raccolta dei dati quali il questionario e le misure di prestazioni; acquisire una base metodologica per seguire i corsi della triennale; mettere in relazione le teorie psicologiche, la ricerca empirica e la pratica; saper valutare gli aspetti metodologici di una ricerca empirica. | 9 |
| Lingua inglese  Il modulo intende offrire gli strumenti necessari per comprendere i testi in lingua inglese relativi alla professionalizzazione specifica e richiesti nel corso formativo. Particolare attenzione è quindi rivolta allo sviluppo delle abilità di lettura e comprensione di testi e/o ipertesti in lingua inglese relativi alle discipline formative. | 5 |


### Insegnamenti a scelta vincolata: 9 CFU fra i seguenti insegnamenti


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Psicologia della memoria e dell’apprendimento  Il corso si propone di fornire le conoscenze di base relative ai processi di apprendimento e di memoria e di illustrare le principali teorie e i più importanti paradigmi e contributi sperimentali. Ci si attende che alla fine del corso gli studenti e le studentesse abbiano conseguito i seguenti risultati dell'apprendimento: conoscere i metodi, le teorie e le nozioni della disciplina; approfondire e rielaborare in modo autonomo le conoscenze acquisite; mettere in relazione conoscenze teoriche e contesti applicativi; argomentare in modo chiaro e con proprietà lessicale. | 9 |
| Psicologia del linguaggio e della comunicazione  Il corso permetterà di confrontare diversi approcci scientifici allo studio sperimentale di uno stesso fenomeno: il linguaggio. Il corso è strutturato in modo che al termine dello stesso le/gli studentesse/studenti: - abbiano acquisito il lessico specialistico e le nozioni di base in linguistica ed in psicologia del linguaggio di modo da orientarsi agevolmente all’interno di tali discipline per poter approfondire autonomamente specifici argomenti di interesse; - siano capaci di selezionare tra le conoscenze teoriche ed i costrutti acquisiti quelli pertinenti a specifici ambiti della psicologia cognitiva all’interno dei quali gli aspetti linguistici sono rilevanti; - siano capaci di persuadere e dialogare attraverso il linguaggio specialistico della/e disciplina/e oggetto di studio relativamente ai differenti argomenti trattati nel corso. | 9 |
| Psicologia della percezione e dell’attenzione  L’insegnamento ha lo scopo generale di fornire le nozioni teoriche e metodologiche di base per lo studio della percezione e dell''attenzione, e della loro interazione nella formazione di rappresentazioni mentali del mondo esterno. Alla fine del corso, le studentesse e gli studenti dovrebbero: -Conoscere i principali argomenti teorici legati alla percezione e all’attenzione. -Approfondire e rielaborare quanto appreso in modo critico, originale e con linguaggio appropriato. -Comprendere i passaggi chiave di una ricerca nell’ambito della percezione e dell’attenzione. | 9 |

Secondo anno
------------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Fondamenti di neuroscienze cognitive e comportamentali  L'obiettivo del corso è di trattare i fondamenti delle neuroscienze cognitive e comportamentali alla luce delle più recenti ricerche in psicobiologia, psicologia fisiologica, neuroscienze, psicologia cognitiva e neuropsicologia. A fine corso, le/gli studentesse/studenti saranno in grado: • di capire in che modo l’analisi delle strutture e delle funzioni cerebrali attraverso diverse metodologie permette di studiare la cognizione ed il comportamento • di conoscere i meccanismi neurali di alcune funzioni mentali superiori integrando i modelli della psicologia cognitiva con le evidenze empiriche degli studi neurofisiologici e di neuroimmagini • di comprendere le interconnessioni tra i meccanismi neurofisiologici che sottendono le diverse funzioni mentali superiori. | 6 |
| Psicologia sociale  L'insegnamento si propone di fornire le nozioni di base della disciplina che studia i processi sociali e cognitivi che determinano come gli individui comprendano se stessi e il mondo sociale e come si svolge l'influenza e l'interazione sociale fra individui. Al termine del corso gli studenti e le studentesse saranno in grado di: a) conoscere e comprendere le nozioni di base della disciplina con un particolare riferimento alle teorie principali e la metodologia di ricerca della Psicologia Sociale; b) sviluppare un pensiero critico autonomo (discernere, giudicare ed eventualmente mettere in discussione) rispetto ai fenomeni sociali che verranno trattati durante il corso; c) acquisire le capacità di apprendimento necessarie per un processo di apprendimento continuo nella Psicologia e le Scienze sociali. | 9 |
| Psicologia dinamica  Il corso si propone di far acquisire alle studentesse e agli studenti le competenze fondamentali necessarie a comprendere l’impianto teorico e metodologico delle teorie psicodinamiche, facendo particolare riferimento all’applicazione di questi concetti nell’ambito della pratica clinica. I temi dello sviluppo della vita mentale, dell’affettività e della conflittualità intrapsichica verranno esaminati con riferimento sia alla teoria classica freudiana che alle successive elaborazioni del pensiero psicodinamico. Il corso si propone inoltre di favorire la capacità di costruire nessi tra i differenti paradigmi teorici contemporanei e i problemi della pratica clinica che verranno discussi in aula, facilitando la comprensione e la contestualizzazione dei contenuti formativi degli insegnamenti del percorso di studi. | 9 |
| Psicologia clinica  Il corso vuole portare alla conoscenza delle teorie, dei metodi e degli strumenti che consentono allo psicologo di comprendere le problematiche di chi lo consulta. Si forniranno conoscenze sulle caratteristiche dei principali disturbi clinici e sulle loro implicazioni a livello individuale e sociale, si daranno, inoltre, accenni delle diverse applicazioni terapeutiche. | 9 |
| Psicologia dello sviluppo  Lo scopo del corso è fornire le informazioni e le abilità fondamentali per permettere di riflettere in modo competente sui processi, le fasi e le cause dello sviluppo mentale. Particolare attenzione verrà data alle teorie classiche dello sviluppo e alla loro revisione alla luce degli studi recenti. Verranno discusse varie ricerche sperimentali che hanno affrontato i problemi dello sviluppo nelle seguenti aree di indagine: percezione visiva, uditiva e olfattiva, capacità motorie e controllo posturale, capacità di orientamento dell’attenzione, rappresentazione dello spazio, pianificazione, capacità ludiche, cognizione sociale, sviluppo emotivo e affettivo Verranno inoltre discusse le principali tecniche di ricerca impiegate nello studio sviluppo mentale. Ci si propone in questo modo di favorire una comprensione critica delle principali teorie evolutive e un apprezzamento dei notevoli progressi compiuti negli ultimi vent’anni dalla ricerca sperimentale. | 9 |
| Psicometria  Scopo del corso è quello di fornire delle solide basi in teoria della misura in ambito psicologico e nel campo dell’'analisi statistica dei dati, favorendo le conoscenze necessarie per sviluppare adeguate competenze metodologiche e per affrontare lo studio dei principali metodi e modelli statistici utilizzati nelle Scienze Cognitive. La comprensione dei concetti e delle tecniche essenziali della misurazione e della statistica inferenziale costituisce il nucleo indispensabile per l'utilizzazione di metodi scientifici in psicologia e per la lettura critica di libri o articoli inerenti a ricerche in ambito psicologico. Alla fine del corso la/lo studentessa/studente sarà in grado di: interpretare le informazioni di contesto selezionando gli strumenti adeguati all'analisi delle informazioni; identificare i contesti governati dall'incertezza; implementare i metodi di analisi dei dati, i modelli e le tecniche inferenziali per la soluzione di problematiche applicative; valutare criticamente gli strumenti utilizzati. | 9 |

Terzo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Psicologia del lavoro  Il corso si propone di introdurre i concetti di base della psicologia del lavoro. Nello specifico si vuole a) favorire l’acquisizione delle conoscenze e nozioni della disciplina, delle sue aree di studio e di intervento, fornendo elementi per la comprensione dell’interazione tra individuo e ambienti di lavoro, con particolare riferimento all’innovazione tecnologica, ai mutamenti recenti intervenuti nel mercato del lavoro e alle dinamiche organizzative; favorire la capacità di rielaborare le conoscenze apprese in maniera critica e originale e costruire nessi con la pratica professionale. b) Favorire l’acquisizione di competenze comunicative attraverso attività esercitative; favorire l’acquisizione di competenze trasversali (capacità di relazione e attitudine al lavoro di gruppo, proattività e spirito critico). | 9 |
| Analisi dei dati con applicazioni informatiche  Il corso si propone di fornire un’introduzione alle tecniche di analisi dei dati in ambito descrittivo e inferenziale. Una particolare enfasi verrà data sia ai metodi di analisi preliminare dei dati (metodi grafici e di analisi distribuzionale), sia alla scelta dei modelli statistici più idonei per le discipline psicologiche. L'idea principale del corso è quella di rappresentare la pratica dell'analisi dei dati come un processo decisionale multifasico e gerarchicamente organizzato volto a ricavare informazione utile dai dati raccolti. Tale gerarchia, comunque, non è da intendersi come statica, ma bensì, dinamica e ricca di interconnessioni tra i differenti stadi decisionali. | 9 |
| Metodologia della ricerca qualitativa  Il corso si propone di far conoscere ed insegnare ad utilizzare gli approcci metodologici e i principali metodi e strumenti della ricerca qualitativa analizzando le premesse teoriche e metodologiche ad essi sottesi. Gli obiettivi del corso sono: conoscere i presupposti epistemologici della ricerca qualitativa; conoscere le fasi del processo di ricerca qualitativa; conoscere i principali approcci metodologici, con particolare riferimento alla grounded theory; conoscere e saper applicare gli strumenti di ricerca qualitativa (osservazione e intervista); saper formulare una domanda di ricerca e scegliere il metodo più appropriato per indagarla; saper valutare una ricerca qualitativa. | 6 |
| Tirocinio  Attività a frequenza obbligatoria secondo quanto previsto dal regolamento di tirocinio. | 10 |
| Prova finale  La prova finale costituisce un momento formativo che permette di verificare il raggiungimento di capacità di riflessione metacognitiva sulle conoscenze acquisite e di valutare il raggiungimento di un livello iniziale di autonomia adeguato a impostare, redigere e discutere un testo descrittivo/argomentativo su un argomento scientifico. | 3 |


### Insegnamenti a scelta vincolata: 12 CFU fra i seguenti insegnamenti


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Ergonomia cognitiva  Il corso ha lo scopo di introdurre le/gli studentesse/studenti all'applicazione delle scienze cognitive per il supporto del design dell’interazione tra esseri umani e sistemi artificiali (digitali e non). A fine corso le/gli studentesse/studenti avranno acquisito strumenti teorici e pratici per la progettazione e la valutazione di prodotti, servizi, lavori, sistemi e ambienti che siano compatibili con il benessere dell'essere umano, e cioè con l’insieme dei suoi bisogni, limiti, capacità e aspirazioni. | 6 |
| Fondamenti di neuropsicologia  L’obiettivo formativo del corso è fornire un quadro introduttivo alla neuropsicologia cognitiva e clinica che promuova nelle/negli studentesse/studenti (1) la comprensione delle caratteristiche dell'approccio neuropsicologico allo studio della cognizione umana e dei metodi specifici della neuropsicologia; (2) la conoscenza delle principali sindromi e manifestazioni neuropsicologiche; (3) una prima base di capacità analitiche per leggere e comprendere i modelli cognitivi proposti per l’interpretazione dei deficit neuropsicologici. | 6 |
| Personalità e motivazione  Il corso ha l’obiettivo di fornire le basi dello studio scientifico della personalità e della motivazione, viste sia nel loro sviluppo sia nei termini di fattori determinanti dell’agire umano. Scopo dell'insegnamento è di permettere alla/allo studentessa/studente di apprendere le principali teorie della personalità, dalle teorie tipologiche alle teorie dei tratti, dal modello psicodinamico al modello cognitivo-comportamentale; di apprezzare i principali strumenti d'indagine della personalità; e di approfondire i tratti patologici della personalità. La/lo studentessa/studente apprenderà inoltre le principali teorie della motivazione umana e approfondirà il rapporto tra ansia e prestazione. | 6 |
| Plasticità e apprendimento  Il corso si propone di far acquisire alle studentesse e agli studenti le principali nozioni teoriche riguardanti l'apprendimento e la plasticità corticale, sia in condizioni normali che patologiche. A tal proposito verranno illustrati in modo critico gli studi che hanno investigato la plasticità corticale sia attraverso de-afferentazione dell'input sensoriale, sia attraverso una estesa stimolazione, come nel caso dell'apprendimento percettivo. Sarà inoltre affrontato il tema della dipendenza da stupefacenti come esempio di plasticità maladattiva, e saranno messi in luce i meccanismi cognitivi legati all'apprendimento che sono coinvolti in questo tipo di patologia. | 6 |


### Insegnamenti a scelta vincolata: 9 CFU fra i seguenti insegnamenti


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Psicologia del pensiero  Scopo del corso è fornire una panoramica generale dei temi e dei metodi di indagine della psicologia del pensiero. In particolare, saranno illustrate le principali teorie e modelli del ragionamento induttivo e deduttivo. Alla fine del corso ci si aspetta che le studentesse e gli studenti siano in grado di capire la struttura delle decisioni e delle argomentazioni (induttive o deduttive), individuare eventuali bias e fallacie, ed interpretare i risultati di un esperimento che abbia per oggetto i processi di pensiero. | 9 |
| Psicobiologia degli apprendimenti culturali  Il corso intende fornire un approfondimento circa le basi cognitive e neurali di due importanti funzioni cognitive “superiori”: la cognizione matematica e la lettura. Il corso si strutturerà in due parti. La prima parte affronterà i fondamenti cognitivi delle abilità numerico-matematiche, ed i loro correlati neurali, con una particolare enfasi su aspetti evolutivi, sia filogenetici che ontogenetici. La seconda parte tratterà le basi psicobiologiche della lettura. Entrambe i moduli termineranno con l'affrontare le basi neurocognitive delle alterazioni legate a disturbi dello sviluppo, che generano quindi discalculia e o dislessia. In entrambe i moduli saranno costruite le argomentazioni illustrando esempi tratti da ricerche provenienti da ambiti diversi (neuropsicologia, elettrofisiologia, psicofisica, sia sull’uomo che sull’animale non umano), fornendo in questo modo la possibilità alle studentesse e agli studenti di approfondire le proprie conoscenze relative alle diverse metodologie di indagine nelle neuroscienze cognitive. | 9 |

**Insegnamento a scelta libera: 12 CFU**  

Il percorso formativo prevede l’acquisizione di 12 CFU senza vincoli di settore scientifico disciplinare scelti tra gli insegnamenti che vengono appositamente attivati dal Corso di laurea e annualmente pubblicati nel Manifesto degli Studi o tra quelli attivati dall’Ateneo. Queste attività sono di norma offerte al secondo e terzo anno di corso









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione riservata a cittadini e cittadine italiani e dei paesi dell’Unione Europea.

Alcuni posti sono riservati ai cittadini e alle cittadine non europei residenti fuori Italia, assegnati in base al [Bando unico di Ateneo per l’accesso ai corsi di laurea in lingua italiana](https://international.unitn.it/incoming/bachelors-degrees-Italian-non-eu-outside-italy) pubblicato normalmente ogni anno a dicembre.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I candidati e le candidate che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.









 

