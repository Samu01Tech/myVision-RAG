

* **Livello**: Laurea di primo livello
* **Classe** del corso: **L-2 - Biotecnologie**
* **Lingua** in cui si tiene il corso: **Italiano**
* **Modalità di accesso**: accesso a numero **programmato**, con superamento di una prova di ammissione
* **Sede**: Centro di Biologia Integrata, via Sommarive 9, 38123 Povo (TN).

Obiettivi formativi
-------------------

Il corso intende fornire ai laureati gli strumenti necessari a realizzare un approccio conoscitivo integrato ai sistemi biologici. Con questo termine si indica un approccio indirizzato allo studio dell'insieme dei componenti molecolari, dei parametri biologici/fisiologici e delle loro interazioni nei sistemi complessi.

Ai fini indicati, il corso comprende attività formative che permettono:

* di acquisire conoscenze approfondite dei meccanismi genetici di base della cellula e della loro regolazione;
* di acquisire conoscenze approfondite dei componenti strutturali della cellula, del loro ruolo nel mantenimento dell'integrita' cellulare, nella comunicazione cellulare e nella regolazione del metabolismo;- di conoscere e di comprendere le tecnologie utilizzate per la manipolazione genetica;
* di acquisire adeguate competenze di chimica e di fisica, in particolare di integrare i fondamenti scientifici delle metodologie di analisi che caratterizzano le tecnologie biomolecolari;
* di acquisire adeguate competenze di matematica e di informatica, in particolare quelle rivolte all'analisi dei dati;
* di saper utilizzare tutte le informazioni derivanti delle moderne piattaforme biotecnologiche e di applicarle in situazioni concrete per analizzare e comprendere i fenomeni biologici;
* di acquisire adeguate conoscenze delle normative giuridiche e deontologiche e delle problematiche bioetiche.

Profili professionali
---------------------

Il corso di Laurea in Scienze e Tecnologie Biomolecolari prepara alle professioni di:

* specialisti nelle scienze della vita, in particolare biologi, biochimici, biotecnologi alimentari e microbiologi;
* ricercatori e tecnici laureati nelle scienze biologiche.

Studi che si possono intraprendere dopo la laurea
-------------------------------------------------

La laurea in Scienze e Tecnologie Biomolecolari fornisce le conoscenze per accedere alle seguente Lauree Magistrali: Biotecnologie agrarie, Biotecnologie industriali, Biotecnologie mediche, veterinarie e farmaceutiche.









Percorso formativo
------------------

Il corso prevede un unico percorso formativo. I primi due anni sono principalmente dedicati all’acquisizione di conoscenze di base nelle scienze biologiche, chimiche, matematiche, fisiche ed informatiche.   

Il terzo anno è dedicato all’acquisizione di conoscenze avanzate sugli strumenti concettuali e tecnico-pratici delle biotecnologie e della biologia dei sistemi.

Primo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Matematica e Statistica I  Il corso ha l’obiettivo di introdurre il linguaggio della matematica utilizzato nelle scienze biologiche. In particolare vengono trattati i concetti di base dell’analisi matematica in una variabile e dell’algebra lineare. Il corso fornisce inoltre i primi elementi della statistica descrittiva e del calcolo delle probabilità. | 6 |
| Biologia cellulare  Il corso ha come obiettivo quello di fornire le conoscenze di base sulla struttura e funzione dei componenti della cellula, degli organelli e del trafficking cellulare. Inoltre, l'obiettivo del corso è di fornire le conoscenze fondamentali sulla regolazione delle funzioni del citoscheletro e degli organelli in processi cellulari complessi quali il ciclo di divisione cellulare e la morte cellulare programmata. | 9 |
| Chimica generale ed inorganica  Il corso ha l’obiettivo di fornire le conoscenze di base della chimica necessarie per affrontare lo studio dei sistemi biologici. Particolare enfasi viene data alla struttura atomica della materia, alle proprietà̀ chimico- fisiche degli elementi e delle sostanze, alla termodinamica dei processi chimici ed allo studio degli equilibri in soluzione. | 9 |
| Fisica I  Il corso ha l’obiettivo di Fornire le conoscenze di base della fisica e della strumentazione fisica di interesse per le scienze biologiche, nonché della metodologia di indagine empirica. In particolare verranno trattati: grandezze e misure, processi energetici, fondamenti della termodinamica e dell’ottica. | 6 |
| Lingua Inglese B2  Accertamento della conoscenza dell'inglese scientifico, con capacità di comprendere testi scientifici scritti o parlati ad un livello almeno pari al livello B2 del Quadro comune europeo di riferimento per la conoscenza delle lingue. | 3 |
| Chimica organica  Il corso ha l’obiettivo di far acquisire i concetti generali che sono alla base della chimica dei composti organici. In particolare verranno fornite conoscenze sulla struttura, reattività e meccanismi di reazione delle più comuni classi di molecole organiche, privilegiando composti di interesse biologico. | 9 |
| Microbiologia generale  Il corso ha l’obiettivo di fornire conoscenze di base sulle strutture, funzioni ed attività metaboliche dei microrganismi, con particolare riferimento alla biologia e genetica dei virus e dei batteri e al ruolo dei microrganismi come patogeni. | 9 |
| Biologia degli organismi  Il corso ha l’obiettivo di fornire conoscenze di base sugli organismi animali, in termini di evoluzione, diversità, anatomia e fisiologia. | 9 |

Secondo anno
------------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Matematica e Statistica II  Il corso ha lo scopo di fornire i concetti base della statistica inferenziale e di fare acquisire competenze nell'analisi statistica dei dati e nella loro elaborazione informatica. Si introdurranno inoltre gli studenti all'uso di modelli dinamici in biologia. | 6 |
| Informatica  Il corso ha l’obiettivo di introdurre gli elementi fondamentali dell'informatica e della programmazione dei calcolatori e di insegnare a realizzare semplici programmi di analisi dati. | 6 |
| Biochimica  Il corso ha l’obiettivo di fornire le conoscenze di base relative alle biomolecole fondamentali per la formazione e funzionamento delle cellule e alle interazioni molecolari nell’ambiente cellulare. Introdurre alla struttura e dinamica delle proteine in relazione alle possibili funzioni svolte da queste negli organismi viventi (Modulo I) e alla comprensione su base molecolare dei processi metabolici e di trasporto (Modulo II). | 12 |
| Biologia molecolare  Il corso ha l’obiettivo di fornire conoscenze di base sui processi regolativi a livello intracellulare, con particolare riferimento alla trascrizione dei geni, alla traduzione dei trascritti codificanti, e alla regolazione delle proteine stesse (stabilità, attività, localizzazione) tramite modificazioni post-traduzionali. | 9 |
| Immunologia  Il corso consentirà allo studente di acquisire competenze sui meccanismi principali del sistema immunitario adibiti alla protezione dell’organismo umano contro le infezioni e la proliferazione neoplastica. Lo studente potrà comprendere come patogeni extra- e intracellulari e cellule tumorali vengano riconosciuti come estranei ed inducano una complessa e coordinata rete di risposte innate ed adattative capaci di prevenire e/o controllare l'insorgere delle infezioni e dei tumori. | 6 |
| Fisica II  Il corso ha l’obiettivo di fornire le conoscenze di base riguardanti l'elettricità e il magnetismo, con particolare attenzione per gli aspetti rilevanti nelle scienze biologiche. Verranno inoltre forniti le conoscenze di base dei fenomeni ondulatori (come interferenza e diffrazione) e, a livello fenomenologico, alcuni elementi base della fisica moderna. | 6 |
| Chimica fisica e bioanalitica  Introdurre alla comprensione dei principi dei moderni metodi fisici di indagine strutturale ed alle metodologie analitiche bioorganiche, quali le spettroscopie ottiche, la cromatografia, la risonanza magnetica nucleare e la spettrometria di massa. | 6 |
| Genetica  Il corso ha l’obiettivo di far acquisire i meccanismi della trasmissione ereditaria e della ricombinazione genica, le basi molecolari dei sistemi che tutelano la stabilità dei genomi, l’origine, la natura e le conseguenze della variabilità genetica con attenzione alle relazioni esistenti tra genotipo e fenotipo; le principali metodiche di analisi fisica e funzionale dei genomi complessi ed i meccanismi molecolari di regolazione dell’espressione genica. | 9 |

Terzo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Biologia applicata alle Biotecnologie  Modulo Biotecnologie cellulari. Il corso ha l’obiettivo di far acquisire conoscenze dei principi e applicazioni delle metodiche di manipolazione genica in cellule eucariotiche. Fornire i fondamenti teorici ed esperienza pratica delle principali applicazioni biotecnologiche delle colture di cellule animali e delle principali strategie per l’isolamento, l’espressione di proteine di interesse e l’utilizzo delle proteine ricombinanti in ambito biomedico. Modulo Biotecnologie delle cellule staminali. Il corso ha l'obiettivo di fornire le conoscenze di base riguardanti la biologia delle cellule staminali e le loro potenziali applicazioni biotecnologiche. Al termine del corso gli studenti saranno in grado di definire le caratteristiche principali di una cellula staminale, avranno acquisito nozioni di base sulle dinamiche rigenerative che coinvolgono popolazioni di cellule staminali nei diversi tessuti adulti ed avranno appreso le principali applicazioni biomediche basate sull'utilizzo di cellule staminali attualmente disponibili. | 12 |
| Biologia dello sviluppo  Il corso ha l’obiettivo di far acquisire i meccanismi cellulari e molecolari dello sviluppo di invertebrati e vertebrati; i meccanismi molecolari che guidano lo sviluppo embrionale e regolano il differenziamento cellulare; fornire conoscenze sugli organismi modello e risvolti biotecnologici applicati alla biologia dello sviluppo. | 6 |
| Biodiritto e bioetica  Il corso intende fornire una conoscenza della materia del biodiritto e della bioetica. In particolare, il corso è volto a: comprendere il concetto di biodiritto, applicarlo ai diversi ordinamenti, conoscere l'efficacia delle diverse fonti giuridiche italiane ed europee, riconoscere ed analizzare le dinamiche del rapporto tra diritto e scienza, individuare l’incidenza delle questioni etiche sulla regolamentazione giuridica delle tematiche di biodiritto, utilizzare le conoscenze acquisite per comprendere il panorama italiano.. | 6 |
| Fisiologia molecolare  Il corso ha l’obiettivo di far acquisire la conoscenza delle modalità di funzionamento degli organi umani ed animali ed i meccanismi generali di controllo funzionale in condizioni normali e le loro alterazioni in condizioni patologiche. | 6 |
| Biologia computazionale  Il corso ha l’obiettivo di fornire le conoscenze di base della biologia computazionale; di comprendere la logica dei principali algoritmi in ambito di analisi di sequenze, di machine learning, di analisi di dati high-throughput e preparazione di pipeline computazionali; di fornire indicazioni pratiche riguardo l’utilizzo avanzato di database pubblici, di analisi funzionali su liste di geni e di applicazioni di analisi integrate di dati su larga scala.etazione delle norme configuranti i reati nella consapevolezza della loro contestualizzazione. | 6 |
| Esami a scelta libera | 12 |
| Tirocinio  Acquisizione di abilità professionali, svolta presso laboratori dei Dipartimenti e/o Istituti cui afferiscono i docenti del corso o presso laboratori di industrie e/o enti pubblici o privati che operano nei settori biotecnologici di competenza | 6 |
| Prova Finale | 6 |









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.









 

