

Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/56/beni-culturali)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)
* [Orienta: tutti i servizi](http://orienta.unitn.it)
* [Scegliere UniTrento](http://www.unitn.it/ateneo/4/perche-scegliere-unitrento)




* Livello: Laurea di primo livello
* Classe del corso: L-1 - Beni culturali
* Lingua in cui si tiene il corso: italiano
* Modalità di accesso: programmato, con superamento di una prova d'ammissione
* Sede: Dipartimento di Lettere e filosofia, via Tommaso Gar 14, 38122 Trento.

Il corso di laurea in Beni Culturali è articolato in quattro diversi Piani di studio consigliati, chiamati “Carriere”:

* Archeologia
* Archivistica e Biblioteconomia
* Musica e Spettacolo
* Storia dell’arte.

Tutte queste carriere preparano agli studi di laurea magistrale per accedere all’insegnamento.

Per approfondire i contenuti del corso e delle Carriere vai alla pagina [Cosa si studia](cosa-si-studia)

Obiettivi formativi
-------------------

Questi sono i principali obiettivi formativi del corso:

* fornire una solida formazione culturale e storica per i beni culturali;
* offrire un approccio interdisciplinare allo studio, alla valorizzazione e alla conservazione dei beni culturali;
* approfondire, nell'ambito di ciascuna delle carriere, gli aspetti generali delle discipline caratterizzanti, nonché il loro sviluppo storico;
* integrare l'approccio umanistico e storico ai beni culturali con il metodo scientifico e le nuove tecnologie;
* stimolare lo sviluppo delle competenze pratiche e della applicazione di teorie e tecniche acquisite durante il corso;
* fornire la capacità di lavorare in gruppo e di operare con autonomia;
* fornire le competenze necessarie più generali per i vari ambiti professionali (padronanza di una lingua straniera e conoscenza di una seconda lingua straniera, abilità informatiche di base, conoscenza dei fondamenti della legislazione sui beni culturali).

Profili professionali
---------------------

Le professionalità contemporanee e, più in generale, il mondo del lavoro coinvolgono sempre più le conoscenze e le competenze nell’ambito dei beni culturali. Il corso offre dunque una preparazione per intraprendere le professioni più consolidate nei beni culturali, aprendosi anche all’interdisciplinarità. I profili professionali del corso riguardano:

* musei e soprintendenze, per lavori di schedatura e catalogazione, per scavi archeologici, per la didattica, la gestione e la tutela dei beni culturali e territoriali;
* aziende, associazioni e organizzazioni professionali operanti nel settore della tutela, della valorizzazione, della conservazione e della fruizione dei beni culturali;
* archivi, per lo studio e la gestione del patrimonio archivistico;
* biblioteche, biblioteche specializzate, fototeche e videoteche, per la gestione dei servizi;
* enti locali (Comune, Provincia, Regione), settore culturale e pianificazione territoriale;
* case editrici e discografiche.

Il corso di laurea in Beni Culturali offre conoscenze di base che potranno essere impiegate per l’inserimento lavorativo o per un proseguimento degli studi che consenta l’insegnamento e la possibilità di accedere a carriere di livello più alto.

Studi dopo la laurea
--------------------

La laurea in Beni Culturali fornisce le conoscenze necessarie per accedere, presso l’Università di Trento:

* alla laurea magistrale in [Storia dell'arte e studi museali](https://offertaformativa.unitn.it/it/lm/storia-arte-studi-museali)
* alla laurea magistrale in [Quaternario, preistoria e archeologia](http://offertaformativa.unitn.it/it/lm/quaternario-preistoria-e-archeologia#overlay-context=it/login)
* alla laurea magistrale in [Musicologia](http://offertaformativa.unitn.it/it/lm/musicologia#overlay-context=it/lm/quaternario-preistoria-e-archeologia/il-corso)
* alla laurea magistrale in [Scienze storiche](https://offertaformativa.unitn.it/it/LM/scienze-storiche).








Il corso di laurea in Beni Culturali è articolato in quattro diversi Piani di studio consigliati, chiamati “Carriere”.

 Archeologia.
Il percorso prepara allo studio della preistoria e della protostoria, dell’età antica e medievale, e alla tutela del suo patrimonio, attraverso competenze di tipo storico e tecnico, mediante la conoscenza delle pratiche più aggiornate di scavo, di documentazione fotografica e delle nuove tecnologie (GIS e Historical GIS, sistemi informatici, ecc.).
 Archivistica e Biblioteconomia.
Il percorso prepara alle professioni degli archivi e delle biblioteche, fornendo competenze integrate (paleografia, storia, cartografia storica, ecc.), conoscenze sulla tutela del patrimonio librario e documentario, e una spiccata attività pratica e laboratoriale con le istituzioni del settore.
Musica e Spettacolo.
Il percorso offre una conoscenza della storia e delle pratiche della musica e del teatro, preparando alla valorizzazione del patrimonio culturale, alla promozione delle arti performative e alla divulgazione culturale. Esso offre conoscenze storiche, strumenti critici e opportunità di coinvolgimento in attività sul campo.
Storia dell’arte.
Il percorso offre le conoscenze necessarie per lo studio della storia dell’arte, la tutela del patrimonio storico-artistico e le attività di valorizzazione di carattere espositivo, didattico, storiografico e divulgativo. Il tirocinio costituisce un momento formativo centrale, coinvolgendo in modo particolare le istituzioni museali.

Nel primo anno tutte le carriere prevedono le stesse discipline per un totale di 60 crediti formativi universitari (CFU).

A partire dal secondo anno il percorso di studio si diversifica.

Per capire come potrebbe essere articolato il tuo piano di studio e come sono composte le carriere, consulta la pagina [Regolamenti e manifesti](regolamenti-e-manifesti).

Puoi anche scegliere un piano di studi libero e individuale, che deve essere coeren**te** con il Regolamento didattico del corso e approvato dal Coordinatore o dalla Coordinatrice di Ambito Didattico o da un loro delegato, in base al Regolamento del Dipartimento di Lettere e Filosofia.

Il corso, oltre alle lezioni, presenta un’offerta formativa ampia che include varie tipologie di attività:

* attività nei **laboratori del Dipartimento**, presso il Centro Geo-Cartografico di Studio e Documentazione, il LaBAAF, Laboratorio Bagolini di Archeologia, Archeometria, Fotografia, il Laboratorio di Filologia Musicale, Laboratorio di Archivistica e Discipline del Documento, l'Officina Espositiva, ecc
* **esercitazioni** complementari ai corsi seguiti (puoi scegliere fra circa 15 tipologie di esercitazioni)
* **tirocini** per un totale di 150 ore (6 crediti) presso uno tra i moltissimi enti convenzionati in Italia e all’estero.










Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 

