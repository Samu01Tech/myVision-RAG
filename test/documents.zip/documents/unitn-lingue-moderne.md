

Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/58/lingue-moderne)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)
* [Orienta: tutti i servizi](http://orienta.unitn.it)
* [Scegliere UniTrento](http://www.unitn.it/ateneo/4/perche-scegliere-unitrento)




* **Livello**: Laurea di primo livello
* **Classe** del corso: **L-11 - Lingue e culture moderne**
* Lingua in cui si tiene il corso: **italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Lettere e filosofia, via Tommaso Gar 14, 38122 Trento.

Il corso di laurea Lingue Moderne si articola in due percorsi:

* **Letterature, lingue e traduzione (LLT)**, che dedica particolare attenzione alla dimensione delle lingue, della comunicazione e traduzione delle culture e letterature straniere;
* **Lingue per l’intermediazione turistica e d’impresa (LITI)**, percorso di studi maggiormente orientato alle lingue applicate agli ambiti dell’economia e dell’organizzazione turistica.

Il corso intende fornire ai laureati solide basi nella **linguistica teorica** e in **due lingue e le relative culture** da scegliere fra **inglese, francese, spagnolo, russo (solo percorso LITI) e tedesco**.

Le lezioni di lingue, culture e letterature straniere vengono offerte **in lingua originale** sin dal primo anno creando un ambiente proficuo per il raggiungimento di alti livelli di conoscenza sia a livello orale che scritto.  


Obiettivi formativi
-------------------

La laurea in Lingue moderne permettere l’acquisizione degli **strumenti teorici e metodologici** necessari a comprendere fenomeni di natura giuridico-economica, storico-geografica, filologico-letteraria e linguistico-culturale relativi ai Paesi delle lingue di studio.  

I laureati dovranno inoltre acquisire gli strumenti teorici per l’**analisi di testi**, attraverso la conoscenza degli atti e delle funzioni linguistico-comunicative, i principi della linguistica teorica, dell’analisi contrastiva, nonché della traduzione in e dalla lingua prima/italiana.  

Il corso di laurea in Lingue moderne prevede per entrambi i percorsi un ambito comune di acquisizione e consolidamento delle **competenze linguistiche e metalinguistiche** della lingua italiana (scritta e orale), delle lingue e delle culture di studio e dei principali **strumenti informatici** e **metodologici**; saranno centrali inoltre gli ambiti relativi alla **comunicazione**, all’analisi e produzione di **testi scritti** e **orali** e alla teoria e pratica della **traduzione**.  

ltre a queste abilità condivise, gli studenti svilupperanno inoltre competenze specifiche a seconda del percorso scelto:

* nel curriculum in “**Letterature, Lingue e traduzione**” (LLT), a carattere linguistico-letterario, saranno privilegiati gli insegnamenti volti all’approfondimento di strumenti metodologici relativi agli ambiti storico-culturali e filologico-letterari, compreso l’avviamento alla traduzione letteraria e istituzionale;
* nel curriculum “**Lingue per l’intermediazione turistica e d’impresa**” (LITI), sarà privilegiata l’applicazione di competenze linguistiche, nozioni economico-aziendali e conoscenze geografiche dei sistemi territoriali all’ambito della comunicazione interculturale e professionale, a livello nazionale e internazionale, con particolare attenzione per le nuove tecnologie.

Profili professionali
---------------------

Il corso di laurea in Lingue moderne fornisce il complesso delle conoscenze empiriche e delle competenze teoriche, metodologiche e pratiche atte a svolgere l’attività di mediatore linguistico e interculturale, esperto in relazioni pubbliche, esperto linguistico, operatore turistico e d'impresa, traduttore anche multimediale, revisore di testi, consulente per la comunicazione (uffici stampa), collaboratore in ricerche di enti culturali e socio-ambientali, consulente di azienda.  

Le competenze sono linguistiche, comunicative, testuali, traduttive e letterarie, culturali e interculturali, di lettura del territorio sul piano turistico, economico, culturale e istituzionale.  

Il corso prepara alla professione di:

* corrispondenti in lingue estere e professioni assimilate
* tecnici delle attività ricettive e professioni assimilate organizzatori di fiere, esposizioni ed eventi culturali
* organizzatori di convegni e ricevimenti
* animatori turistici e professioni assimilate
* agenti di viaggio guide ed accompagnatori naturalistici e sportivi
* guide turistiche tecnici dei musei tecnici delle biblioteche

Studi che si possono intraprendere dopo la laurea
-------------------------------------------------

Alla fine del percorso triennale lo studente può proseguire gli studi iscrivendosi al corso di laurea magistrale più attinente al percorso seguito nell’ambito della laurea triennale.  

Le lauree magistrali di carattere linguistico offerte dal Dipartimento di Lettere e Filosofia sono:

* corso di laurea magistrale in [Letterature euroamericane, traduzione e critica letteraria](http://offertaformativa.unitn.it/it/lm/letterature-euroamericane-traduzione-e-critica-letteraria#overlay-context=it/l/beni-culturali/studiare-e-frequentare)
* corso di laurea magistrale in [Mediazione linguistica, turismo e culture](http://offertaformativa.unitn.it/it/l/mediazione-linguistica-turismo-e-culture#overlay-context=it/lm/letterature-euroamericane-traduzione-e-critica-letteraria)








Il corso di laurea Lingue moderne è articolato in due percorsi:

* **Letterature, lingue e traduzione** (LLT)
* **Lingue per l'intermediazione turistica e d'impresa** (LITI)

Entrambi i percorsi prevedono lo studio di **due lingue straniere**.

Per il **percorso LLT** si possono **scegliere le due lingue** tra francese, inglese, spagnolo, tedesco.  

Dall'anno accademico 2020/2021 il **percorso LITI** permette di scegliere **anche russo** oltre a **francese, inglese, spagnolo, tedesco**.

E' possibile studiare una **terza lingua** come **attività a scelta** (francese, inglese, russo, spagnolo, tedesco).

Le **lezioni di lingue, culture e letterature straniere** vengono offerte **in lingua originale** sin dal primo anno creando un ambiente proficuo per il raggiungimento di alti livelli di conoscenza sia a livello orale che scritto.  


Insegnamenti comuni ai due percorsi
-----------------------------------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Linguistica generale e glottologia  Obiettivi del corso di Glottologia: Il corso intende fornire le informazioni fondamentali sulle lingue e sui gruppi linguistici che costituiscono la famiglia indoeuropea e sulle caratteristiche della lingua originaria ricostruita sulla base dalla loro comparazione. Ci si prefigge inoltre di introdurre gli studenti alla conoscenza della storia e dei metodi della linguistica storica. Obiettivi del corso di Linguistica generale: Il corso intende rendere accessibili agli studenti che provengono dalle scuole superiori le basi di una disciplina nuova, che richiede tecniche e prospettive di analisi diverse da quelle abituali nello studio letterario e storico. Perciò nel corso verranno affrontati i termini, le nozioni e i procedimenti fondamentali per un'introduzione alla linguistica contemporanea e ai recenti metodi di analisi del linguaggio, in modo da fornire gli strumenti necessari per affrontare lo studio di qualsiasi lingua e per riconoscervi le strutture caratteristiche di suoni, forme, parole e frasi | 12 |
| Letteratura italiana  Conoscenza dei principali codici letterari (stilistici, retorici, metrici) e della loro dimensione storica. Capacità di analisi e interpretazione di testi fondamentali della tradizione letteraria italiana dell’età moderna | 6 |
| Tirocinio  Il tirocinio consiste in un periodo di formazione in azienda, ente o istituzione, ad integrazione del percorso universitario. Attraverso il tirocinio lo/la studente ha la possibilità di mettere in pratica le conoscenze apprese, condividere lo sviluppo di un progetto ed un risultato, fare propri aspetti legati alla professionalità, alle tecnologie e all'organizzazione del lavoro, conoscere le proprie aspirazioni e progettare con più consapevolezza il proprio futuro professionale | 6 |
| Prova di informatica  Le informazioni sono disponibili sul sito [www.testcenter.unitn.it/ecdl/lettere-e-filosofia](http://www.testcenter.unitn.it/ecdl/lettere-e-filosofia) | - |
| Prova finale  La prova finale per il conseguimento della laurea in Lingue moderne consiste nella discussione di un elaborato scritto che lo/la studente prepara in una delle due lingue oggetto di studio. La prova è volta a verificare le capacità di analisi critica e di argomentazione scientifica relativamente all'argomento dato, nonché le competenze linguistico-espositive acquisite nella lingua di studio | 6 |
| A scelta libera | 12 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Lingua francese I  Conoscere e saper analizzare, anche in chiave contrastiva, gli elementi di fonetica, morfologia, sintassi, lessico della lingua standard; comprendere testi autentici su temi noti; interagire in maniera fluida e comunicativa con parlanti di madrelingua, produrre un breve testo scritto descrivendo avvenimenti, esperienze, desideri, e sentimenti e giustificando progetti e opinioni | 12 |
| Lingua spagnola I  Conoscere e saper analizzare, anche in chiave contrastiva, gli elementi di fonetica, morfologia, sintassi, lessico della lingua standard; comprendere testi autentici su temi noti; interagire in maniera fluida e comunicativa con parlanti di madrelingua, produrre un breve testo scritto descrivendo avvenimenti, esperienze, desideri, e sentimenti e giustificando progetti e opinioni | 12 |
| Lingua inglese I  Conoscere e saper analizzare, anche in chiave contrastiva, gli elementi di fonetica, morfologia, sintassi, lessico della lingua standard; comprendere testi autentici su temi noti; interagire in maniera fluida e comunicativa con parlanti di madrelingua, produrre un breve testo scritto descrivendo avvenimenti, esperienze, desideri, e sentimenti e giustificando progetti e opinioni | 12 |
| Lingua tedesca I  Conoscere e saper analizzare, anche in chiave contrastiva, gli elementi di fonetica, morfologia, sintassi, lessico della lingua standard; comprendere testi autentici su temi noti; interagire in maniera fluida e comunicativa con parlanti di madrelingua, produrre un breve testo scritto descrivendo avvenimenti, esperienze, desideri, e sentimenti e giustificando progetti e opinioni | 12 |
| Lingua russa I (solo percorso LITI)  Conoscere e saper analizzare, anche in chiave contrastiva, gli elementi di fonetica, morfologia, sintassi, lessico della lingua standard; comprendere testi autentici su temi noti; interagire in maniera fluida e comunicativa con parlanti di madrelingua, produrre un breve testo scritto descrivendo avvenimenti, esperienze, desideri, e sentimenti e giustificando progetti e opinioni | 12 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Cultura e letteratura francese  L'insegnamento è volto ad affrontare un percorso attraverso le culture, soprattutto Otto-Novecentesche, dei paesi di lingua spagnola, con particolare riferimento a come nelle varie letterature si rifletta l'evoluzione dei paradigmi socio-politici, dei linguaggi (musicali, cinematografici, legati ai nuovi media, etc) e dei saperi artistici, filosofici e variamente culturali | 6 |
| Cultura e letteratura spagnola  L'insegnamento è volto ad affrontare un percorso attraverso le culture, soprattutto Otto-Novecentesche, dei paesi di lingua spagnola, con particolare riferimento a come nelle varie letterature si rifletta l'evoluzione dei paradigmi socio-politici, dei linguaggi (musicali, cinematografici, legati ai nuovi media, etc) e dei saperi artistici, filosofici e variamente culturali | 6 |
| Cultura e letteratura inglese  L'insegnamento è volto ad affrontare un percorso attraverso le culture, soprattutto Otto-Novecentesche, dei paesi di lingua spagnola, con particolare riferimento a come nelle varie letterature si rifletta l'evoluzione dei paradigmi socio-politici, dei linguaggi (musicali, cinematografici, legati ai nuovi media, etc) e dei saperi artistici, filosofici e variamente culturali | 6 |
| Cultura e letteratura tedesca  L'insegnamento è volto ad affrontare un percorso attraverso le culture, soprattutto Otto-Novecentesche, dei paesi di lingua spagnola, con particolare riferimento a come nelle varie letterature si rifletta l'evoluzione dei paradigmi socio-politici, dei linguaggi (musicali, cinematografici, legati ai nuovi media, etc) e dei saperi artistici, filosofici e variamente culturali | 6 |
| Cultura e letteratura russa (solo percorso LITI)  L'insegnamento è volto ad affrontare un percorso attraverso la cultura russa, soprattutto Otto-Novecentesca, con particolare riferimento a come nella letteratura si rifletta l'evoluzione dei paradigmi socio-politici, dei linguaggi (musicali, cinematografici, legati ai nuovi media, ecc.) e dei saperi artistici, filosofici e variamente culturali | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Lingua francese II  Alla fine del corso la/lo studente sarà in grado di comprendere testi autentici sia orali che scritti; saprà interagire in L2 con buona proprietà argomentativa e comunicativa e produrrà testi scritti coesi e coerenti su un’ampia gamma di argomenti | 6 |
| Lingua spagnola II  Alla fine del corso la/lo studente sarà in grado di comprendere testi autentici sia orali che scritti; saprà interagire in L2 con buona proprietà argomentativa e comunicativa e produrrà testi scritti coesi e coerenti su un’ampia gamma di argomenti | 6 |
| Lingua inglese II  Alla fine del corso la/lo studente sarà in grado di comprendere testi autentici sia orali che scritti; saprà interagire in L2 con buona proprietà argomentativa e comunicativa e produrrà testi scritti coesi e coerenti su un’ampia gamma di argomenti | 6 |
| Lingua tedesca II  Alla fine del corso la/lo studente sarà in grado di comprendere testi autentici sia orali che scritti; saprà interagire in L2 con buona proprietà argomentativa e comunicativa e produrrà testi scritti coesi e coerenti su un’ampia gamma di argomenti | 6 |
| Lingua russa II (solo percorso LITI)  Alla fine del corso la/lo studente sarà in grado di comprendere testi autentici sia orali che scritti; saprà interagire in L2 con buona proprietà argomentativa e comunicativa e produrrà testi scritti coesi e coerenti su un’ampia gamma di argomenti | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Filologia germanica I  Lo/la studente approfondirà il quadro delle culture dell’area gallo-romanza in epoca medievale. In particolare acquisirà la capacità di esaminare i testi medievali nella loro specificità e alterità rispetto alla cultura contemporanea, imparando a formulare ipotesi interpretative rispetto alle difficoltà di ricezione da parte del lettore contemporaneo che tali testi presentano | 6 |
| Filologia romanza I (per francesisti)  Lo/la studente approfondirà il quadro delle culture dell’area gallo-romanza in epoca medievale. In particolare acquisirà la capacità di esaminare i testi medievali nella loro specificità e alterità rispetto alla cultura contemporanea, imparando a formulare ipotesi interpretative rispetto alle difficoltà di ricezione da parte del lettore contemporaneo che tali testi presentano | 6 |
| Filologia romanza I (per ispanisti)  Lo/la studente approfondirà il quadro delle culture dell’area ibero-romanza in epoca medievale. In particolare acquisirà la capacità di esaminare i testi medievali nella loro specificità e alterità rispetto alla cultura contemporanea, imparando a formulare ipotesi interpretative rispetto alle difficoltà di ricezione da parte del lettore contemporaneo che tali testi presentano | 6 |
| Filologia slava (solo percorso LITI)  Lo/la studente acquisirà un quadro generale dell’evoluzione linguistico-culturale dallo slavo antico alle lingue slave moderne. In particolare acquisirà modelli di analisi utili a comprendere origine, sviluppo e caratteristiche delle lingue slave, identificandone le principali specificità fonologiche, morfologiche e sintattiche, con particolare riguardo alla lingua russa | 6 |

Percorso Lingue per l'intermediazione turistica e d'impresa
-----------------------------------------------------------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Sociologia dei processi culturali e comunicativi  Utilizzare gli strumenti della sociologia dei processi culturali e comunicativi per la comprensione degli attuali contesti socio-culturali a livello locale, nazionale e internazionale | 6 |
| Tecnologie informatiche per la comunicazione  La comprensione dei concetti di base dell'Informatica per l'individuazione ed applicazione degli strumenti informatici più idonei alle attività individuali e professionali in contesti caratterizzati dalla presenza di numerosi attori ed interazioni complesse, come quello del turismo culturale | 6 |
| Economia politica e aziendale  Comprensione dei principi del comportamento razionale degli operatori economici e dell’influenza esercitata su di esso dal contesto linguisticoculturale, al fine di valutare il funzionamento delle imprese e i meccanismi di regolazione dei mercati di beni e servizi sia dal punto di vista della domanda che dell’offerta. Acquisizione di conoscenze sui grandi movimenti dell’economia utili a comprendere il significato di crescita economica nelle sue fasi di espansione e recessione, di inflazione e deflazione e di economia aperta agli scambi con il resto del mondo. Acquisizione del concetto di impresa come forma singola e in aggregazioni, nonché del concetto di portatore di interesse nelle diverse forme e con applicazione all’ambito turistico. Applicazione del concetto di economicità aziendale e comprensione degli strumenti per la rappresentazione e interpretazione dei fenomeni aziendali in termini contabili, come necessario per essere utenti e interpreti di informazioni contabili che consentano una valutazione del grado di liquidità, redditività e solvenza di un’impresa | 12 |
| Gestione delle imprese  Acquisizione di capacità di analisi e di valutazione delle strategie aziendali, con particolare attenzione al settore di attività dell’impresa, ai concorrenti e al vantaggio competitivo perseguito. Capacità di applicare tali strumenti di analisi alle decisioni strategiche e operative di marketing relative alla politica di prodotto, prezzo, comunicazione e distribuzione di beni e servizi delle imprese | 6 |
| Organizzazione aziendale  Acquisizione di conoscenze riguardanti le principali teorie dell’organizzazione aziendale. Comprensione delle diverse forme organizzative intra e inter aziendali e loro uso secondo i principi di base del design organizzativo. Capacità di applicare tali conoscenze e strumenti di progettazione organizzativa ad imprese e aggregazioni di imprese in diversi contesti socio-economici | 6 |
| Geografia del paesaggio e dell'ambiente  Il laureato acquisirà le competenze necessarie per analizzare criticamente i caratteri naturalistici e antropici di un territorio e il loro stato di qualità mettendone in evidenza gli elementi materiali e immateriali meritevoli di valorizzazione culturale e turistica anche al fine di avanzare ipotesi affinché possano essere programmati interventi idonei in tema di pianificazione paesaggistica, di tutela conservativa dei paesaggi naturali e antropici e di rafforzamento delle identità dei luoghi | 12 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Linguistica francese I  Alla fine del corso la/lo studente sarà in grado di decodificare e codificare un testo specialistico dei settori turistico e d’impresa, in forma orale e scritta, identificandone il genere testuale e gli aspetti lessico-grammaticali. In particolare saprà tradurre un testo specialistico attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà articoli scientifici sui linguaggi specialistici e sarà in grado di produrre contributi su argomenti linguistici | 6 |
| Linguistica spagnola I  Alla fine del corso la/lo studente sarà in grado di decodificare e codificare un testo specialistico dei settori turistico e d’impresa, in forma orale e scritta, identificandone il genere testuale e gli aspetti lessico-grammaticali. In particolare saprà tradurre un testo specialistico attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà articoli scientifici sui linguaggi specialistici e sarà in grado di produrre contributi su argomenti linguistici | 6 |
| Linguistica inglese I  Alla fine del corso la/lo studente sarà in grado di decodificare e codificare un testo specialistico dei settori turistico e d’impresa, in forma orale e scritta, identificandone il genere testuale e gli aspetti lessico-grammaticali. In particolare saprà tradurre un testo specialistico attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà articoli scientifici sui linguaggi specialistici e sarà in grado di produrre contributi su argomenti linguistici | 6 |
| Linguistica tedesca I  Alla fine del corso la/lo studente sarà in grado di decodificare e codificare un testo specialistico dei settori turistico e d’impresa, in forma orale e scritta, identificandone il genere testuale e gli aspetti lessico-grammaticali. In particolare saprà tradurre un testo specialistico attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà articoli scientifici sui linguaggi specialistici e sarà in grado di produrre contributi su argomenti linguistici | 6 |
| Linguistica russa I  Alla fine del corso la/lo studente sarà in grado di decodificare e codificare un testo specialistico dei settori turistico e d’impresa, in forma orale e scritta, identificandone il genere testuale e gli aspetti lessico-grammaticali. In particolare saprà tradurre un testo specialistico attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà articoli scientifici sui linguaggi specialistici e sarà in grado di produrre contributi su argomenti linguistici | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Linguistica francese II  Alla fine del corso la/lo studente utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando linguaggi specialistici dei settori turistico e d’impresa. Inoltre saprà utilizzare le convenzioni accademiche nella stesura di elaborati scientifici | 12 |
| Linguistica spagnola II  Alla fine del corso la/lo studente utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando linguaggi specialistici dei settori turistico e d’impresa. Inoltre saprà utilizzare le convenzioni accademiche nella stesura di elaborati scientifici | 12 |
| Linguistica inglese II  Alla fine del corso la/lo studente utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando linguaggi specialistici dei settori turistico e d’impresa. Inoltre saprà utilizzare le convenzioni accademiche nella stesura di elaborati scientifici | 12 |
| Linguistica tedesca II  Alla fine del corso la/lo studente utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando linguaggi specialistici dei settori turistico e d’impresa. Inoltre saprà utilizzare le convenzioni accademiche nella stesura di elaborati scientifici | 12 |
| Linguistica russa II  Alla fine del corso la/lo studente utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando linguaggi specialistici dei settori turistico e d’impresa. Inoltre saprà utilizzare le convenzioni accademiche nella stesura di elaborati scientifici | 12 |

Percorso Letterature, lingue e traduzione
-----------------------------------------

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Letteratura francese I  Conoscere i generi letterari narrativi attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi narratologica e storico | 6 |
| Letteratura spagnola I  Conoscere i generi letterari narrativi attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi narratologica e storico | 6 |
| Letteratura inglese I  Conoscere i generi letterari narrativi attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi narratologica e storico | 6 |
| Letteratura tedesca I  Conoscere i generi letterari narrativi attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi narratologica e storico | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Lingua e traduzione francese e letteratura francese  Collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. Inoltre comprenderà testi inerenti argomenti letterari, saggi di critica letteraria e di teoria linguistica; saprà interagire con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere letterario. In particolare saprà tradurre un testo letterario in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Oltre ai testi letterari, lo/la studente saprà tradurre anche saggi e documenti di natura linguistica e socio-culturale, relativi ad eventi di natura turistica, di natura istituzionale e politica e testi e documenti connessi agli eventi culturali locali e alle relazioni internazionali. Conoscere diverse tipologie di testi nel contesto dell'evoluzione dei generi teatrali. Acquisire i principali strumenti critici e teorici per un’analisi sincronica di tipo filologico, linguistico e letterario e per lo studio diacronico della ricezione e messa in scena dei testi della letteratura teatrale | 12 |
| Lingua e traduzione spagnola e letteratura spagnola  Collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. Inoltre comprenderà testi inerenti argomenti letterari, saggi di critica letteraria e di teoria linguistica; saprà interagire con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere letterario. In particolare saprà tradurre un testo letterario in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Oltre ai testi letterari, lo/la studente saprà tradurre anche saggi e documenti di natura linguistica e socio-culturale, relativi ad eventi di natura turistica, di natura istituzionale e politica e testi e documenti connessi agli eventi culturali locali e alle relazioni internazionali. Conoscere diverse tipologie di testi nel contesto dell'evoluzione dei generi teatrali. Acquisire i principali strumenti critici e teorici per un’analisi sincronica di tipo filologico, linguistico e letterario e per lo studio diacronico della ricezione e messa in scena dei testi della letteratura teatrale | 12 |
| Lingua e traduzione inglese e letteratura inglese  Collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. Inoltre comprenderà testi inerenti argomenti letterari, saggi di critica letteraria e di teoria linguistica; saprà interagire con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere letterario. In particolare saprà tradurre un testo letterario in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Oltre ai testi letterari, lo/la studente saprà tradurre anche saggi e documenti di natura linguistica e socio-culturale, relativi ad eventi di natura turistica, di natura istituzionale e politica e testi e documenti connessi agli eventi culturali locali e alle relazioni internazionali. Conoscere diverse tipologie di testi nel contesto dell'evoluzione dei generi teatrali. Acquisire i principali strumenti critici e teorici per un’analisi sincronica di tipo filologico, linguistico e letterario e per lo studio diacronico della ricezione e messa in scena dei testi della letteratura teatrale | 12 |
| Lingua e traduzione tedesca e letteratura tedesca  Collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. Inoltre comprenderà testi inerenti argomenti letterari, saggi di critica letteraria e di teoria linguistica; saprà interagire con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere letterario. In particolare saprà tradurre un testo letterario in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Oltre ai testi letterari, lo/la studente saprà tradurre anche saggi e documenti di natura linguistica e socio-culturale, relativi ad eventi di natura turistica, di natura istituzionale e politica e testi e documenti connessi agli eventi culturali locali e alle relazioni internazionali. Conoscere diverse tipologie di testi nel contesto dell'evoluzione dei generi teatrali. Acquisire i principali strumenti critici e teorici per un’analisi sincronica di tipo filologico, linguistico e letterario e per lo studio diacronico della ricezione e messa in scena dei testi della letteratura teatrale | 12 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Filologia germanica II  Approfondire il quadro delle culture germaniche (inglese e tedesca soprattutto) in epoca medievale. In particolare acquisirà la capacità di esaminare i testi medievali nella loro specificità e alterità rispetto alla cultura contemporanea, imparando a formulare ipotesi interpretative rispetto alle difficoltà di ricezione da parte del lettore contemporaneo che tali testi presentano | 6 |
| Filologia romanza II (per francesisti)  Il corso introduce allo studio delle lingue e delle letterature del medioevo romanzo e all’analisi filologico-linguistica di testi di particolare rilevanza storico-culturale dell’area gallo-romanza | 6 |
| Filologia romanza II (per ispanisti)  Il corso introduce allo studio delle lingue e delle letterature del medioevo romanzo e all’analisi filologico-linguistica di testi di particolare rilevanza storico-culturale dell’area ibero-romanza | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 1 esame a scelta tra | Storia moderna II  Acquisizione di una conoscenza generale dei temi della storia moderna fra XV e XIX secolo, nonché degli strumenti analitici necessari per orientarsi nelle vicende istituzionali, sociali e culturali dell'Europa moderna, per comprendere fonti di vario tipo e rapportarsi criticamente alla storiografia | 6 |
| Storia medievale II  Acquisizione di conoscenze di base relative ai quadri politici e istituzionali, al lessico specifico, alle tecniche di esegesi delle fonti e alla conoscenza dei principali indirizzi storiografici | 6 |
| Storia contemporanea II  Analisi e comprensione di processi storici complessi nel tempo (inserendo l'analisi di tempi storici più brevi in un'ottica di lungo periodo) e nello spazio (raccordando la storia nazionale con quella europea e internazionale), cogliendo la complessità e articolazione degli eventi storici, ma essendo in grado di individuare i nodi causali più significativi | 6 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Lingua e traduzione francese  Individuare gli aspetti filologici e linguistici caratterizzanti un testo letterario situandolo nella storia della lingua e della letteratura. Utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando lessici specifici della letteratura e della critica letteraria. Inoltre saprà analizzare e tradurre un’opera letteraria poetica e teatrale attraverso l’applicazione delle correnti teorie della traduzione. In particolare, per quanto attiene la lingua del turismo, verranno analizzati i diversi generi anche in ottica contrastiva e traduttiva. Lo/la studente saprà tradurre anche saggi e documenti di natura linguistica e socio-culturale, di natura istituzionale e politica e testi connessi agli eventi culturali locali e alle relazioni internazionali | 12 |
| Lingua e traduzione spagnola  Individuare gli aspetti filologici e linguistici caratterizzanti un testo letterario situandolo nella storia della lingua e della letteratura. Utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando lessici specifici della letteratura e della critica letteraria. Inoltre saprà analizzare e tradurre un’opera letteraria poetica e teatrale attraverso l’applicazione delle correnti teorie della traduzione. In particolare, per quanto attiene la lingua del turismo, verranno analizzati i diversi generi anche in ottica contrastiva e traduttiva. Lo/la studente saprà tradurre anche saggi e documenti di natura linguistica e socio-culturale, di natura istituzionale e politica e testi connessi agli eventi culturali locali e alle relazioni internazionali | 12 |
| Lingua e traduzione inglese  Individuare gli aspetti filologici e linguistici caratterizzanti un testo letterario situandolo nella storia della lingua e della letteratura. Utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando lessici specifici della letteratura e della critica letteraria. Inoltre saprà analizzare e tradurre un’opera letteraria poetica e teatrale attraverso l’applicazione delle correnti teorie della traduzione. In particolare, per quanto attiene la lingua del turismo, verranno analizzati i diversi generi anche in ottica contrastiva e traduttiva. Lo/la studente saprà tradurre anche saggi e documenti di natura linguistica e socio-culturale, di natura istituzionale e politica e testi connessi agli eventi culturali locali e alle relazioni internazionali | 12 |
| Lingua e traduzione tedesca  Individuare gli aspetti filologici e linguistici caratterizzanti un testo letterario situandolo nella storia della lingua e della letteratura. Utilizzerà l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta per esprimere, oralmente e in forma scritta, tesi utilizzando lessici specifici della letteratura e della critica letteraria. Inoltre saprà analizzare e tradurre un’opera letteraria poetica e teatrale attraverso l’applicazione delle correnti teorie della traduzione. In particolare, per quanto attiene la lingua del turismo, verranno analizzati i diversi generi anche in ottica contrastiva e traduttiva. Lo/la studente saprà tradurre anche saggi e documenti di natura linguistica e socio-culturale, di natura istituzionale e politica e testi connessi agli eventi culturali locali e alle relazioni internazionali | 12 |

|  | Insegnamento | Crediti (CFU) |
| --- | --- | --- |
| 2 esami a scelta tra | Letteratura francese III  Conoscere i principali generi della letteratura poetica attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi poetologica, metrica e retorica. Alla fine del corso lo/la studente sarà in grado di collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. In particolare saprà tradurre testi letterari, saggistici e argomentativi in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà testi inerenti argomenti storico-culturali letterari, artistici e politici, saggi di critica letteraria e di teoria linguistica; saprà interagire con parlanti di madrelingua con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere argomentativo | 6 |
| Letteratura spagnola III  Conoscere i principali generi della letteratura poetica attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi poetologica, metrica e retorica. Alla fine del corso lo/la studente sarà in grado di collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. In particolare saprà tradurre testi letterari, saggistici e argomentativi in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà testi inerenti argomenti storico-culturali letterari, artistici e politici, saggi di critica letteraria e di teoria linguistica; saprà interagire con parlanti di madrelingua con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere argomentativo | 6 |
| Letteratura inglese III  Conoscere i principali generi della letteratura poetica attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi poetologica, metrica e retorica. Alla fine del corso lo/la studente sarà in grado di collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. In particolare saprà tradurre testi letterari, saggistici e argomentativi in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà testi inerenti argomenti storico-culturali letterari, artistici e politici, saggi di critica letteraria e di teoria linguistica; saprà interagire con parlanti di madrelingua con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere argomentativo | 6 |
| Letteratura tedesca III  Conoscere i principali generi della letteratura poetica attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi poetologica, metrica e retorica. Alla fine del corso lo/la studente sarà in grado di collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. In particolare saprà tradurre testi letterari, saggistici e argomentativi in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà testi inerenti argomenti storico-culturali letterari, artistici e politici, saggi di critica letteraria e di teoria linguistica; saprà interagire con parlanti di madrelingua con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere argomentativo | 6 |
| Lingue e letterature angloamericane  Conoscere i principali generi della letteratura poetica attraverso l’analisi di testi primari e di riflessione teorica. Acquisire i principali strumenti critici e teorici per un’analisi poetologica, metrica e retorica. Alla fine del corso lo/la studente sarà in grado di collocare un testo nella tradizione letteraria identificandone il genere e l’epoca attraverso lo studio e l’analisi della lingua. In particolare saprà tradurre testi letterari, saggistici e argomentativi in prosa attraverso l’applicazione delle recenti teorie della traduzione e l’analisi linguistica dei diversi livelli e registri della comunicazione orale e scritta. Inoltre comprenderà testi inerenti argomenti storico-culturali letterari, artistici e politici, saggi di critica letteraria e di teoria linguistica; saprà interagire con parlanti di madrelingua con buona proprietà argomentativa e comunicativa; infine, produrrà testi scritti su argomenti di carattere argomentativo | 6 |









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 

