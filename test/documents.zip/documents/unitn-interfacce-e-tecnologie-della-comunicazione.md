
![](https://offertaformativa.unitn.it/file/offertaformativa/consulta_education_logo_0.gif)



Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/61/interfacce-e-tecnologie-della-comunicazione)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)




* **Livello**: Laurea di primo livello
* **Classe del corso**: L-20 - Scienze della comunicazione
* **Lingua** in cui si tiene il corso: italiano
* **Modalità di accesso: programmato**, con superamento di una prova di ammissione
* **Sede**: Dipartimento di Psicologia e Scienze Cognitive, Corso Bettini, 84 - 38068 - **Rovereto** (TN)

Il corso di studio è stato attivato nell'a.a. 2008/2009 in collaborazione con il centro di ricerca FBK-IRST (Centro per la Ricerca Scientifica e Tecnologica della Fondazione Bruno Kessler).

Il corso ha un carattere **innovativo nel panorama italiano** grazie alla sua caratteristica di integrare aspetti di programmazione, di forte funzionalità e di valore estetico dei prodotti tecnologici.

Il corso ha già ottenuto il riconoscimento dalla Consulta Educational Assorel, attribuito a meno della metà dei corsi di laurea di questo ambito.

Obiettivi formativi
-------------------

Il corso di studio è volto alla formazione di laureati con **competenze negli aspetti tecnico-informatici, cognitivi e sociali della comunicazione mediata dalle tecnologie dell’informazione**.

In Italia esistono poche realtà in cui **si studiano gli aspetti specifici delle tecnologie della comunicazione e dell’interazione uomo-macchina** e quasi mai vengono considerate assieme  le  tre “anime” di quest’area: computer science, scienze cognitive e progettazione di interfacce utente linguistiche, grafche e multi-modali.

Profili professionali
---------------------

Questo corso di laurea fornisce competenze teoriche, metodologiche, sperimentali ed applicative nelle aree fondamentali dell'informatica orientata agli utenti, quindi primariamente **nelle aree delle interfacce della comunicazione tra sistemi e utenti e dell’accesso intelligente all’informazion**e.

In particolare il laureato acquisirà conoscenze legate alla **progettazione**, produzione e valutazione di questi sistemi, sia riguardo il loro impatto sociale, che la loro adeguatezza dal punto di vista della usabilità, utilità, ed accettazione, anche nelle applicazioni con persone con disturbi cognitivo-comunicativi. Il laureato sarà quindi in grado di concorrere alle attività di **pianificazione**, progettazione, sviluppo, direzione lavori, stima, collaudo e **gestione di interfacce e di sistemi per la comunicazione**.

Gli ambiti occupazionali e professionali di riferimento riguardano non solo le **imprese produttrici** nelle aree dei sistemi informatici e delle reti e nelle pubbliche amministrazioni, ma, più in generale, tutte le **organizzazioni e le imprese che utilizzano sistemi informatici finalizzati alla comunicazione con la persona**.

Studi che si possono intraprendere dopo la laurea
-------------------------------------------------

I laureati potranno possono accedere ai livelli superiori di studio nelle aree delle Scienze della Comunicazione, dell’Informatica e delle Scienze Cognitive, in particolare:

* al [Master's Course in Human-Computer Interaction](http://offertaformativa.unitn.it/it/lm/human-computer-interaction);
* al [Master's Course in Cognitive Science](http://offertaformativa.unitn.it/it/node/1559).








Primo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Informatica ed elementi di programmazione I  Il corso costituisce una prima introduzione ai concetti di base dell'informatica con particolare enfasi sulla programmazione, proponendosi quindi di sviluppare competenze nella produzione sistematica di programmi sequenziali. Il corso inoltre enfatizza il controllo della complessità dei sistemi software attraverso tecniche generali come: costruire astrazioni per nascondere dettagli e separare le specifiche dall'implementazione, stabilire interfacce software per permettere la creazione di moduli standard. | 12 |
| Analisi matematica con elementi di algebra  Il corso ha come scopo principale quello di sviluppare strumenti utili per un approccio scientifico ai problemi e fenomeni che la/lo studentessa/studente incontrerà nel proseguimento dei suoi studi. La parte teorica del corso sarà presentata in modo rigoroso ma conciso e accompagnata da una parallela attività di esercitazione volta a favorire la comprensione dei concetti. | 9 |
| Psicologia generale  Scopo del corso è fornire alle/agli studentesse/studenti una panoramica degli ambiti di studio e dei metodi di indagine propri della psicologia sperimentale. | 9 |
| Sociologia della comunicazione  Il corso intende fornire le basi teorico-metodologiche per studiare i processi sociali di comunicazione, approfondire le relazioni tra lo studio della comunicazione e la teoria sociale e analizzare le forme della comunicazione nella vita quotidiana. | 9 |
| Semiotica della rappresentazione visiva  Il corso intende dare una introduzione alle basi del visual design, cioè di quell'insieme tecniche e metodi per la creazione e combinazione di simboli, immagini e parole al fine di creare una rappresentazione visuale efficace del messaggio o dell'idea da comunicare. Una particolare attenzione verrà posta alle rappresentazioni iconiche nelle interfacce grafiche per l'interazione persona-macchina con l'ausilio di simulazioni laboratoriali. L'approccio del corso si basa sulla semiotica figurativa e in esso verrà discusso il concetto di equilibrio visivo in particolare per quanto concerne la progettazione grafica di interfacce utenti WIMP (Windows Icons Menus and Pointing). | 6 |
| Interazione persona macchina con elementi di comunicazione multimodale  Le/gli studentesse/studenti potranno acquisire conoscenza riguardo alle problematiche, ai concetti, modelli e metodi centrali del settore dell'interazione uomo-macchina. Avranno modo di comprendere come i contenuti appresi negli altri corsi del programma di studi, possono essere applicati a problematiche specifiche di progettazione e valutazione di interfacce. | 6 |
| Psicologia del linguaggio e della comunicazione  l corso prende in esame i processi cognitivi coinvolti nell’elaborazione del linguaggio e nella comunicazione. In particolare, verranno esaminati i modelli teorici e le evidenze empiriche relativi alla comprensione e produzione linguistica, considerando i livelli lessicale (delle singole parole), frasale e testuale, e alla comunicazione, anche in riferimento ai nuovi media e alle nuove tecnologie. | 9 |
| Lingua inglese  Il modulo intende offrire gli strumenti necessari per comprendere i testi in lingua inglese relativi alla professionalizzazione specifica e richiesti nei corsi formativi. Particolare attenzione è quindi rivolta allo sviluppo delle abilità di lettura e comprensione di testi e/o ipertesti in lingua inglese relativi alle discipline formative. | 5 |
|


### Un insegnamento a scelta (4 CFU) fra i segenti


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Ulteriori competenze linguistiche - Lingua tedesca  L’obiettivo del corso è di fornire alla/allo studentessa/studente gli strumenti di base per l’utilizzo della lingua nell'ambito specifico di competenza e per lo scambio di informazioni generali, corrispondente a un livello A1. | 4 |
| Ulteriori competenze linguistiche - Lingua francese  L’obiettivo del corso è di fornire alla/allo studentessa/studente gli strumenti di base per l’utilizzo della lingua nell'ambito specifico di competenza e per lo scambio di informazioni generali, corrispondente a un livello A1. | 4 |
| Ulteriori competenze linguistiche - Lingua spagnola  L’obiettivo del corso è di fornire alla/allo studentessa/studente gli strumenti di base per l’utilizzo della lingua nell'ambito specifico di competenza e per lo scambio di informazioni generali, corrispondente a un livello A1. | 4 |
|

Secondo anno
------------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Informatica ed elementi di programmazione II  Il corso costituisce un approfondimento dei concetti informatici con particolare enfasi sulla programmazione, proponendosi quindi di sviluppare competenze nella produzione sistematica di programmi sequenziali. | 12 |
| Linguistica generale e computazionale  Il corso si propone di fornire elementi teorici per l’interpretazione della comunicazione basata su linguaggio e di offrire una introduzione al campo della linguistica computazionale. Verranno altresì poste le basi per lavorare all’uso di strumenti di trattamento del linguaggio. | 9 |
| Logica e ragionamento  Obiettivo principale del corso è fornire alla/allo studentessa/studente gli elementi di base della logica proposizionale e della logica del primo ordine. | 6 |
| Progettazione di interfacce grafiche  Il corso intende fornire gli strumenti di base per comprendere la progettazione di interfacce grafiche partendo dai bisogni degli utenti e dalle regole codificate in uno specifico framework. Alla fine del corso, le studentesse e gli studenti saranno in grado di applicare quanto appreso a livello pratico definendo i bisogni degli utenti in modo strutturato ed elaborando una progettazione grafica aderente ai vincoli del framework per un progetto interfaccia grafica di piccole dimensioni. | 9 |
| Probabilità e statistica  Il corso ha l’obiettivo di fornire una introduzione alla teoria delle probabilità, per permettere agli studenti di comprendere le implicazioni della materia per la modellizzazione e l’analisi statistica. | 9 |
| Fondamenti di Neurotecnologia  Il corso introduce ai concetti fondamentali della neurotecnologia e le sue applicazioni nell'interazione persona-macchina. Un focus specifico è posto sulle tecniche di elettroencefalografia (EEG) per la comunicazione tra cervello e dispositivi tecnologici. Si illustrano diverse tecniche quali il neurofeedback, la stimolazione cerebrale e la sensoristica psicofisiologica. Si incoraggia inoltre una riflessione critica sulle conseguenze sociali ed etiche dell'human augmentation e del transhumanism. | 6 |

Terzo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Ergonomia cognitiva  Il corso si propone di mettere la/lo studentessa/studente in grado di applicare nozioni e paradigmi di psicologia cognitiva all’analisi e progettazione di sistemi interattivi. | 6 |
| Cognizione e comunicazione sociale  Il corso si propone di fornire le basi teorico-metodologiche per studiare i processi cognitivi e sociali di comunicazione e approfondire le relazioni tra lo studio della comunicazione e la teoria sociale. | 6 |
| Laboratorio di interfacce linguistiche  Il corso si propone di fornire strumenti pratici per lo sviluppo di interfacce basate su comunicazione linguistica. | 6 |
| Teorie e tecniche di riconoscimento  Il corso fornirà alla/allo studentessa/studente gli elementi di base della teoria dell’apprendimento automatico (machine learning) e del suo ruolo nella progettazione di sistemi interattivi. | 6 |
| Interazione persona-macchina con elementi di comunicazione multimodale – corso avanzato  Lavorando in piccoli gruppi, le/gli studentesse/studenti potranno acquisire esperienza nell'applicazione delle conoscenze apprese durante il programma di studio alla soluzione di problematiche complesse e realistiche inerenti alcune aree di ricerca applicata in cui sono attualmente impegnati i docenti del corso. | 6 |
| Tirocinio formativo  Attività a frequenza obbligatoria secondo quanto previsto dal regolamento di tirocinio. | 15 |
| Prova finale | 3 |

### INSEGNAMENTI A SCELTA LIBERA

Il percorso formativo prevede l’acquisizione di 12 CFU senza vincoli di settore scientifico disciplinare scelti tra gli insegnamenti che

vengono appositamente attivati dal Corso di laurea e annualmente pubblicati nel Manifesto degli Studi o tra quelli attivati dall’Ateneo.

Queste attività sono di norma offerte al secondo e terzo anno di corso.









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I candidati e le candidate che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.









 

