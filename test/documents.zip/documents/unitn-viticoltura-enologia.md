

[Orientamento](/it/no-index/orientamento "Orientamento")
--------------------------------------------------------


Orientamento


[I nostri studenti](https://orienta.unitn.it/cosa-scegliere/245/viticoltura-ed-enologia)
[Open days, colloqui di orientamento con studenti](https://orienta.unitn.it/)














**Livello**: Laurea di primo livello  

**Durata**: 3 anni  

**Lingua** in cui si tiene il corso: **Italiano  

Modalità di accesso**: **programmato**, con superamento di una prova di ammissione  

**Sede**: le lezioni e le attività didattiche si svolgono presso il Centro Agricoltura Alimenti Ambiente (C3A) dell’Università degli Studi di Trento, presso la Fondazione Edmund Mach, via Mach, 1 - 38010 - San Michele all’Adige (Tn).

### Obiettivi formativi

Il laureato in Viticoltura ed Enologia sarà in possesso di un'adeguata conoscenza delle materie caratterizzanti ed in particolare quelle **agronomiche**, **genetiche**, **fitoiatriche** e delle **tecnologie enologiche**.

Il laureato avrà inoltre la capacità di riconoscere e gestire i fattori biotici (animali, vegetali, microrganismi) e abiotici (atmosfera, idrosfera, litosfera) dell'agro-ecosistema, nonché quelli connessi ai processi di trasformazione delle materie prime, saprà programmare e gestire tutti gli aspetti relativi alla produzione in campo e alla trasformazione in cantina delle materie prime del settore vitivinicolo. Conoscerà i contesti aziendali e gli aspetti economici propri del settore vitivinicolo e in generale anche di quelli del settore agro-alimentare.

Le conoscenze e competenze, anche a livello operativo di laboratorio, verranno acquisite nei settori agrario e microbiologico, in particolare nel controllo di qualità dei prodotti viticolo-enologici, nell'analisi di matrici biologiche e dei terreni agrari.

Il laureato avrà inoltre appreso:

* il metodo scientifico d’indagine e sarà in grado di collaborare alla sperimentazione per giungere alla soluzione di problemi applicativi del settore vitivinicolo
* il metodo scientifico d'indagine ed essere in grado di collaborare alla sperimentazione, per giungere alla soluzione di problemi applicativi del settore vitivinicolo
* i criteri per operare scelte volte a ridurre l'impatto ambientale dell'attività sia viticola che enologica
* la capacità di recepire i processi innovativi e di trasferirli tempestivamente al settore produttivo
* gli aspetti gestionali e normativi del settore, inclusa la capacità di inquadrarli a livello nazionale e internazionale
* gli strumenti cognitivi di base per la formazione e l'aggiornamento continuo delle proprie conoscenze.

### Profili professionali

Il laureato trova collocazione nel settore vitivinicolo, dove ricopre ruoli di gestione nell’intera filiera produttiva, dall'impianto e dalla conduzione agronomica e fitoiatrica del vigneto, alla produzione dell'uva, alla sua trasformazione, ai controlli di qualità e al marketing.

Gli sbocchi professionali possono comprendere la figura di addetto, dipendente, collaboratore o consulente, in forma singola o associata, di:

* imprese ed aziende nella filiera vitivinicola
* enti territoriali, pubblici o privati
* associazioni settoriali nell'ambito vitivinicolo
* commercio all'ingrosso di vino e derivati e commercio al dettaglio in esercizi specializzati di vino e derivati
* distribuzione alimentare
* editoria e informazione tecnico scientifica in materia di vino
* strutture alberghiere e della ristorazione
* centri/enti di ricerca e sviluppo sperimentale nel campo della viticoltura e dell’enologia.

### Studi dopo la laurea

La laurea in Viticoltura ed Enologia è una **laurea professionalizzante** e pertanto permette di entrare direttamente nel mondo del lavoro.

È altresì possibile **proseguire gli studi** iscrivendosi a **Lauree magistrali** che richiedano come requisiti di ammissione il diploma di laurea triennale CL-25, con necessità di integrazione di specifici CFU se l’ambito si discostasse da quello vitivinicolo.

Il laureato potrà anche iscriversi a **master di primo livello** o **executive master**.

Successive **specializzazioni** si possono acquisire con **stage**, frequenza presso **laboratori** di Enti di ricerca e/o Università.

Il laureato in Viticoltura ed Enologia potrà trovare occupazione e crescita professionale anche nel **settore della ricerca e dello sviluppo** di aziende specializzate nella produzione di coadiuvanti e prodotti per l’industria enologica, di macchinari e tecnologie per la vitivinicoltura, nonché nell’industria enologica stessa.








Link utili 
[Tasse universitarie](http://infostudenti.unitn.it/it/tasse)
[Borse di studio e agevolazioni](http://infostudenti.unitn.it/it/borse-di-studio-e-agevolazioni)



La struttura didattica del Corso di laurea in Viticoltura ed Enologia è elaborata sulla base delle linee guida proposte dall'Organisation Internationale de la Vigne et du Vin (OIV, Parigi), rispecchiando quella dei corsi universitari analoghi di altri paesi europei e comprendendo, oltre a discipline di base, discipline caratterizzanti, affini e integrative per lo più a carattere professionale e tecnico, nonché altre attività formative.

Il Corso di laurea si articola in **tre anni**.

Durante il **primo anno** lo studente acquisisce le conoscenze di base mediante lezioni teoriche ed esercitazioni in aula e in laboratorio.

Nel **secondo anno** alle lezioni teoriche delle materie caratterizzanti si affiancano laboratori, seminari, attività di campo e viaggi di studio.

Nel **terzo anno** si completa lo studio delle materie caratterizzanti ed affini, si svolge un tirocinio pratico-applicativo e si realizza un elaborato finale.


### Primo anno


| Insegnamenti e obiettivi formativi | Crediti (CFU) |
| --- | --- |
| **Matematica e statistica**  Il corso si focalizza sui concetti base dell'analisi matematica e della statistica descrittiva e inferenziale. L'obiettivo principale del corso è fornire agli studenti metodi di calcolo basilari nei campi dell'analisi matematica e della statistica. Nello specifico, la parte di analisi matematica include funzioni, limiti, derivate e integrali, mentre la parte relativa alla statistica comprende concetti base di statistica descrittiva, probabilità, distribuzioni e verifica delle ipotesi. | 6 |
| **Fisica**  Definire operativamente e/o con leggi le principali grandezze fisiche, le loro unità di misura, riconoscendo il ruolo dei sistemi di unità di misura. Caratterizzare grandezze scalari e vettoriali e relative operazioni. Riconoscere il ruolo dell’esperimento in fisica. Compiere stime numeriche di grandezze fisiche. Conoscere le leggi principali degli ambiti tematici: meccanica, fisica dei fluidi, termodinamica, ottica e elettricità e magnetismo. Saperle applicare in semplici attività di problem solving, nella descrizione di fenomeni quotidiani, di processi fisiologici e/o di semplici apparati e strumenti. | 6 |
| **Biologia generale ed Ecologia**  **Modulo Biologia Generale**. L'obiettivo del modulo è di fornire agli studenti le nozioni di base della biologia, un argomento fondante di gran parte degli insegnamenti dell'anno in corso e degli anni successivi. Il modulo introdurrà i principali temi portanti della biologia: 1) l'evoluzione, intesa come processo unificante della biologia 2) la biochimica e lo studio delle principali macromolecole biologiche; 3) la citologia generale con lo studio delle principali strutture cellulari e delle loro funzioni; 4) lo studio dei principali processi metabolici e fisiologici nei vegetali e negli animali 5) la genetica con nozioni di genetica classica e di genomica.  **Modulo Ecologia**. L'obiettivo del modulo di è di presentare agli studenti gli aspetti principali della biodiversità, fornendo gli strumenti necessari allo studio degli ecosistemi e del loro cambiamento nello spazio e nel tempo. Il modulo introdurrà i temi legati a:   1. l'ecologia di base e le interazioni biotiche e abiotiche all'interno degli ecosistemi. 2. la biodiversità animale, vegetale e microbica, con l'obiettivo di comprendere la varietà di forme e di funzioni all'interno degli ecosistemi. 3. le principali applicazione genetiche allo studio della biodiversità come filogenesi, orologio molecolare, genetica di popolazione, barcoding e metagenomica. | 12 |
| **Chimica generale e inorganica**  Fornire allo studente gli strumenti basilari della chimica per poter comprendere la struttura e le proprietà chimico-fisiche della materia, razionalizzare le possibili trasformazioni delle sostanze. Essendo l’insegnamento propedeutico alla chimica organica e alle chimiche applicate del settore agroambientale, sono oggetto di particolare attenzione i concetti della struttura atomica, la descrizione dei legami chimici, la struttura molecolare, le interazioni inter-molecolari, gli stati di aggregazione della materia. Con l’uso delle grandezze termodinamiche è presentato l’equilibrio delle reazioni chimiche in particolare quelle acido/base e ossido/riduttive di solubilizzazioni di soluti nelle soluzioni acquose. | 6 |
| **Economia e gestione aziendale**  Il filo conduttore del corso è rappresentato dalla comprensione dell’impresa quale istituzione finalizzata alla creazione di valore e inserita in ambiente competitivo. Gli obiettivi formativi prioritari consistono nel fornire allo studente: una buona comprensione del funzionamento del mercato soprattutto dei meccanismi di formazione del prezzo e delle loro ricadute sul benessere dei consumatori; una capacità di leggere le decisioni economiche dell’impresa; la conoscenza delle tipologie di costi e delle più importanti tecniche di gestione manageriale. | 6 |
| **Chimica Organica**  Lo studente è introdotto a conoscere i modelli di rappresentazione stereochimica delle molecole organiche e le più semplici regole di nomenclatura. Lo studio è organizzato in base alla classificazione dei gruppi funzionali. Si rimarca l’apprendimento delle caratteristiche acido-base dei composti organici e delle forze intermolecolari che ne determinano lo stato di aggregazione e la solubilità in acqua. Vengono presentati i concetti di risonanza, elettrofilo, nucleofilo e gruppo uscente che sono fondamentali per la comprensione delle reazioni sia di trasformazione funzionale che di formazione dei legami carbonio-carbonio. Lo studente si esercita a descrivere alcuni meccanismi di reazione dando rilievo agli effetti di equilibrio e catalisi. | 6 |
| **Arboricoltura generale, principi di fisiologia e genetica delle piante da frutto**  L’obiettivo generale di questo insegnamento è fornire agli studenti le nozioni principali inerenti il ruolo della arboricoltura nell’agricoltura moderna. La prima parte del corso riguarderà i concetti di base dell’arboricoltura generale, dove verranno spiegate le principali strutture dell’albero e le varie forme di allevamento, oltre che di potatura, per un migliore controllo della fruttificazione della pianta. In questa parte verranno anche trattati argomenti inerenti la vocazionalità ambientale ed i principi del vivaismo. Nella seconda parte del corso verrà invece trattata la fisiologia della pianta, con particolare attenzione sui vari ormoni e bioregolatori che controllano lo sviluppo della pianta stessa. Parte fondamentale di questa sezione del corso è lo studio del ciclo ontogenico, in cui verranno illustrati i vari processi di maturazione del frutto ed il loro legame con la definizione della qualità dei frutti. L’ultima parte del corso riguarderà invece i principi di miglioramento genetico della pianta da frutto e la loro applicazione per una frutticoltura più performante e sostenibile.  Al termine del corso, lo studente:   * sarà a conoscenza del ruolo dei principi dell’arboricoltura moderna * comprenderà le varie tecniche colturali volte all’allevamento della pianta secondo le più recenti modalità colturali * avrà la possibilità di conoscere i vari processi fisiologici alla base dello sviluppo e maturazione dei frutti, ed al ruolo che questi hanno nella definizione della qualità dei frutti stessi * comprenderà il ruolo del postraccolta nella moderna frutticoltura e nel mantenimento della qualità dei frutti * conoscerà le principali strategie di miglioramento genetico per il miglioramento delle caratteristiche qualitative del frutto e la performance del postraccolta * verrà informato sui moderni approcci biotecnologici volti all’ottenimento di ideotipi superiori | 6 |
| **Microbiologia generale con esercitazioni di laboratorio**  L’insegnamento si propone di fornire allo studente le conoscenze relative alla microbiologia generale che riguardano la struttura e la funzione di batteri, archeobatteri, funghi, oomiceti ed entità acellulari; oltre che aspetti riguardanti il metabolismo e la riproduzione dei microorganismi, i fattori che influenzano la crescita dei microorganismi e i metodi utilizzabili per il controllo della crescita microbica. L'insegnamento si propone di fornire le conoscenze di base sui microrganismi che popolano il suolo, la vite e che sono implicati nei processi industriali; oltre che sui meccanismi responsabili delle regolazioni di espressione genica, sintesi proteica, variabilità genetica, interazione microorganismo-ambiente e microorganismo-pianta. L’obiettivo è inoltre quello di fornire conoscenze di ecologia microbica e di far acquisire la capacità di isolare, coltivare, identificare microrganismi con metodi di microbiologia classica e molecolare, inclusi approcci di metagenomica, mediante esercitazioni pratiche in laboratorio. | 6 |
| **Informatica di base (abilità informatiche)** | 3 |


### Secondo anno


| Insegnamenti e obiettivi formativi | Crediti (CFU) |
| --- | --- |
| **Chimica agraria biochimica con esercitazioni**  Acquisire le basi necessarie per la comprensione delle trasformazioni biochimiche che avvengono nella cellula e nelle piante mettendoli in relazione con aspetti fisiologici e delle produzioni agrarie. Conoscere le caratteristiche principali delle biomolecole in rapporto alla loro struttura e proprietà, analizzare le proprietà e funzioni degli enzimi, la bioenergetica e il trasporto trans-membrana, i cicli metabolici di base della cellula e la loro regolazione. Verranno fornite anche competenze di base sulle caratteristiche fondamentali del suolo, gli elementi nutritivi minerali e i loro cicli biogeochimici. Sono previste esercitazioni di laboratorio mirate ad applicare gli insegnamenti teorici e a sviluppare una capacità critica nell’interpretazione dei risultati ottenuti. | 6 |
| **Chimica e microbiologia enologica** modulo A: Microbiologia enologica con esercitazioni di laboratorio modulo B: Chimica enologica  **Modulo A**. Fornire allo studente le conoscenze necessarie ad una gestione consapevole delle popolazioni microbiche di interesse enologico. Conseguire la conoscenza della tassonomia, morfologia e fisiologia dei principali microrganismi procarioti ed eucarioti di interesse enologico ed i fattori in grado di controllarne lo sviluppo in funzione dei risultati produttivi attesi. Apprendere le nozioni necessarie alla gestione delle colture starter, del rischio microbiologico e delle principali tecniche analitiche necessarie al monitoraggio microbiologico. Sono previste esercitazioni in laboratorio.  **Modulo B**. Questo corso ha l’obiettivo di portare lo studente ad una buona comprensione (principalmente teorica ma anche con esempi applicativi) dei principali composti e reazioni chimiche che avvengono nelle diverse fasi di produzione del vino. Di familiarizzare con i temi critici associati con la chimica del vino. Obiettivo principale è permettere allo studente di acquisire il background di competenze necessario per prendere decisioni informate sul trattamento del vino. | 12 |
| **Viticoltura 1** modulo A: Morfologia e fisiologia della vite con esercitazioni modulo B: Genetica e miglioramento genetico della vite con esercitazioni  **Modulo A**. Fornire conoscenze di morfologia e anatomia della vite, nonché una approfondita conoscenza e comprensione dei fenomeni fisiologici relativi al ciclo vegetativo (crescita, sviluppo della chioma) e produttivo (fioritura, allegagione e maturazione) della vite, al fine di saper attuare scelte tecniche consapevoli orientate verso i diversi obiettivi di quantità e qualità della produzione nel rispetto degli equilibri agro-eco-sistemici.  **Modulo B**.Questo insegnamento intende fornire allo studente le conoscenze più aggiornate sulle basi genetiche dei fenotipi di interesse in viticoltura, le capacità di comprendere le interazioni genotipoambiente con riferimento al sistema vigneto in uno scenario di cambiamenti climatici e gli strumenti per capire i principi della selezione clonale e del miglioramento genetico varietale in viticoltura. Lo studente apprenderà, anche tramite esercitazioni di laboratorio, come le tecniche di analisi diretta del genotipo siano oggi applicate alla sistematica del genere Vitis, agli studi sull’origine e diffusione della viticoltura e delle relazioni genetiche dei vitigni; attraverso approfondimenti sul sistema vivaistico, conoscerà i vari aspetti delle produzioni di materiali per uve da vino, tavola e portinnesti e i relativi approcci di identificazione varietale. Il miglioramento genetico in viticoltura sarà affrontato su base storica per meglio comprendere le possibilità introdotte dall’applicazione dei marcatori molecolari, con i dovuti approfondimenti sulla genetica della resistenza alle malattie e agli stress abiotici, e della qualità dell’uva. In questo contesto lo studente avrà inoltre l’opportunità di apprendere l’evoluzione delle tecnologie di breeding fino alle più recenti applicazioni in vite, e valutarne le possibili implicazioni nel settore viti-enologico. | 12 |
| **Enologia 1** modulo A: Tecnica enologica modulo B: Analisi sensoriale con esercitazioni di laboratorio  **Modulo A**. Portare lo studente ad una buona comprensione degli strumenti normativi per la gestione della qualità e della sicurezza nella filiera vinicola. Acquisire le conoscenze di base relative alle tecniche di vinificazione con o senza macerazione delle parti solide, delle pratiche per il dosaggio dei principali coadiuvanti ed additivi enologici, per l’affinamento e corretta conservazione dei vini e per il riconoscimento dei principali difetti. Obiettivo generale è permettere allo studente di acquisire padronanza sui criteri di scelta della filiera di trasformazione più opportuna in funzione della composizione dell’uva e dell’obiettivo enologico, facendo sintesi delle competenze biochimiche, chimiche, microbiologiche e tecnologiche mirate alla gestione attiva del processo di vinificazione.  **Modulo B**. Il corso si propone di far acquisire allo studente i fondamenti delle scienze sensoriali e una conoscenza di base delle principali tecniche sensoriali applicabili per studiare la qualità percepibile dei prodotti e la risposta dei consumatori puntando l'attenzione alle potenzialità e criticità dei vari metodi sensoriali. Le esercitazioni pratiche inoltre mirano a sviluppare le capacità di riconoscere e descrivere le principali caratteristiche di un vino e permettere agli studenti di sperimentare nella pratica come si applicano i metodi sensoriali, come si elaborano e interpretano i risultati. | 12 |
| **Difesa della vite** modulo A: Patologia viticola con esercitazioni modulo B: Entomologia viticola con esercitazioni  Far acquisire allo studente le conoscenze di base sulle avversità biotiche e abiotiche della vite e sui loro danni, e i fondamenti su cui si basano gli interventi di lotta integrata e biologica e le normative europee e nazionali di riferimento per la difesa. Far acquisire la capacità di riconoscere i danni causati dai principali patogeni e parassiti della vite e le più importanti specie di invertebrati fitofagi e di elaborare autonomamente strategie di difesa contro patogeni e insetti dannosi adottabili a livello di azienda vitivinicola. Far acquisire la capacità di organizzare prove per determinare l’efficacia di un metodo di difesa, migliorare ed analizzarne i risultati. Far acquisire competenze che permettano la scelta delle strategie di difesa ottimali in termini di sostenibilità economica, sociale ed ambientale e la valutazione del rischio connesso con le pratiche di difesa. Nello specifico le conoscenze di base che il corso mira a far acquisire nei due moduli sono le seguenti.  **Modulo A**. Patologia della vite: gli agenti di malattia (funghi, batteri, fitoplasmi, virus o virus-simili, fattori ambientali) più importanti della vite (ciclo biologico, danni); l’interazione pianta, patogeno, ambiente (incluso l’apporto antropico e il controllo biologico naturale); i concetti base dell'epidemiologia e cenni sui modelli previsionali; gli strumenti per la difesa contro i patogeni vegetali (varietà resistenti, pratiche agronomiche, sistemi di supporto alle decisioni, prodotti fitosanitari di sintesi chimica e di natura biologica), le principali categorie di sostanze attive ed il loro meccanismo d’azione, le strategie di prevenzione della resistenza contro le sostanze attive, metodi di lotta integrata e biologica contro i patogeni.  **Modulo B**. Entomologia viticola: sistematica, morfologia e bio-etologia dei principali insetti e acari di interesse viticolo; dinamica di popolazione e fattori di regolazione abiotici e biotici di tali organismi; soglie di intervento, e sviluppo di strategie di difesa e metodi di controllo con particolare riferimento a quelli alternativi all’uso dei mezzi chimici, quali la lotta integrata ed il controllo biologico; l’impatto delle specie esotiche nella gestione del vigneto. | 12 |
| **Meccanizzazione viticola e viticoltura di precisione**  L’obiettivo generale delle lezioni è quello di informare gli studenti riguardo gli sviluppi in corso nella meccanizzazione e gestione di precisione dei vigneti e nel fornire gli strumenti utili per la comprensione dei principali processi fisiologici, rilevanti da un punto di vista viticolo-enologico, che coinvolgono la vite. L’obiettivo ultimo è quello di formare delle figure professionali in grado di rispondere alle esigenze della viticoltura di oggi e di domani. | 6 |
| **Lingua inglese (livello QCER B2)** | 3 |


### Terzo anno


| Insegnamenti e obiettivi formativi | Crediti (CFU) |
| --- | --- |
| **Enologia 2 con esercitazioni**  Fornire conoscenze tecnico-scientifiche adeguate e funzionali all’ottimizzazione dei processi di trasformazione enologica, nonché alla produzione, esaltazione e mantenimento, quanto più possibile nel tempo, delle caratteristiche di qualità e di sicurezza dei vini, anche alla luce e nel rispetto delle normative e dei limiti previsti nel settore alimentare e più specificatamente enologico. Favorire la formazione di una forma mentis funzionale all'analisi rigorosa e alla risoluzione di problemi pratici di cantina. | 6 |
| **Marketing e legislazione prodotti vitivinicoli** modulo A: Marketing e promozione dei prodotti vitivinicoli modulo B: Legislazione vitivinicola  **Modulo A**. Il modulo di Marketing e legislazione dei prodotti vitivinicoli si propone di fornire allo studente le conoscenze di base sulla organizzazione dell’impresa vitivinicola, sul mercato e sul marketing dei prodotti vitivinicoli. I contenuti del modulo di economia riguardano: la struttura e l’organizzazione del settore, i mercati vitivinicoli e le fonti statistiche, il commercio internazionale di prodotti vitivinicoli, la multidimensionalità della qualità in viticoltura ed enologia e le dimensioni della sostenibilità; il comportamento del consumatore di vino, l’analisi delle sue preferenze e la segmentazione di mercato; l’approccio di prezzo edonico e le informazioni ottenibili per i produttori; l’analisi Swot e il piano di marketing; le strategie di “prodotto” e quelle di “prezzo”, marchio e marca; le strategie distributive e i rapporti di filiera; i nuovi strumenti di comunicazione; co-marketing e comunicazione collettiva.  **Modulo B**. Il modulo di Legislazione vitivinicola si propone di fornire allo studente l’inquadramento essenziale dell’ordinamento nazionale e comunitario e della legislazione vitivinicola con particolare riferimento all'Organizzazione Comune del Mercato (OCM) del comparto vitivinicolo. I contenuti del modulo di diritto riguardano: le fonti internazionali, comunitarie e nazionali; l’impresa e in particolare l’impresa agricola; la qualità ed etichettatura dei prodotti; la sicurezza alimentare; gli standard privati e le certificazioni; i meccanismi di gestione del mercato; la qualificazione dei soggetti e i rapporti contrattuali all'interno della filiera vitivinicola. | 12 |
| **Laboratorio controllo qualità prodotti vitivinicoli**  Fornire agli studenti, sia attraverso una presentazione in aula dei presupposti teorici e legislativi, che mediante l'effettuazione individuale in laboratorio delle misure analitiche di base, le competenze necessarie a condurre in autonomia le valutazioni chimico-fisiche necessarie al controllo della qualità generale dei prodotti del settore viti-enologico. Durante il corso vengono presentati e discussi i metodi ufficiali e i principali metodi di corrente utilizzo in cantina. | 6 |
| **Ingegneria alimentare ed impianti enologici**  Mettere in grado lo studente di risolvere semplici problemi pratici del settore alimentare ed enologico applicando i concetti di base dell'ingegneria industriale. Fornire gli elementi base per la conoscenza degli impianti e delle macchine utilizzati in enologia in modo che lo studente sia in grado di valutare criticamente tutta l’impiantistica attualmente disponibile sul mercato e sappia gestirla a favore della sicurezza e qualità del prodotto. | 6 |
| **Viticoltura 2: tecnica viticola con esercitazioni**  Acquisire le conoscenze teoriche e capacità di comprensione dei processi viticoli per poter progettare e realizzare un vigneto, scegliere e gestirne le operazioni colturali connesse. Lo studente sarà in grado di valutare e di scegliere, in dipendenza della situazione ambientale e climatica, la tecnica colturale più idonea all’ottenimento di produzioni la cui qualità sia in linea con gli obiettivi enologici aziendali. Lo studente sarà in grado di reperire gli aggiornamenti propri del settore, prendere decisione e comunicare le informazioni tecniche giudicate idonee anche stilando relazioni e progetti. | 6 |
| **Tirocinio** | 6 |
| **Prova finale** | 6 |


### Corsi a scelta


| Insegnamenti | Crediti (CFU) |
| --- | --- |
| **Insegnamenti a scelta**   * Tecnica enologica speciale   Modulo: Vini spumanti e vini speciali   Modulo: Tecnologie dei distillati * Viticoltura biologica   Modulo: Aspetti agronomici delle viticoltura biologica   Modulo: Infrastrutture ecologiche * Valorizzazione dei sottoprodotti dell’industria enologica e gestione reflui   Modulo: Valorizzazione dei sottoprodotti dell’industria enologica   Modulo: Gestione reflui di cantina * Vitienologia internazionale   Modulo: Geografia viticola: territori e denominazioni   Modulo: Viti-enologia internazionale - territori e vini (ENG) * Bioagrofarmaci, biofertilizzanti e tecniche innovative di gestione per una viticoltura sostenibile (ENG) * Pratiche di consumo e società   Modulo: Pratiche di consumo e società   Modulo: Metodi di indagine sui consumi * Meteorologia per la viticoltura | 12 |









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I candidati e le candidate che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.









 

