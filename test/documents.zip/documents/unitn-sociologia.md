

Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/64/sociologia)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)
* [Scegliere UniTrento](http://www.unitn.it/ateneo/4/perche-scegliere-unitrento)




* **Livello**: Laurea di primo livello
* **Classe** del corso: **L40 Sociologia**
* Lingua in cui si tiene il corso: **italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Sociologia e ricerca sociale, via Verdi 26, 38122 Trento.

Scegliere Sociologia significa studiare **la società nel suo complesso**, riconoscere i **soggetti** che la compongono, analizzare le **relazioni** che si sviluppano al suo interno oltre che i meccanismi alla base dell’**organizzazione** e della **trasformazione sociale**. Per fare questo, la preparazione fornita è **multidisciplinare** e comprende la sociologia, la scienza politica, il diritto, la storia, l’economia, l’antropologia e la psicologia. Inoltre, vengono sviluppate competenze metodologiche indispensabili per raccogliere, analizzare ed elaborare dati quantitativi e qualitativi. Lo studente ha poi la possibilità di scegliere esami opzionali per predisporre un piano di studi personale, articolato secondo i propri interessi.

### Obiettivi formativi

Il corso di laurea in Sociologia prepara gli studenti a comprendere e interpretare i **fenomeni sociali**, le **trasformazioni delle società contemporanee** e delle loro **istituzioni** ed **organizzazioni**, i **modelli relazionali e comportamentali** degli individui che le compongono. La formazione sociologica è arricchita da un’attenzione costante per i metodi e le tecniche di **ricerca empirica** e dal contributo delle principali discipline delle **scienze umane e sociali** – antropologia, scienza politica, storia, diritto, economia, psicologia.

### Profili professionali

La Laurea in Sociologia è spendibile in particolare:

* negli istituti di ricerca sociale e di mercato;
* nei settori della programmazione e organizzazione dei servizi, delle relazioni pubbliche e della comunicazione, della selezione e gestione delle risorse umane;
* nella pianificazione territoriale e nel turismo;
* nella valutazione delle politiche sociali.

Le competenze acquisite costituiscono al contempo la base di una eventuale specializzazione, mediante l'accesso alle diverse lauree magistrali di carattere sociologico offerte dal Dipartimento a coloro che intendono proseguire gli studi.

### Studi che si possono intraprendere dopo la laurea

Al termine della laurea in Sociologia è possibile accedere a corsi di laurea magistrale, master di primo livello e altri percorsi formativi, in base ai requisiti di ammissione previsti.

All'Università di Trento la laurea in Sociologia fornisce le conoscenze necessarie per iscriversi:

* alla laurea magistrale [Sociology and social research](http://offertaformativa.unitn.it/it/lm/sociology-and-social-research/il-corso)
* alla laurea magistrale in [Organizzazione, Società e Tecnologia](https://offertaformativa.unitn.it/it/lm/organizzazione-societa-tecnologia)
* alla laurea magistrale [Global and Local Studies](https://offertaformativa.unitn.it/it/lm/global-and-local-studies)
* alla laurea magistrale in [Data Science](https://offertaformativa.unitn.it/en/lm/data-science)
* alla laurea magistrale [Metodologia, organizzazione e valutazione dei servizi sociali](http://offertaformativa.unitn.it/it/lm/metodologia-organizzazione-e-valutazione-dei-servizi-sociali/il-corso) (con il recupero dei crediti di tirocinio)
* ad alcuni [Master di primo livello](https://www.unitn.it/ateneo/200/master).








Il corso dà gli **strumenti per leggere la realtà sociale all’interno di esperienze concrete di ricerca**, fornendo competenze di analisi, coordinamento e gestione, progettazione, comunicazione, organizzazione e valutazione.

Dopo un **[biennio fortemente unitario](#Attività in comune per tutti i percorsi), in cui gli e le studenti riceveranno una solida formazione teorica e metodologica** in campo sociologico e una formazione di base adeguata nelle scienze umane e sociali che interagiscono più strettamente con la sociologia, è possibile scegliere uno dei **quattro****percorsi**:

* [società civile, ambiente e sostenibilità](#percorso società civile, ambiente e sostenibilità)
* [ricerca e analisi sulla società](#percorso ricerca e analisi sulla società)
* [progettazione e innovazione sociale](#percorso progettazione e innovazione sociale)
* [cultura, media e comunicazione.](#percorso cultura, media e comunicazione)

Le **tabelle in questa pagina** indicano gli insegnamenti previsti dal regolamento del corso approvato per l'**anno accademico 2023/2024**. Consulta

* la [guida studente](https://www.sociologia.unitn.it/111/guida-studenti) per conoscere l'articolazione del percorso formativo, sapere quali sono gli esami obbligatori e quali a scelta previsti ogni anno
* il [regolamento didattico](https://offertaformativa.unitn.it/it/l/sociologia/regolamenti), con le regole principali e gli obiettivi formativi
* il [programma dei singoli insegnamenti](https://unitn.coursecatalogue.cineca.it/cerca-insegnamenti) per conoscerne contenuti, docenti, libri e modalità d'esame.

Attività in comune per tutti i percorsi
---------------------------------------

1° anno - insegnamenti obbligatori
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Istituzioni di sociologia | L'obiettivo del corso è quello di offrire uno sguardo complessivo dei principali temi attorno ai quali si è sviluppata la ricerca sociologica, concentrandosi in particolare sulle tendenze e i problemi della società contemporanea. Saranno affrontati aspetti relativi ai contesti dell'azione sociale, alle disuguaglianze nella società e alle forme di partecipazione civica e politica. Al termine del corso, gli/le studenti acquisiranno una conoscenza critica degli argomenti trattati e svilupperanno una maggiore capacità di orientarsi nella comprensione delle principali dinamiche sociali. | 8 |
| Istituzioni di sociologia - esercitazioni | Le esercitazioni prevedono la discussione e presentazione di articoli scientifici di carattere sociologico. L'obiettivo di tali attività è promuovere lo sviluppo delle competenze di ricerca, analisi critica e comunicazione scientifica degli/delle studenti. L’approccio didattico attivo consentirà di approfondire temi rilevanti e di mettere in pratica le competenze acquisite durante le lezioni. | 4 |
| Storia del pensiero sociologico | Il corso presenta i principali orientamenti delle teorie sociologiche dalle origini della disciplina fino ai più recenti sviluppi. Al termine del corso, lo/la studente sarà in grado di padroneggiare le nozioni fondamentali del pensiero sociologico classico e contemporaneo, con particolare attenzione alle loro definizioni e comparazioni. | 8 |
| Storia del pensiero sociologico - esercitazioni | Le esercitazioni sono un ausilio alla conoscenza delle principali teorie sociologiche dalle origini della disciplina fino ai più recenti sviluppi e consistono nella lettura e commento di alcuni passi significativi tratti dai testi più rappresentativi della storia della sociologia. L’approccio didattico attivo consentirà agli/alle studenti di acquisire una migliore comprensione delle teorie sociologiche e del loro evolversi nel corso del tempo. | 4 |
| Psicologia sociale | Il principale obiettivo del corso è fornire delle conoscenze di base utili ad analizzare fenomeni sociali anche complessi. In particolare, si conseguiranno: (i) una buona conoscenza dei processi psicologici che hanno luogo quando gli individui si percepiscono, si influenzano e interagiscono tra loro; (ii) una buona padronanza del linguaggio specifico della disciplina e delle teorie affrontate; (iii) la capacità di mettere in relazione conoscenze teoriche, ricerca empirica e realtà sociale. Al termine del corso gli/le studenti avranno sviluppato una maggiore capacità di apprendimento autonomo, autonomia di giudizio e abilità comunicative. | 8 |
| Costruire un disegno di analisi dei fenomeni sociali | Il corso fornisce un’introduzione ai concetti di fondo della logica della ricerca empirica teoricamente orientata, seguita da una rassegna critica delle principali strategie conoscitive e delle tecniche di ricerca attualmente impiegate nell’analisi dei fenomeni sociali. Partendo dalla formulazione degli interrogativi di ricerca, il corso passerà in rassegna le diverse logiche dell’indagine sociale, i tipi di dati necessari per rispondere a forme diverse di interrogativi, le tecniche appropriate per raccoglierli e analizzarli. Attraverso una combinazione di lezioni frontali, lettura critica di ricerche esistenti, accompagnate da esercitazioni pratiche, lo/la studente acquisirà progressivamente le conoscenze e le competenze necessarie per orientarsi nel mondo variegato della ricerca sociale contemporanea. | 8 |
| Diritto e istituzioni | Il corso fornisce gli strumenti necessari per una comprensione critica dei profili organizzativi e funzionali del diritto pubblico italiano. Adottando una prospettiva che interroga il binomio autorità-libertà, si evidenzieranno le ragioni giustificative degli istituti e la loro evoluzione. Il legislatore può fare quello che vuole o incontra dei limiti? Quali? Nei procedimenti decisionali “conta” più il Parlamento o il Governo? Cosa vuol dire governare a colpi di fiducia? Quanto incide il diritto dell’UE sull’ordinamento nazionale? Gli/le studenti saranno in grado di rispondere a queste e altre simili domande, acquisendo familiarità con il linguaggio giuridico e comprendendo le interrelazioni tra diritto nazionale e diritto dell’UE. | 6 |
| Storia e società | Il corso intende introdurre gli/le studenti alla conoscenza dei principali temi e concetti della storia sociale, mettendo in luce anche come questi si intrecciano con la storia culturale, politica ed economica. Oltre a fornire un contesto storico agli studi sociologici, il corso incoraggia gli/le studenti ad adottare una prospettiva storica e a considerare le radici profonde di fenomeni che all’apparenza paiono propri della contemporaneità. Adottando quanto più possibile un approccio globale, particolare attenzione è dedicata ad alcune tematiche fondamentali della storia contemporanea, tra cui: le migrazioni, le tecnologie della comunicazione, i movimenti sociali, il genere e la famiglia, la globalizzazione. | 8 |
| Competenze linguistiche - Inglese (B1) | Scopo di queste attività è sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, interagire in una conversazione e produrre un testo utilizzando un linguaggio semplice. | 4 |
| Scrittura accademica | Il seminario sviluppa le competenze di base riguardo a tutto il processo di ricerca: dalla lettura e selezione del materiale, alla definizione della struttura dell'argomentazione scientifica, alla stesura e al controllo finale di testi accademici per le scienze sociali. | 2 |

2° anno - insegnamenti obbligatori
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Antropologia culturale | Il corso si propone di introdurre gli/le studenti agli sviluppi storici, ai cambiamenti teorici e alle tematiche di ricerca (passate e presenti) della disciplina antropologica, a partire dai primi decenni del XX secolo fino all’epoca contemporanea. Particolare attenzione viene prestata ad analizzare il rapporto tra antropologia, scienze sociali e scienze umane, nell'ottica di un dialogo interdisciplinare. Le attività in  classe e le letture assegnate mirano inoltre a generare una conoscenza critica sul rapporto fra teoria antropologica e metodo etnografico, evidenziandone punti di forza e debolezza attraverso l’analisi di casi specifici. | 8 |
| Statistica sociale | Il corso introduce allo studio statistico dei fenomeni sociali fornendo conoscenze di base per la descrizione, l’analisi e l’interpretazione dei dati quantitativi. Il corso introduce altresì i concetti di distribuzioni di probabilità e di inferenza statistica per la generalizzazione dal campione alla popolazione. I/le studenti impareranno a selezionare e applicare i metodi statistici adatti per le analisi esplorative e descrittive, univariate e bivariate. Impareranno inoltre ad implementare i test di significatività e il confronto tra gruppi. Il corso introdurrà all’uso di un software statistico per l’analisi dei dati. | 6 |
| Fondamenti di economia | Il corso intende introdurre gli/le studenti ai concetti e alle idee principali che caratterizzano l’economia politica. Da un lato si affrontano le basi consolidate del pensiero economico ed i principali concetti micro e macroeconomici. Dall’altro, si utilizzano queste basi per capire il dibattito contemporaneo, con approfondimento del pensiero di alcuni tra gli economisti che hanno contribuito a formare l’economia politica contemporanea, e utilizzare queste idee nella comprensione delle questioni socio economiche attuali. Nello specifico il corso si propone di fornire agli/alle studenti le conoscenze di base necessarie sul funzionamento dell’economia di mercato, dei suoi limiti e di presentare il ruolo dello Stato e della cooperazione. | 6 |
| Politica e società | Il corso esplora il nesso esistente tra la società e la politica. Oltre a chiarire i concetti fondamentali utili allo studio di questa relazione, viene approfondito il modo in cui questo rapporto è cambiato nel corso del tempo, anche in chiave comparata. Una particolare attenzione è dedicata ai sistemi politici democratici, alle forme di partecipazione politica, alle cause della crisi delle democrazie contemporanee, nonché ai possibili scenari che si profilano per la democrazia rappresentativa. | 8 |
| Metodi e tecniche di ricerca: raccolta e analisi dati qualitativi (laboratorio) | Il corso, di carattere laboratoriale, fornisce gli strumenti concettuali e metodologici necessari per impostare una ricerca sociologica con un approccio qualitativo.  Il corso offre una panoramica del variegato campo dei metodi qualitativi — etnografia, intervista in profondità, focus group, analisi della conversazione e video-analysis. Per ciascun metodo, verranno trattati i seguenti temi: costruzione degli strumenti di raccolta dati; tecniche della raccolta dati; aspetti etici e legali; analisi dei dati raccolti. Al termine dell’insegnamento, studenti e studentesse sapranno orientarsi riguardo l’utilizzo di metodi e tecniche di ricerca qualitativa e impostare autonomamente una propria raccolta e/o analisi di dati qualitativi. | 6 |
| Metodi e tecniche di ricerca: raccolta e analisi dati quantitativi (laboratorio) | Il corso, di carattere laboratoriale, fornisce gli strumenti concettuali e metodologici necessari per impostare una ricerca sociologica con un approccio quantitativo. Il corso introduce i concetti di associazione e causazione e fornisce gli strumenti per la raccolta dati e per misurare l’associazione tra variabili, anche tramite l’uso di modelli di regressione con l’aiuto di un software statistico. Al termine del corso, gli/le studenti sapranno descrivere diverse strategie di raccolta dei dati, condurre in modo appropriato un'analisi secondaria di dati ‘micro’ teoricamente orientata e interpretarne correttamente i risultati. | 6 |
| Attività a scelta |  | 4 |

2° anno - due insegnamenti a scelta tra
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Genere e diversità | Il corso si propone di introdurre gli/le studenti all’utilizzo di una prospettiva di analisi e allo sviluppo di una consapevolezza critica rispetto alle varie articolazioni della diversità nella vita sociale, con particolare attenzione alla dimensione di genere. Principali obiettivi formativi saranno: una conoscenza di base dei concetti fondamentali e delle principali teorie in materia, con attenzione agli sviluppi più recenti; la capacità di adottare una prospettiva di genere e intersezionale nell’analisi dei principali fenomeni e ambiti della vita sociale; una conoscenza di base rispetto alle modalità di ricerca e alle possibili strategie di contrasto alle diseguaglianze e discriminazioni e di valorizzazione delle differenze in vari ambiti. | 8 |
| Sociologia della cultura | Il corso ha l’obiettivo di fornire la conoscenza di base dei principali approcci teorici e dei maggiori filoni di ricerca nell’analisi contemporanea del legame tra cultura e società. Dopo un percorso introduttivo alle tematiche più rilevanti, il corso esplora quattro dimensioni: la dimensione organizzativa e istituzionale della produzione culturale; l’analisi degli oggetti culturali; la ricezione di oggetti culturali; le forze sociali che definiscono il campo d’azione della cultura. Obiettivi formativi sono: acquisire competenze specifiche e aggiornate nel campo della sociologia della cultura; l’analisi critica delle ricerche sociologiche in questo ambito; l’impostazione in autonomia di analisi sulle pratiche, oggetti, istituzioni e fenomeni di ricezione. | 8 |
| Scienza tecnologia e società | Obiettivo centrale del corso è introdurre ai concetti chiave della sociologia della scienza e all’analisi del ruolo sociale di scienza e tecnologia nelle società contemporanee. In particolare, il corso offre: a) una ricognizione generale del settore e delle sue interazioni con altre aree disciplinari; b) un’introduzione agli autori principali nella fondazione e sviluppo degli Science and Technology Studies (es. Merton, Kuhn, Fleck, Latour, Collins e Pinch, Bijker, Ogburn); c) una panoramica su temi quali: scienza, società e politica; scienza, democrazia e partecipazione; scienza, tecnologia e innovazione; d) l'applicazione di tale quadro concettuale alle dinamiche di tecnologia e innovazione nelle società contemporanee. | 8 |
| Sociologia economica e del lavoro | Il corso fornisce una conoscenza delle principali prospettive teoriche nello studio dell'economia, del welfare e della società e della loro intersezione. Trattando lo stato dell'arte della ricerca in sociologia economica comparata, del welfare e del mercato del lavoro, gli/le studenti acquisiranno competenze specifiche per un'analisi approfondita del nesso fra regimi di welfare e mercati del lavoro post-industriali. Il corso si concentrerà poi sulle principali questioni contemporanee relative alla deregolamentazione e dualizzazione del mercato del lavoro, alla trasformazione industriale, al divario nord/sud, alla discriminazione di genere/etnica/di istruzione, al cambiamento tecnologico e al dibattito fra teorie “skill-biased” e “routine-biased technical change”. | 8 |

3° anno - insegnamenti obbligatori
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Attività a scelta |  | 8 |
| Prova finale | Obiettivo della prova finale è dimostrare di aver acquisito una padronanza nelle materie oggetto di studio del corso di laurea che consenta di svolgere un elaborato con spunti originali e critici su di un argomento specifico. | 4 |

3° anno - un insegnamento a scelta tra
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Analisi dei dati testuali e visivi | Il corso ha l’obiettivo di fornire la conoscenza di base dei principali approcci teorici e dei maggiori filoni di ricerca con e su dati testuali e visivi. Dopo aver fornito le basi teoriche dell’interpretazione dei testi e delle immagini, affronterà diversi modi di studiarli, secondo categorie e concetti fornite dall’analisi tematica, l’analisi qualitativa del contenuto, la frame analysis, l’analisi narrativa, l’analisi del discorso, lo studio dei generi e degli stili. Obiettivi formativi sono l’acquisizione di competenze sistematiche e aggiornate; l’analisi critica delle ricerche sociologiche che fanno uso di questi dati; l’uso degli strumenti per l’analisi dei dati testuali e visivi. | 8 |
| Introduzione ai metodi di ricerca avanzati | Il corso fornisce strumenti utili a selezionare i metodi adeguati a rispondere a specifiche domande di ricerca, operativizzare concetti complessi, implementare e interpretare modelli di analisi dei dati. Vengono presentate ed applicate tecniche quali la regressione lineare multipla e l’interazione tra variabili, si fornisce inoltre un’introduzione a modelli di regressione non lineare, a modelli gerarchici e ad approcci mixed methods. Al termine del corso, gli/le studenti saranno in grado di discutere e/o replicare disegno e tecniche di selezionati esempi di ricerche sociali empiriche. | 8 |
| Ricerca sociale applicata | Il corso introduce ai metodi di ricerca della sociologia computazionale di nuova generazione. In particolare, si compone di tre moduli. Il primo introduce l’analisi di dati non strutturati attraverso tecniche computazionali come Natural Language Processing, l'analisi del sentiment e l'apprendimento automatico. Gli/le studenti saranno introdotti alle applicazioni di tali metodi nell’analisi di dati digitali. Il secondo modulo introduce il concetto di probabilità statistica. Il terzo modulo è dedicato ai concetti base dell’uso di esperimenti nelle scienze sociali: il loro design e l’analisi causale. | 8 |

3° anno - due insegnamenti a scelta tra
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Approcci e metodi di ricerca sui corsi di vita | Il corso introduce gli strumenti teorici e metodologici dello studio dei corsi di vita. Durante le lezioni, gli/le studenti acquisiranno conoscenza dei processi che guidano le scelte che gli individui compiono nell'arco del loro ciclo di vita, dalle scelte educative e percorsi lavorativi, alla formazione di una famiglia e gli aspetti legati alla salute. Verranno inoltre presentati i principali strumenti per l'analisi dei corsi di vita, anche con l'aiuto di software appropriati. Alla fine del corso gli/le studenti avranno acquisito le basi dell'analisi di dati longitudinali e multilivello, e saranno in grado di applicare le tecniche più indicate per gli specifici problemi nonché per una corretta interpretazione dei risultati di tali applicazioni. | 8 |
| Comunicare l’innovazione | Obiettivo del corso è fornire gli strumenti analitico-teorici per comprendere le interazioni tra innovazioni tecnologiche e processi comunicativi. Il corso presenterà i concetti chiave per analizzare le dinamiche sociali alla base dei processi innovativi, con particolare attenzione alle tecnologie di comunicazione e informazione. Fornirà inoltre gli strumenti per studiare le dinamiche dei processi di comunicazione (sia interpersonali sia di massa) in relazione ai tipi di tecnologie coinvolte. Al termine del corso gli/le studenti avranno acquisito le competenze per analizzare sia le dinamiche comunicative all’interno dei diversi ambienti tecnologici sia come comunicare l’innovazione tecnologica. | 8 |
| Movimenti sociali, politica e società | Il corso si propone di introdurre i concetti e le teorie principali utilizzati per interpretare le azioni collettive di protesta e, in particolare, i movimenti sociali. Al termine del corso, gli/le studenti saranno in grado di riconoscere e distinguere le diverse forme di conflitto sociale, politico e culturale e di analizzare il ruolo e la dinamica dei movimenti sociali. Inoltre, saranno capaci di interpretare le evidenze empiriche applicando le conoscenze acquisite durante il corso. Gli/le studenti apprenderanno infine competenze analitiche che permetteranno loro di comprendere in maniera critica fenomeni relativi alle forme e alle dinamiche di conflitto caratteristici della società contemporanea. | 8 |
| Progettazione sociale | L’obiettivo del corso è fornire conoscenze relative alla progettazione sociale. Saranno affrontate le problematiche della progettazione sociale in rapporto alle diverse forme di razionalità, i principali modelli di progettazione sociale e i processi di costruzione dei progetti. Tematiche di approfondimento riguarderanno esemplificazioni di progetti sociali in vari ambiti applicativi ed i diversi strumenti attraverso i quali la progettazione sociale prende forma. Agli/alle studenti verranno fornite competenze sia teoriche che pratiche per costruire un progetto sociale. | 8 |
| Società digitale | Il corso illustra i tratti principali della società digitale per come questa si definisce all’incrocio di corsi di azione sociali e tecnologici. Al termine del corso, gli/le studenti avranno familiarità con i principali modi di indagine della società digitale e saranno in grado di valutare in modo critico e comprendere il ruolo dei media digitali, degli algoritmi, delle intelligenze artificiali e dei big data nella definizione della quotidianità, in particolare rispetto alle dinamiche di partecipazione collettiva e comunicazione politica, definizione del discorso pubblico nella sfera mediale ibrida, rappresentazioni di genere, classe, etnicità, appartenenze religiose e abilità fisiche. | 8 |
| Sviluppo di comunità | In questo corso, gli studenti e le studenti acquisiranno conoscenze e competenze riguardanti il cambiamento delle comunità e delle organizzazioni di base. Attraverso letture, attività di gruppo, studi di caso e momenti seminariali, gli/le studenti acquisiranno  le competenze e le tecniche necessarie per lo sviluppo di comunità, Al termine del corso, gli/le studenti avranno sviluppato, in riferimento a casi concreti:   1. la capacità di analizzare le relazioni sociali per promuovere il cambiamento all'interno delle comunità; 2. la conoscenza dei principi fondamentali della negoziazione comunitaria, del compromesso e dell'accordo; 3. la capacità di collaborare con le comunità per pianificare e implementare azioni pubbliche efficaci. | 8 |
| Sociologia dei consumi culturali | Il corso indaga le dinamiche e le relazioni tra oggetti culturali e i processi di ricezione e consumo. Si focalizza sugli attori del consumo, i pubblici e le audience. Un’attenzione specifica sarà rivolta alle dinamiche di stratificazione e alle logiche di riproduzione del capitale culturale. Gli obiettivi formativi consistono nella capacità di orientarsi criticamente nella letteratura di sociologia dei consumi e della ricezione; nella impostazione in autonomia di ricerche sulla ricezione e i consumi; nella definizione delle relazioni rilevanti all’interno del campo della produzione e ricezione culturale. | 8 |
| Organizzazione e innovazione | Obiettivo del corso è fornire conoscenze per comprendere i processi organizzativi che accompagnano le innovazioni. Verranno approfondite le teorie e i concetti utili a comprendere l’innovazione come fenomeno sociale e organizzativo e saranno fornite competenze relative all’analisi critica delle dinamiche d’innovazione. | 8 |
| Transizione socio-ecologica | Obiettivo del corso è di introdurre gli/le studenti alla conoscenza delle questioni chiave trattate dalla sociologia dell’ambiente con particolare attenzione al ruolo della società civile nel promuovere/ostacolare la transizione socio-ecologica. Tematiche del corso saranno la transizione energetica, il conflitto ambientale, la giustizia ambientale, l’innovazione socio-ecologica per la sostenibilità, le forme dell’ambientalismo, il rischio ambientale. Al completamento di questo corso gli/le studenti saranno in grado di comprendere il ruolo delle variabili e delle dinamiche sociali nei processi di transizione socio-ecologica e di discutere criticamente le problematiche ambientali contemporanee utilizzando la letteratura sociologica rilevante. | 8 |
| Introduzione ai big data e ai metodi computazionali | Il corso si propone di introdurre gli strumenti metodologici di base per utilizzare la programmazione e, in generale, approcci computazionali basati su grandi quantità di dati, nell'ambito delle scienze sociali. Al termine del corso, gli/le studenti avranno acquisito competenze di base nella programmazione con linguaggi di scripting, con specifiche applicazioni all’analisi dati. Inoltre, saranno capaci di valutare in modo critico le opportunità e le problematiche che emergono dall'analisi di dati da sorgenti digitali (per esempio da social media, smartphone, motori di ricerca) nella ricerca sociale. | 8 |

3° anno - percorso società civile, ambiente e sostenibilità
-----------------------------------------------------------

Insegnamenti obbligatori
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Modelli di interazione e azione collettiva | Il corso presenta alcuni dei meccanismi fondamentali che da un lato facilitano lo sviluppo dell’azione collettiva, dall’altro ne garantiscono il coordinamento attraverso diversi principi organizzativi. Questi presentano livelli molto variabili di formalizzazione e strutturazione, dai comportamenti di massa e folla sino alle organizzazioni burocratiche. Il corso fornirà gli strumenti concettuali necessari per interpretare le differenze e le analogie tra burocrazie, organizzazioni reticolari, comunità ed altre forme di coordinamento. | 8 |
| Sostenibilità ambientale e sociale | Il corso intende fornire gli strumenti concettuali e le evidenze empiriche utilizzati per analizzare la crisi ambientale contemporanea. Verranno descritte le tendenze di fenomeni globali che rappresentano le principali minacce alla sostenibilità ambientale, facendo particolare riferimento agli andamenti demografici, alla produzione agricola ed industriale, al consumo delle risorse naturali, all’inquinamento, al cambiamento climatico. Verranno inoltre analizzate le interpretazioni contrapposte di tali fenomeni che animano il dibattito socio-politico e le controversie relative alle potenziali soluzioni politiche, tecnologiche e sociali della crisi. Al termine del corso gli/le studenti saranno in grado di analizzare e discutere criticamente le varie dimensioni della sostenibilità ambientale e sociale. | 8 |
| Stage o attività orientate al lavoro |  | 8 |

3° anno - percorso ricerca e analisi sulla società
--------------------------------------------------

Insegnamenti obbligatori
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Dinamiche sociali | Adottando una prospettiva di comparazione internazionale, il corso presenta i principi-base della ricerca sulle differenze e le disuguaglianze sociali nel loro declinarsi all'interno dei corsi di vita, attraverso una rassegna delle principali trasformazioni e dinamiche delle società contemporanee. Gli/le studenti acquistano le capacità di elaborazione scientifica e al termine, saranno in grado di applicare i concetti appresi ad argomenti di loro interesse e di riflettere criticamente sulla base di solide evidenze empiriche. Avranno acquisito le competenze teoriche e pratiche per riflettere sui problemi attuali delle società contemporanee nonché per discutere possibili soluzioni a tali problemi, con una solida conoscenza delle principali politiche pubbliche e sociali. | 8 |
| Popolazione e società | Il corso fornisce un’introduzione non tecnica alla demografia. I/le studenti impareranno a descrivere gli andamenti globali nei tre pilastri della demografia: fecondità, mortalità e migrazioni, conoscere le principali teorie alla base del cambiamento demografico e valutare criticamente le conseguenze del cambiamento demografico per gli individui, la società e le politiche pubbliche. I/le studenti impareranno inoltre a cercare, analizzare e interpretare informazioni sulla popolazione da banche dati pubblicamente disponibili. | 8 |
| Stage o attività orientate al lavoro |  | 8 |

3° anno - percorso progettazione e innovazione sociale
------------------------------------------------------

Insegnamenti obbligatori
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Innovazione sociale | L’obiettivo del corso è di offrire conoscenze relative alla innovazione sociale affrontando le principali problematiche definitorie e applicative. Saranno approfondite in particolare da un punto di vista sociologico le tematiche dei problemi sociali che richiedono nuove forme di innovazione, degli attori coinvolti nei processi di innovazione sociale e del modo con cui essi creano valore condiviso. Agli/alle studenti verranno fornite competenze per comprendere il fenomeno e saranno forniti gli strumenti sociologici di base per operare nel suo ambito. | 8 |
| Imprenditorialità sociale | L'obiettivo del corso è di fornire una inquadratura concettuale ed empirica sul fenomeno dell’imprenditorialità sociale. Verranno affrontate le questioni definitorie, gli ambiti e i modelli di azione. Tematiche di approfondimento riguarderanno la natura sociale oltre che economica dell’impresa, le variegate forme di imprese, i processi sociali attraverso i quali prende forma l’imprenditorialità sociale e la tipologia delle problematiche affrontate. I/le  studenti saranno in grado di comprendere da un punto di vista sociologico le peculiarità di questo modello di azione economica e acquisiranno competenze per analizzare i processi e i modelli caratteristici del fenomeno. | 8 |
| Stage |  | 8 |

3° anno - percorso cultura, media e comunicazione
-------------------------------------------------

Insegnamenti obbligatori
| Insegnamento | Obiettivi formativi | Crediti |
| --- | --- | --- |
| Cultura e comunicazione di massa | Il corso fornisce gli elementi fondamentali e i concetti introduttivi della teoria dei media e della communication research nell’ambito dei media tradizionali e dei nuovi media. Introduce alla storia delle comunicazioni di massa e alle maggiori teorie, aggiornate allo sviluppo dei media digitali. Si sofferma, attraverso focus tematici, sulle infrastrutture dei media, sull’analisi del prodotto mediale in ogni sua forma, e introduce allo studio delle audience e degli effetti. Fornisce, attraverso l’esposizione di studi di caso e ricerche, gli strumenti di analisi critica e metodologici per l’analisi della comunicazione. | 8 |
| Produzione culturale | Il corso propone una rassegna di teorie della produzione culturale, con un’attenzione ai metodi per la ricerca sociale utilizzati per lo studio delle forme, degli attori, delle carriere e delle pratiche di produzione di prodotti in diversi campi e media (scrittura, arte, musica, audiovisivo etc.). Verranno ripercorse alcune ricerche classiche e contemporanee al fine di condurre più concretamente gli/le studenti nel vivo dell’analisi della produzione culturale. L’obiettivo formativo del corso è fornire competenze utili a condurre ricerche autonome negli ambiti della produzione di prodotti culturali. | 8 |
| Stage o attività orientate al lavoro |  | 8 |









[Iscriversi](/it/l/servizio-sociale/iscriversi "Iscriversi")
------------------------------------------------------------


Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I candidati e le candidate che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.









 






 

