

Il corso
--------

Il Corso di laurea in Gestione Aziendale rappresenta un percorso rivolto a studenti ambiziosi che, fin dall'immatricolazione, vogliano acquisire competenze e tecniche gestionali adatte ad affrontare i problemi delle imprese di ogni dimensione.

Con un approccio che valorizza l'esperienza formativa attiva degli studenti, il percorso formativo coniuga le competenze disciplinari attraverso un continuo riferimento alle realtà aziendali appartenenti ai diversi settori (privato, for profit, pubblica amministrazione e aziende non profit). Le tipiche competenze manageriali (marketing, finanza, organizzazione, gestione della qualità, controllo ...) sono rese disponibili sia nei corsi specialistici che nei laboratori dove l'approccio problem-based è la modalità principale di apprendimento. Il corso di laurea favorisce le esperienze internazionali, anche di tirocinio, nell'ambito delle reti universitarie cui il Dipartimento partecipa.

Contenuti e obiettivi formativi
-------------------------------

Le tematiche trattate includono sia i fondamenti del management – (analisi contabile e finanza aziendale, strategie d'impresa, strategie di marketing, organizzazione, logistica etc.) - sia tematiche avanzate e d'avanguardia per le imprese del futuro, quali la sostenibilità ambientale e il ruolo sociale d'impresa. Alcuni temi qualificanti includono: l'interazione impresa-mercati, il comportamento dei dipendenti e dei consumatori, le azioni per il cambiamento radicale di tipo organizzativo e strategico, la natura familiare delle imprese, le decisioni manageriali.

Verranno altresì forniti gli elementi di base per la comprensione delle dinamiche economiche e macroeconomiche che coinvolgono le imprese, oltre che conoscenze fondamentali di diritto.



Approccio metodologico
----------------------

Il corso di laurea intende sviluppare sia le competenze manageriali, che la formazione dello studente nella sua totalità, quale persona umana, capace di analisi critica e di giudizio autonomo ed indipendente.

A tal fine, intende fondarsi sulla partecipazione attiva dello studente e sulle interazioni e sugli scambi di idee, in aggiunta allo studio individuale.

Il percorso formativo coniuga una solida conoscenza concettuale e metodologica con applicazioni pratiche, facendo del rimando costante alla realtà concreta delle imprese il proprio elemento qualificante.

Tale obiettivo è conseguito mediante l’alternanza di corsi specialistici per lo sviluppo delle competenze manageriali e di laboratori applicativi basati su un approccio problem-based di tipo applicativo. Inoltre, i singoli corsi specialistici impiegano – in funzione delle specifiche finalità didattiche – una pluralità di metodi, quali ad esempio lavori di gruppo, analisi e discussione di casi aziendali, presentazioni di gruppo in aula, analisi quali-quantitative.

Il percorso formativo si completa con un’esperienza formativa presso le aziende (tirocinio), che amplia e consolida le conoscenze acquisite durante la formazione Universitaria.

Periodi temporanei di studio in altre Università o all’estero (exchange program), così come ulteriori esperienze di stage in aggiunta al tirocinio, sono incoraggiati.

Pre-requisiti
-------------

Il corso è aperto agli studenti di varie provenienze e non richiede conoscenze o prerequisiti specifici.

I principali contenuti verranno elaborati dalle fondamenta, offrendo la possibilità di apprendere le discipline del management anche a coloro che, nella formazione pregressa, non hanno avuto modo di avvicinarsi al funzionamento delle imprese.

Percorsi in uscita
------------------

Il corso triennale in Gestione aziendale predispone – con i corsi fondamentali già previsti in programma – per l’accesso a tutte le Lauree Magistrali del Dipartimento di Economia e Management dell’Università di Trento, oltre che di altre Università italiane e straniere. L’accesso a tali percorsi formativi avanzati può essere effettuato già al termine del percorso triennale o, a scelta dello studente, a valle di un’esperienza formativa in azienda da effettuarsi al termine del Corso.










### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Analisi dei dati e Statistica  Conoscenze: strumenti quantitativi per lo studio, la descrizione, l’interpretazione e la previsione di un qualsivoglia fenomeno attraverso rappresentazioni grafiche, misure di sintesi, metodi e tecniche inferenziali; costruzione di modelli di base e scenari relativi ad applicazioni in ambito economico (micro e macro) e del management. Abilità: rappresentare dati economico-aziendali tramite loro sintesi numeriche e grafiche; costruire semplici modelli in grado di esprimere le relazioni tra le grandezze coinvolte; analizzare le tendenze di fondo relative a un fenomeno, cogliere e misurare l’intensità delle relazioni tra le variabili determinanti; elaborare brevi report statistici. | 8 |
| Introduzione all'economia  Conoscenze: basi concettuali, terminologiche e teoriche della scienza economica, utilizzando un approccio che integra temi microeconomici e temi macroeconomici; problemi e concetti fondamentali della teoria economica, in relazione gli aspetti che definiscono la struttura di un sistema economico nelle sue diverse dimensioni: pubblica e privata, reale e finanziaria, interna e internazionale. Fondamenti di analisi storica dell'economia. Abilità: accostarsi al ragionamento economico dominando terminologia e concetti fondamentali. | 12 |
| Matematica  Conoscenze: strumenti fondamentali necessari ad una analisi quantitativa dell'economia, quali il calcolo differenziale per le funzioni di una o più variabili, l'algebra lineare e l'ottimizzazione libera e vincolata. Abilità: capacità di formalizzare un problema in termini matematici; capacità di impiegare in modo appropriato gli strumenti del calcolo differenziale e dell'ottimizzazione. | 12 |
| Diritto pubblico  Conoscenze in materia di: sistema delle fonti del diritto; organizzazione e funzionamento delle istituzioni pubbliche che producono e applicano il diritto; sistema della tutela e istituzioni della giustizia. Capacità: individuare e collocare correttamente le fonti giuridiche che disciplinano i rapporti fra i soggetti economici; individuare le modalità e gli strumenti attraverso cui le istituzioni pubbliche condizionano l’andamento dell’economia; riconoscere i principali mezzi di tutela giurisdizionale. | 6 |
| Diritto privato  Conoscenze in materia di: soggetti giuridici e relative situazioni soggettive attive e passive; modalità e strumenti di regolazione dei rapporti giuridici fra soggetti privati. Capacità: inquadrare i soggetti economici nell’intreccio dei diritti e degli obblighi connessi all’esercizio della loro attività; utilizzare le principali tecniche interpretative per risolvere problemi giuridici. | 6 |
| Economia e Misurazione aziendale  Conoscenze: tipologie di aziende; governo, organizzazione e modello di funzionamento economico delle aziende di produzione; sistema delle rilevazioni inteso a misurare il grado di efficienza dei processi attraverso i quali le aziende producono valore. I concetti di valore e risultato. I fondamenti della contabilità aziendale, dell'analisi finanziaria e del controllo di gestione. Procedimenti di determinazione delle misure di sintesi delle grandezze economiche, finanziarie e patrimoniali. Capacità: redigere i principali documenti e rapporti utilizzati nella comunicazione economico-finanziaria verso l'interno e l'esterno dell'azienda, ovvero il bilancio d'esercizio, le analisi di bilancio, i budget. | 8 |
| Prova di lingua Inglese. E' obbligatorio superare il test di inglese B1 da CFU del primo anno.  Livello di conoscenza B1 attivo. | 6 |
| Tirocinio | 4 |
| Laboratorio di analisi dei mercati  Conoscenze: le principali variabili che descrivono l’andamento di un mercato (volumi, fatturato, prezzi unitari) e loro interpretazione; le determinanti della domanda (popolazione, redditi, prezzi di beni complementi/sostituti); la struttura dell’offerta di mercato, il contesto competitivo e i metodi per il loro studio (quote imprese, indici di concentrazione, barriere all’entrata, determinanti dei costi e possibilità di differenziazione); la struttura e il posizionamento di una specifica impresa e le scelte strategiche operate dalla stessa. Abilità: comprendere, presentare ed elaborare dati; utilizzare dati a fini interpretativi,riconoscendone il contenuto informativo ed utilizzando le conoscenze teoriche apprese nei corsi di base per comprendere le possibili cause dei fenomeni; in particolare, descrivere, elaborare e confrontare dati economici di base; interpretare e distinguere i dati/fenomeni che si riferiscono alla domanda di mercato da quelli che si riferiscono all’offerta; fornire un quadro chiaro sia dell’andamento del mercato, che della domanda e dell’offerta, distinguendo variazioni di lungo periodo da variazioni congiunturali; distinguere il punto di vista dell’analisi economica del mercato dal punto di vista della singola impresa; elaborare un rapporto. | 8 |
| Contabilità, bilancio e principi contabili  Conoscenze in materia di: sistemi contabili nell'ambito del sistema informativo aziendale; tecnica contabile di formazione del bilancio d'esercizio, valutazioni di bilancio con riferimento alle principali fonti normative: codice civile, principi contabili nazionali e principi contabili internazionali; l'utilizzo del dato contabile nell'analisi finanziaria dell'impresa. Abilità: aver acquisito le basi della tecnica contabile; essere in grado di redigere bilanci di impresa con riferimento alle operazioni ordinarie; di valutare la rispondenza dei bilanci alle norme giuridiche e ai principi contabili; di analizzare bilanci sotto il profilo economico e finanziario. | 12 |
| Finanza aziendale  Conoscenze: strumenti per impostare efficientemente le decisioni finanziarie di un'impresa al fine di creare valore a vantaggio dei proprietari e dei creditori; modelli di valutazione dei rischi sopportati dai finanziatori; criteri di valutazione dei progetti di investimento; decisioni riguardanti la struttura delle fonti di finanziamento e la sua composizione per strumenti. Abilità: analizzare le scelte di investimento e delle fonti di finanziamento; valutare la posizione finanziaria di un'impresa. | 8 |
| Diritto commerciale  Conoscenze: nozioni di base sul funzionamento delle società, di persone e di capitali, con particolare riferimento all'organizzazione ed all'amministrazione delle stesse, al funzionamento degli organi, alle operazioni straordinarie, alle responsabilità degli operatori, ed all'eventuale insolvenza delle imprese organizzate in forma societaria; analisi dei processi societari; comprensione e predisposizione dei principali atti caratteristici dei procedimenti societari, e del funzionamento degli organi. Abilità: capacità di supportare le imprese nelle scelte e nella amministrazione degli organi societari; supporto alle imprese in alcune operazioni societarie; fornire supporto al funzionamento degli organi. | 8 |
| Economia  Conoscenze: approfondimento e ampliamento delle nozioni economiche di base apprese in precedenza, con particolare enfasi sui concetti e gli strumenti microeconomici per l’analisi dei contesti non perfettamente concorrenziali. Studio delle strategie che le imprese possono adottare per migliorare la propria capacità di competere su mercati oligopolistici. Analisi dei fallimenti di mercato e degli interventi pubblici volti a ridurne gli effetti distorsivi sul sistema economico. Abilità: riconoscere ed analizzare le principali forme di mercato; comprendere gli effetti dei fallimenti di mercato e le ragioni dell’intervento pubblico. Descrivere il comportamento delle imprese e le conseguenze delle loro principali scelte strategiche. | 8 |
| Organizzazione aziendale  Conoscenze: concetti di base per comprendere le logiche alternative del disegno organizzativo a livello micro (di mansione), meso (di struttura) e macro (di relazioni tra imprese); principi fondamentali della gestione del personale in impresa, sottolineandone le interdipendenze con le scelte di disegno. Abilità: analizzare ed elaborare soluzioni concrete al problema del disegno attraverso un approfondimento delle variabili di progettazione applicate a casi aziendali. | 8 |
| Laboratorio di pianificazione finanziaria  Conoscenze: consolidamento in un contesto applicativo delle conoscenze di base di analisi dei bilanci e di costruzione di modelli di simulazione previsionale. Abilità: interpretare e affrontare operativamente la formazione dei risultati economici e finanziari delle imprese facendo uso di conoscenze interdisciplinari; applicare strumenti di analisi e modelli concettuali appresi nel corso di laurea a casi di studio relativi a tipici problemi gestionali e organizzativi che si affrontano nelle aziende; apprendere dall’esperienza e di collaborazione all’interno di gruppi di lavoro; comunicazione, all'interno di un gruppo di lavoro e in pubblico; redazione di documenti di comunicazione interna e esterna; utilizzo di repertori informativi, banche dati e di tecnologie informatiche e di rete per la comunicazione attraverso internet. | 18 |
| Insegnamenti a libera scelta dello studente  E' consigliato l’inserimento nel piano degli studi di un insegnamento al primo anno e un al terzo anno entrambi da 6 crediti. | 12 |
| Test di matematica  Test che verifica la padronanza degli strumenti di base della logica e della matematica tra le quali: calcolo algebrico elementare: potenze, valore assoluto, polinomi, equazioni e disequazioni di 1° e 2° grado; nozioni fondamentali di geometria analitica: retta, circonferenza, parabola, ellisse e iperbole. | 0 |
| Test di informatica  Lo studente dovrà dimostrare di saper utilizzare gli applicativi informatici di produttività personale (Open Office, Microsoft Office, etc.) a livello ECDL Base o ECDL Start (o equivalente) - 4 moduli base. | 0 |
| Prova finale | 4 |


### Un insegnamento a scelta

È obbligatorio superare il test di lingua entro il primo anno, in quanto propedeutico al sostenimento degli esami del secondo anno.  

Il test di inglese B1 è comunque obbligatorio per poter poi superare la Prova di lingua Inglese del terzo anno.


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Test di Inglese B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. Obbligatorio per poter superare la Prova di lingua Inglese del terzo anno. | 0 |
| Test di Francese B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |
| Test di Spagnolo B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |
| Test di Tedesco B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |


### 3 insegnamenti a scelta


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Sistemi informativi aziendali  Conoscenze in materia di: struttura dei sistemi informativi aziendali; sistemi informativi direzionali e di supporto alle decisioni; sistemi informativi ed estrazione di conoscenza. Abilità: Capacità di individuare i fabbisogni informativi aziendali; capacità di utilizzare le tecnologie informatiche per realizzare sistemi informativi aziendali; capacità di effettuare una progettazione di massima di sistemi informativi direzionali. | 8 |
| Economia delle amministrazioni pubbliche (management pubblico)  Conoscenze: caratteristiche di ordine istituzionale che qualificano il settore pubblico e la gestione delle amministrazioni pubbliche a livello nazionale ed internazionale; principali problematiche delle relazioni tra sistema delle imprese e sistema delle pubbliche amministrazioni locali; acquisizione di alcuni strumenti di management pubblico; recenti tendenze in tema di accountability delle amministrazioni pubbliche e di coinvolgimento degli stakeholder. Abilità: sviluppare le capacità e le tecniche di diagnosi, progettazione ed implementazione dei sistemi di controllo direzionale e strategico; capacità di analisi del processo di formazione delle decisioni nell'ambito delle amministrazioni pubbliche; capacità di impiegare strumenti di valutazione della performance nelle amministrazioni pubbliche. | 8 |
| Marketing  Conoscenze: conoscenze di base necessarie per assumere decisioni nel campo del Marketing in aziende profit e non profit; Collocazione la funzione di marketing rispetto alle altre funzioni aziendali imprese appartenenti al settore B&C. Abilità: capacità di impostare le principali politiche di marketing - capacità di formulare, a un livello iniziale, un piano di marketing. | 8 |
| Economia dei mercati e degli intermediari finanziari  Capacità: conoscenza di base dei contratti finanziari prevalentemente offerti dagli intermediari finanziari in genere, tipicamente i contratti bancari (di pagamento, indebitamento ed investimento) i contratti mobiliari (negoziazione e gestione) i contratti derivati ed assicurativi; conoscenza di strumenti mobiliari quali i titoli azionari, obbligazionari e monetari. Abilità: capacità di identificare diverse alternative contrattuali di finanziamento e di valutarne le conseguenze economiche. | 8 |
| Gestione della produzione e della qualità  Conoscenze: necessarie alla comprensione e alla rappresentazione del funzionamento dei sistemi produttivi, delle loro performances e delle relazioni tra questi e le altre funzioni economiche; introduzione alle principali scelte di progettazione e di gestione dei sistemi produttivi, anche con riferimento ai sistemi di gestione della qualità. Abilità: di impiego di semplici strumenti matematici e statistici per la gestione operativa di impresa. | 8 |
| Programmazione e controllo  Conoscenze in materie di: variabilità dei costi; relazioni tra costi e decisioni aziendali di breve e lungo periodo; comunanza dei costi; trattamento costi comuni; analisi redditività. Capacità: elaborare un report sull’andamento aziendale focalizzato su prodotti, centri di responsabilità, canali distributivi, clienti, risorse ecc.; analisi dei costi e dei ricavi di specifici problemi decisionali; capacità di costruire un budget impiegando il foglio di calcolo e analizzarne gli scostamenti; capacità di presentare i risultati delle analisi; capacità di discutere e difendere i risultati. | 8 |


### Un insegnamento a scelta


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Matematica finanziaria  Conoscenze: concetti fondamentali della matematica finanziaria necessari per valutare la redditività e la rischiosità delle operazioni finanziarie con dati certi; criteri decisionali per la scelta tra progetti finanziari aleatori. Abilità: capacità di svolgere correttamente calcoli finanziari; capacità di impostare problemi finanziari e di delinearne soluzioni. | 8 |
| Statistica per il controllo della qualità  Il corso si propone di condurre operativamente lo studente nelle problematiche del controllo statistico della qualità. Conoscenze: strumenti grafici, misure e indici di sintesi quantitativi per l’analisi e la misurazione della qualità nell’ambito dei processi aziendali. Trattamento dell’informazione di fenomeni multidimensionali. Analisi degli indici e dei flussi di produzione. Principali tecniche di analisi statistica univariata, bivariata e multivariata utili per impostare e risolvere problemi di controllo statistico della qualità e i connessi problemi decisionali. Abilità. il corso si propone di: estendere la conoscenza e la comprensione dei fenomeni aziendali, utilizzando le capacità logiche e analitiche alla base delle principali tecniche statistiche multivariate; stimolare l’autonomia di giudizio nella interpretazione di problemi decisionali in ambito gestionale e nella ricerca di soluzioni appropriate; attivare capacità applicative nell’uso di archivi, banche dati ecc., nell’uso delle tecniche statistiche, nell’uso di software specifici; favorire il formarsi di una sensibilità critica per quel che riguarda i risultati ottenuti nelle analisi. | 8 |
| Statistica per le ricerche di mercato  Le ricerche di mercato sono da sempre uno strumento fondamentale per il successo delle aziende. Nel loro svolgimento, peraltro, oltre alle conoscenze generali di economia aziendale, e a conoscenze specifiche del settore economico di interesse, vengono comunemente impiegate tecniche statistiche che questo corso si prefigge di approfondire. Conoscenze: strumenti quantitativi per l’acquisizione di informazioni e per l’elaborazione delle stesse tramite tecniche di analisi statistica. Indagini campionarie e popolazione target. Tecniche di segmentazione e partizionamento del mercato. Tecniche di analisi statistica multivariata applicata alle ricerche di mercato. Mappe percettive. Abilità. il corso si propone di: estendere e finalizzare, ai fini dell’analisi di mercato, le capacità logiche, analitiche e gli strumenti acquisiti nei corsi di statistica di base; stimolare l’autonomia di giudizio nella interpretazione di problemi decisionali in ambito gestionale e nella ricerca di soluzioni appropriate; attivare capacità applicative nell’uso di archivi, banche dati ecc., nell’uso delle tecniche statistiche, nell’uso di software specifici; potenziare le capacità di elaborazione e presentazione di report statistici in forma sintetica e analitica prestando particolare attenzione alle sensibilità critiche nell’analisi dei risultati. | 8 |









[Iscriversi](/it/l/economia-e-management/iscriversi "Iscriversi ")
------------------------------------------------------------------


Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 






