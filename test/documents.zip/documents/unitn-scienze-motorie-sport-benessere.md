
Link utili 
[Eventi di orientamento](https://orienta.unitn.it/come-scegliere/4/porteaperte-e-altri-eventi-di-orientamento)



Il corso
--------

* **Livello**: Laurea di primo livello
* **Classe di laurea:** L-22 - Scienze attività motorie e sportive
* **Lingua** in cui si tiene il corso: italiano
* **Modalità di accesso**: programmato, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Psicologia e Scienze Cognitive, Corso Bettini, 84 - 38068 - Rovereto (TN)

La laurea in Scienze Motorie, Sport e Benessere vuole **formare professionisti e professioniste delle attività motorie** con specifiche competenze nella conduzione, gestione e valutazione di attività motorie individuali e di gruppo a carattere compensativo, adattativo, educativo, e sportivo finalizzate al mantenimento del benessere psicofisico mediante la promozione di stili di vita attivi. I laureati e le laureate sapranno gestire in autonomia e supportare **attività motorie e sportive sicure, inclusive, coinvolgenti ed efficaci** per il raggiungimento del benessere psico-fisico individuale e collettivo.


Il **percorso formativo** si concentra prima sugli aspetti di base dei vari ambiti e successivamente sulle competenze operative e applicative, fino allo svolgimento del tirocinio formativo, preferibilmente in strutture sportive o di wellness, e al superamento della prova finale. La laurea è rilasciata congiuntamente dalle Università di Trento e di Verona.

Il corso è caratterizzato da:

* un **equilibrio tra i diversi settori**delle scienze motorie e sportive, biologico, medico-clinico, socio-psico-pedagogico, di carattere economico e giuridico
* un **alto numero di corsi psicologici e socio-pedagogici** per promuovere una visione complessa e multidisciplinare dello sport e del benessere psicofisico in tutto l'arco della vita e in diversi contesti professionali ed educativi;
* una particolare attenzione al **ruolo dello sport come mezzo di integrazione**, sia culturale sia per le disabilità;
* l’**apporto delle Scienze Cognitive** sia per il raggiungimento della performance (anche di alto livello), sia per favorire la abilitazione e riabilitazione e per aiutare ad instaurare corretti stili di vita.

Obiettivi formativi
-------------------

Al termine del percorso conoscerai:

* i metodi e gli strumenti per la valutazione funzionale del movimento;
* gli effetti sulla salute e sulle capacità motorie di diversi regimi di allenamento e di alimentazione;
* la struttura funzionale dei vari distretti corporei, in particolare dell'apparato respiratorio, cardiocircolatorio, neuromuscolare, con particolare attenzione ai processi integrativi relativi all’esercizio fisico;
* i meccanismi di base dell'apprendimento e del comportamento nelle diverse età della vita;
* le teorie socio-psico-pedagogiche alla base dello sviluppo psicomotorio e del benessere psicofisico.

Sarai in grado di:

* analizzare i diversi contesti e  le esigenze delle persone e dei gruppi con cui lavorerai;
* implementare metodologie di allenamento che puntano all’eccellenza sportiva o al benessere psico-fisico sulla base dei fattori biomedici, psico-pedagogici e comunicativi delle persone;
* facilitare e motivare le persone ad adottare e mantenere stili di vita attivi;
* gestire programmi di attività motoria indirizzati alla prevenzione dei dismorfismi posturali e delle patologie legate alla sedentarietà;
* scrivere e parlare in modo efficace in almeno una lingua dell'Unione Europea oltre all'italiano, nel tuo campo di competenza e per lo scambio di informazioni generali;
* comunicare adeguatamente e usare gli strumenti per comunicare e informare;
* collaborare in team, operare in modo autonomo e adattarti rapidamente a nuovi ambienti di lavoro.

Aule, laboratori e strutture sportive
-------------------------------------

Potrai studiare in un ambiente con infrastrutture all’avanguardia per il corso

* le sedi del Dipartimento di Psicologia e Scienze Cognitive;
* il [CeRiSM](http://www.cerism.it/), un centro delle Università di Verona e di Trento con laboratori e attrezzature per la valutazione delle attività motorie e sportive.
* numerosi impianti sportivi e palestre di primo livello messi a disposizione dalla Città di Rovereto, per l'atletica, il calcio, il tennis, la ginnastica artistica, la lotta, il tiro con l'arco, il pugilato, le arti marziali, il nuoto, i tuffi, il rugby, ecc.

Dopo la laurea
--------------

La struttura del corso di laurea permette sia di accedere ai livelli superiori di studio in scienze motorie che di entrare direttamente nel mondo del lavoro.

### Lavoro

Dopo la laurea potrai **lavorare nell'ambito di attività ricettive e ricreative legate al benessere** (saune, centri wellness, palestre) e di **attività sportive in natura** (sport invernali, escursionismo, arrampicata, cicloturismo).

Potrai anche l**avorare in organizzazioni pubbliche e private o come libero o libera professionista delle attività motorie e sportive** con il ruolo di:

* guida e accompagnatore o accompagnatrice naturalistico/a e sportivo/a;
* istruttore o istruttrice di discipline sportive non agonistiche;
* organizzatore o organizzatrice di eventi e di strutture sportive;
* osservatore o osservatrice sportivo/a;
* allenatore o allenatrice e tecnico o tecnica sportivo/a.

### Studio

Dopo la laurea potrai iscriverti alla laurea magistrale in [Scienze dello sport e della prestazione fisica](https://www.corsi.univr.it/?ent=cs&id=538) delle Università di Trento e Verona oppure ad altre lauree magistrali delle classi LM68 “Scienze e tecniche dello sport”, LM67 "Scienze e Tecniche delle Attività Motorie Preventive e Adattate" e LM47 "Organizzazione e Gestione dei Servizi per lo Sport e le Attività Motorie".









Il percorso formativo si articola in quattro aree principali:

* discipline motorie e sportive: include le fondamenta tecniche, didattiche e metodologiche delle attività motorie, che si focalizzano sullo sviluppo psicofisico equilibrato nel ciclo di vita e sulle attività motorie per il benessere
* scienze di base: comprende competenze relative alla comprensione delle basi morfologiche, funzionali e fisiche relative alle attività motorie e sportive
* scienze umane:  include la comprensione dei processi di apprendimento e delle fondamenta didattiche relative all’attività motoria e sportiva
* diritto e organizzazione: comprende la conoscenza delle fondamenta del diritto e dei meccanismi che regolano l’interpretazione della giurisprudenza e i principi basilari dell’organizzazione gestionale e economica di enti sportivi.

Le modalità di apprendimento comprendono:

* Lezioni interattive con il coinvolgimento attivo degli studenti.
* Sessioni pratiche in laboratori attrezzati per applicare la teoria alla pratica.
* Tirocini in organizzazioni e strutture del mondo del lavoro per acquisire competenze specifiche del settore.
* Progetti di gruppo per sviluppare competenze collaborative e risolvere problemi reali.
* Forme di valutazione formativa che puntano a monitorare i progressi e a favorire il miglioramento continuo.


#### 1° anno

**Insegnamenti obbligatori**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Comportamento motorio, qualità della vita e salute | 6 |
| Biologia | 6 |
| Anatomia Umana | 6 |
| Fisica del movimento umano | 6 |
| Psicologia cognitiva e del movimento | 6 |
| Psicologia dello sviluppo tipico e atipico delle competenze motorie e cognitive | 6 |
| Fisiologia e neuroscienze | 9 |
| Biochimica del movimento | 6 |
| Attività tecnico pratiche/Tirocinio I anno | 3 |


#### 2° anno

**Insegnamenti obbligatori**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Biomeccanica del movimento umano; Controllo e apprendimento motorio | 12 |
| Metodologia e tecnica dell’allenamento; Didattica del movimento e dello sport; Tecniche degli sport | 18 |
| Psicologia dei gruppi | 6 |
| Pedagogia didattica per le scienze motorie e sportive | 6 |
| Attività tecnico pratiche/Tirocinio II anno | 10 |



**Un insegnamento a scelta 6 CFU fra i seguenti insegnamenti:**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Sociologia dello sport e dell'inclusione | 6 |
| Sport, dipendenze e doping | 6 |
| Informatica per lo sport e della prestazione fisica | 6 |
| Competenza comunicativa e divulgazione in ambito sportivo | 6 |



**Un insegnamento a scelta 3 CFU fra i seguenti insegnamenti:**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Attività motoria e sportiva adattata per la salute | 3 |
| Educazione motoria ed avviamento allo sport | 3 |
| Attività ludica e sport giovanile | 3 |
| Sport outdoor | 3 |


#### 3° anno

**Insegnamenti obbligatori**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Misure e valutazioni sportive | 6 |
| Economia per le associazioni sportive | 6 |
| Medicina generale applicata allo sport | 6 |
| Elementi di diritto dello sport | 6 |
| Attività tecnico pratiche/Tirocinio III anno | 12 |



**Un insegnamento a scelta 6 CFU fra i seguenti insegnamenti:**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Sociologia dello sport e dell'inclusione | 6 |
| Sport, dipendenze e doping | 6 |
| Informatica per lo sport e della prestazione fisica | 6 |
| Competenza comunicativa e divulgazione in ambito sportivo | 6 |



**Un insegnamento a scelta 3 CFU fra i seguenti insegnamenti:**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Attività motoria e sportiva adattata per la salute | 3 |
| Educazione motoria ed avviamento allo sport | 3 |
| Attività ludica e sport giovanile | 3 |
| Sport outdoor | 3 |



**Altre attività previste dal piano**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Lingua inglese (livello B1) | 4 |
| Prova finale | 4 |

### INSEGNAMENTI A SCELTA LIBERA - 12 cfu

Il percorso formativo prevede l’acquisizione di 12 CFU senza vincoli di settore scientifico disciplinare scelti tra gli insegnamenti che vengono appositamente attivati dal Corso di laurea e annualmente pubblicati nel Manifesto degli Studi o tra quelli attivati dall’Ateneo. Queste attività sono di norma offerte al secondo e terzo anno di corso




Il manifesto degli studi elenca gli insegnamenti e le attività che è possibile seguire nell'a.a. 2024/2025.  

Non è definitivo e potrà essere aggiornato nei prossimi mesi.





[![application/pdf](/sites/all/modules/contrib/alfresco/images/filetypes/pdf.gif "application/pdf")Manifesto degli studi laurea in Scienze motorie, sport e benessere 2024/2025 (aggiornamento 2 ottobre 2024)](/alfresco/download/workspace/SpacesStore/5133bdea-842b-4338-899c-40a7b0077c28/manifesto-l-scienze-motorie-24-25.pdf)(PDF | 152 KB)  
 last update 02/10/2024 







 




Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I candidati e le candidate che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.









 

