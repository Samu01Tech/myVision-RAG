

Il corso
--------

La laurea in Gestione aziendale, percorso Part-Time punta a dotare:

* i laureati di **strumenti di analisi e di gestione dei problemi finanziari**, operativi e amministrativi delle aziende, private e pubbliche, per un ingresso immediato nel mercato del lavoro;
* valide e specifiche **competenze manageriali**, coniugando saperi teorici ad abilità pratico-applicative.

Il corso di laurea in Gestione aziendale si differenzia per organizzazione delle attività e obblighi di frequenza, ma persegue gli stessi [obiettivi formativi](https://offertaformativa.unitn.it/it/l/gestione-aziendale/il-corso) del corso di Gestione aziendale.

La durata del percorso part-time è di quattro anni, così da poter diluire l’impegno didattico su un tempo leggermente più lungo.

Obiettivi formativi
-------------------

 

Il corso di laurea in **Gestione aziendale**(**classe di laurea L-18**)si propone di formare operatori in grado di:

* comprendere, gestire e migliorare i processi attraverso i quali le aziende producono valore;
* trasformare efficientemente i fattori produttivi in beni e servizi capaci di rispondere ai bisogni dei consumatori o degli utenti.

Per sviluppare tali capacità, i laureati in Gestione aziendale apprendono:

* gli strumenti di rilevazione e analisi;
* i modelli decisionali tipici delle discipline manageriali;
* metodologie matematiche, statistiche e strumenti informatici;
* gli strumenti interpretativi fondamentali dell’economia e del diritto al fine di cogliere i nessi esistenti tra l’azienda ed il contesto economico e normativo di riferimento.

Opportunità di Lavoro
---------------------

I laureati in Gestione Aziendale potranno indirizzarsi verso la carriera manageriale in organizzazioni economiche operanti in svariati settori come **assistenti alla direzione** generale, in **posizioni di responsabilità** nelle aree amministrativa e finanziaria, commerciale e operativa di produzione.

Il corso prepara, tra le altre, alle professioni di contabili ed assimilati, tecnici addetti all’organizzazione e al controllo della produzione e tecnici della gestione finanziaria.

Opportunità di studio
---------------------

I laureati possono inoltre decidere di proseguire la formazione nelle lauree magistrali in ambito economico-aziendale e in altri ambiti affini.









Il percorso part time del corso di laurea Gestione Aziendale prevede l’obbligo di frequenza delle attività didattiche (assolto a fronte di almeno il 75% delle presenze), appositamente organizzate in orari normalmente compatibili con gli impegni lavorativi.

Primo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Matematica  Conoscenze: strumenti fondamentali necessari ad una analisi quantitativa dell'economia, quali il calcolo differenziale per le funzioni di una o più variabili, l'algebra lineare e l'ottimizzazione libera e vincolata. Abilità: capacità di formalizzare un problema in termini matematici; capacità di impiegare in modo appropriato gli strumenti del calcolo differenziale e dell'ottimizzazione. | 12 |
| Economia e misurazione aziendale  Conoscenze: tipologie di aziende; governo, organizzazione e modello di funzionamento economico delle aziende di produzione; sistema delle rilevazioni inteso a misurare il grado di efficienza dei processi attraverso i quali le aziende producono valore. I concetti di valore e risultato. I fondamenti della contabilità aziendale, dell'analisi finanziaria e del controllo di gestione. Procedimenti di determinazione delle misure di sintesi delle grandezze economiche, finanziarie e patrimoniali. Capacità: redigere i principali documenti e rapporti utilizzati nella comunicazione economico-finanziaria verso l'interno e l'esterno dell'azienda, ovvero il bilancio d'esercizio, le analisi di bilancio, i budget. | 8 |
| Test di informatica  Lo studente dovrà dimostrare di saper utilizzare gli applicativi informatici di produttività personale (Open Office, Microsoft Office, etc.) a livello ECDL Base o ECDL Start (o equivalente) - 4 moduli base. | 0 |
| Test di matematica  Test che verifica la padronanza degli strumenti di base della logica e della matematica tra le quali: calcolo algebrico elementare: potenze, valore assoluto, polinomi, equazioni e disequazioni di 1° e 2° grado; nozioni fondamentali di geometria analitica: retta, circonferenza, parabola, ellisse e iperbole. | 0 |


### Un insegnamento a scelta

È obbligatorio superare il test di lingua entro il primo anno, in quanto propedeutico al sostenimento degli esami del secondo anno.  

Il test di inglese B1 è comunque obbligatorio per poter poi superare la Prova di lingua Inglese del terzo anno.


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Test di Inglese B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. Obbligatorio per poter superare la Prova di lingua Inglese del terzo anno. | 0 |
| Test di Francese B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |
| Test di Spagnolo B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |
| Test di Tedesco B1  Test che verifica la padronanza di una lingua straniera a livello B1 passivo. | 0 |

Secondo anno
------------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Analisi dei dati e statistica  Conoscenze: strumenti quantitativi per lo studio, la descrizione, l’interpretazione e la previsione di un qualsivoglia fenomeno attraverso rappresentazioni grafiche, misure di sintesi, metodi e tecniche inferenziali; costruzione di modelli di base e scenari relativi ad applicazioni in ambito economico (micro e macro) e del management. Abilità: rappresentare dati economico-aziendali tramite loro sintesi numeriche e grafiche; costruire semplici modelli in grado di esprimere le relazioni tra le grandezze coinvolte; analizzare le tendenze di fondo relative a un fenomeno, cogliere e misurare l’intensità delle relazioni tra le variabili determinanti; elaborare brevi report statistici. | 8 |
| Introduzione all'economia  Conoscenze: basi concettuali, terminologiche e teoriche della scienza economica, utilizzando un approccio che integra temi microeconomici e temi macroeconomici; problemi e concetti fondamentali della teoria economica, in relazione gli aspetti che definiscono la struttura di un sistema economico nelle sue diverse dimensioni: pubblica e privata, reale e finanziaria, interna e internazionale. Fondamenti di analisi storica dell'economia. Abilità: accostarsi al ragionamento economico dominando terminologia e concetti fondamentali. | 12 |
| Diritto pubblico  Gli ordinamenti giuridici. Le fonti del diritto. Forme di Stato e forme di governo. Il Parlamento. Il Presidente della Repubblica. Il Governo. La pubblica amministrazione. La Corte costituzionale. | 6 |
| Diritto privato  Fornire la conoscenza di base delle principali categorie del diritto privato, con particolare riguardo alla soggettività giuridica e alle sue forme, alla proprietà e le diverse forme di appartenenza, al ruolo del contratto e gli altri modi di assunzione delle obbligazioni, alla responsabilità civile. Guidare gli studenti alla consultazione delle fonti e all'interpretazione delle norme, con particolare riguardo alla Costituzione, alle fonti comunitarie e al codice civile. | 6 |
| Contabilità, bilancio e principi contabili  Conoscenze in materia di: sistemi contabili nell'ambito del sistema informativo aziendale; tecnica contabile di formazione del bilancio d'esercizio, valutazioni di bilancio con riferimento alle principali fonti normative: codice civile, principi contabili nazionali e principi contabili internazionali; l'utilizzo del dato contabile nell'analisi finanziaria dell'impresa. Abilità: aver acquisito le basi della tecnica contabile; essere in grado di redigere bilanci di impresa con riferimento alle operazioni ordinarie; di valutare la rispondenza dei bilanci alle norme giuridiche e ai principi contabili; di analizzare bilanci sotto il profilo economico e finanziario. | 12 |

Terzo anno
----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Laboratorio di analisi dei mercati  Conoscenze: le principali variabili che descrivono l’andamento di un mercato (volumi, fatturato, prezzi unitari) e loro interpretazione; le determinanti della domanda (popolazione, redditi, prezzi di beni complementi/sostituti); la struttura dell’offerta di mercato, il contesto competitivo e i metodi per il loro studio (quote imprese, indici di concentrazione, barriere all’entrata, determinanti dei costi e possibilità di differenziazione); la struttura e il posizionamento di una specifica impresa e le scelte strategiche operate dalla stessa. Abilità: comprendere, presentare ed elaborare dati; utilizzare dati a fini interpretativi, riconoscendone il contenuto informativo ed utilizzando le conoscenze teoriche apprese nei corsi di base per comprendere le possibili cause dei fenomeni; in particolare, descrivere, elaborare e confrontare dati economici di base; interpretare e distinguere i dati/fenomeni che si riferiscono alla domanda di mercato da quelli che si riferiscono all’offerta; fornire un quadro chiaro sia dell’andamento del mercato, che della domanda e dell’offerta, distinguendo variazioni di lungo periodo da variazioni congiunturali; distinguere il punto di vista dell’analisi economica del mercato dal punto di vista della singola impresa; elaborare un rapporto. | 8 |
| Finanza aziendale  Conoscenze: strumenti per impostare efficientemente le decisioni finanziarie di un'impresa al fine di creare valore a vantaggio dei proprietari e dei creditori; modelli di valutazione dei rischi sopportati dai finanziatori; criteri di valutazione dei progetti di investimento; decisioni riguardanti la struttura delle fonti di finanziamento e la sua composizione per strumenti. Abilità: analizzare le scelte di investimento e delle fonti di finanziamento; valutare la posizione finanziaria di un'impresa. | 8 |
| Diritto commerciale  Conoscenze: nozioni di base sul funzionamento delle società, di persone e di capitali, con particolare riferimento all'organizzazione ed all'amministrazione delle stesse, al funzionamento degli organi, alle operazioni straordinarie, alle responsabilità degli operatori, ed all'eventuale insolvenza delle imprese organizzate in forma societaria; analisi dei processi societari; comprensione e predisposizione dei principali atti caratteristici dei procedimenti societari, e del funzionamento degli organi. Abilità: capacità di supportare le imprese nelle scelte e nella amministrazione degli organi societari; supporto alle imprese in alcune operazioni societarie; fornire supporto al funzionamento degli organi. | 8 |
| Economia  Conoscenze: approfondimento e ampliamento delle nozioni economiche di base apprese in precedenza, con particolare enfasi sui concetti e gli strumenti microeconomici per l’analisi dei contesti non perfettamente concorrenziali. Studio delle strategie che le imprese possono adottare per migliorare la propria capacità di competere su mercati oligopolistici. Analisi dei fallimenti di mercato e degli interventi pubblici volti a ridurne gli effetti distorsivi sul sistema economico. Abilità: riconoscere ed analizzare le principali forme di mercato; comprendere gli effetti dei fallimenti di mercato e le ragioni dell’intervento pubblico. Descrivere il comportamento delle imprese e le conseguenze delle loro principali scelte strategiche. | 8 |
| Organizzazione aziendale  Conoscenze: concetti di base per comprendere le logiche alternative del disegno organizzativo a livello micro (di mansione), meso (di struttura) e macro (di relazioni tra imprese); principi fondamentali della gestione del personale in impresa, sottolineandone le interdipendenze con le scelte di disegno. Abilità: analizzare ed elaborare soluzioni concrete al problema del disegno attraverso un approfondimento delle variabili di progettazione applicate a casi aziendali. | 8 |
| Sistemi informativi aziendali  Conoscenze in materia di: struttura dei sistemi informativi aziendali; sistemi informativi direzionali e di supporto alle decisioni; sistemi informativi ed estrazione di conoscenza. Abilità: Capacità di individuare i fabbisogni informativi aziendali; capacità di utilizzare le tecnologie informatiche per realizzare sistemi informativi aziendali; capacità di effettuare una progettazione di massima di sistemi informativi direzionali. | 8 |
| Marketing e marketing dei servizi  Conoscenze: principi fondamenti del Marketing tra i quali il ruolo del marketing strategico e del marketing operativo e il marketing mix; peculiarità d Marketing dei servizi rispetto al Marketing. Abilità: progettazione dell’offerta per un’impresa di servizi; definizione e misurazione della qualità dei servizi e della customer satisfaction. | 8 |

Quarto anno
-----------


### Insegnamenti obbligatori


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Laboratorio di pianificazione finanziaria  Conoscenze: consolidamento in un contesto applicativo delle conoscenze di base di analisi dei bilanci e di costruzione di modelli di simulazione previsionale. Abilità: interpretare e affrontare operativamente la formazione dei risultati economici e finanziari delle imprese facendo uso di conoscenze interdisciplinari; applicare strumenti di analisi e modelli concettuali appresi nel corso di laurea a casi di studio relativi a tipici problemi gestionali e organizzativi che si affrontano nelle aziende; apprendere dall’esperienza e di collaborazione all’interno di gruppi di lavoro; comunicazione, all'interno di un gruppo di lavoro e in pubblico; redazione di documenti di comunicazione interna e esterna; utilizzo di repertori informativi, banche dati e di tecnologie informatiche e di rete per la comunicazione attraverso internet. | 18 |
| Economia dei mercati e degli intermediari finanziari  Capacità: conoscenza di base dei contratti finanziari prevalentemente offerti dagli intermediari finanziari in genere, tipicamente i contratti bancari (di pagamento, indebitamento ed investimento) i contratti mobiliari (negoziazione e gestione) i contratti derivati ed assicurativi; conoscenza di strumenti mobiliari quali i titoli azionari, obbligazionari e monetari. Abilità: capacità di identificare diverse alternative contrattuali di finanziamento e di valutarne le conseguenze economiche. | 8 |
| Matematica finanziaria  Conoscenze: concetti fondamentali della matematica finanziaria necessari per valutare la redditività e la rischiosità delle operazioni finanziarie con dati certi; criteri decisionali per la scelta tra progetti finanziari aleatori. Abilità: capacità di svolgere correttamente calcoli finanziari; capacità di impostare problemi finanziari e di delinearne soluzioni. | 8 |
| Prova di lingua inglese. E' obbligatorio superare il test di inglese B1 da CFU del primo anno.  Raggiungimento di una conoscenza grammaticale, sintattica e semantica della lingua inglese corrispondente al livello B1. | 6 |
| Prova di informatica  ECDL Full. | 0 |
| Insegnamenti a libera scelta dello studente  Attività formative dedicate al completamento e all’approfondimento della preparazione anche in vista della scelta del tema su cui svolgerà la prova finale. | 12 |
| Tirocinio | 4 |
| Prova finale  La prova finale consiste nella predisposizione di un elaborato scritto e della sua presentazione e discussione. Obiettivo della prova finale è valorizzare le capacità di analisi critica rispetto ad uno specifico argomento o problema e di presentazione. | 4 |









[Iscriversi](/it/l/economia-e-management/iscriversi "Iscriversi ")
------------------------------------------------------------------


Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 






