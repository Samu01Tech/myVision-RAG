
Link utili 
[Tasse Universitarie](http://infostudenti.unitn.it/it/tasse-universitarie)



* **Livello**: Laurea di **primo livello**
* **Classe**del corso: **L-7 Ingegneria civile e ambientale**
* **Lingua**in cui si tiene il corso: **italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Ingegneria Civile, Ambientale e Meccanica, via Mesiano, 77 38123 Trento

Obiettivi formativi
-------------------

Il Corso di Laurea in Ingegneria per l’Ambiente e il Territorio si propone di:

* soddisfare la domanda di qualità ambientale, di sicurezza del territorio e di efficiente gestione delle risorse che proviene da vasti settori della società;
* soddisfare la domanda, proveniente dal sistema della produzione dei beni e della fornitura dei servizi, relativa sia al rispetto di parametri ambientali e di sicurezza, sia all’innovazione dei processi di trattamento delle risorse;
* concorrere al soddisfacimento di queste domande preparando adeguatamente una duplice figura professionale:
  - in grado di inserirsi in un percorso formativo superiore, orientato alla acquisizione di competenze sia generali che specialistiche che consentano lo studio e la progettazione di adeguate soluzioni in risposta alle diverse problematiche ambientali;  
  
  ​​​​- in grado di ricoprire ruoli tecnici e tecnico-organizzativi in imprese, studi di progettazione ed enti pubblici e privati che si occupano di pianificazione, realizzazione e gestione di opere, di sistemi di controllo e monitoraggio dell’ambiente e del territorio, di difesa del suolo, di gestione dei rifiuti, delle materie prime e delle risorse ambientali, geologiche ed energetiche, di valutazione dell’impatto e della compatibilità ambientale di piani ed opere.

A questo fine il Corso di laurea in Ingegneria per l’Ambiente e il Territorio adotta i seguenti obiettivi formativi:

* l’acquisizione di una solida cultura di base, con riferimento sia agli aspetti fisico - matematici che ai contenuti delle discipline tradizionali dell'ingegneria civile e ambientale;
* la comprensione, attraverso un approccio quantitativo, dell’ambiente, ovvero delle molteplici interazioni tra componenti ambientali, processi antropici e naturali, con riferimento al ciclo delle risorse, a partire in particolare dalle risorse idriche;
* la capacità di tradurre questa comprensione in azioni utili a migliorare il benessere collettivo in un’ottica di lungo periodo, attraverso il controllo, la preservazione e la riqualificazione dell’ambiente;
* la capacità di concorrere, con strumenti concettuali e tecnologici adeguati, all’uso sostenibile delle risorse naturali, alla difesa e prevenzione dalle catastrofi, alla salvaguardia degli ecosistemi, alla progettazione e alla gestione sostenibile degli insediamenti e, in generale, alla sicurezza e alla qualità della vita.

Profili professionali
---------------------

Il laureato in Ingegneria per l'Ambiente e il Territorio è in grado di ricoprire ruoli tecnici e tecnico-organizzativi nei seguenti settori:

* gestione e controllo dell'ambiente e del territorio, sia attraverso il monitoraggio ambientale che attraverso la gestione di quadri conoscitivi a supporto delle decisioni;
* difesa idrogeologica del territorio, sia attraverso il monitoraggio ambientale che attraverso il concorso alla identificazione di soluzioni adeguate;
* valutazione dell'impatto di progetti e di piani, attraverso il concorso alla stesura degli studi di impatto ambientale e alle procedure di verifica;
* gestione delle risorse ambientali, sia attraverso il monitoraggio che attraverso il concorso alla predisposizione di soluzioni rivolte all’efficienza e alla sostenibilità;
* gestione delle reti idriche e degli impianti di trattamento dei reflui, oltre che gestione del ciclo dei rifiuti;
* gestione della sicurezza dei cantieri con riferimento all’interazione con il rischio e le risorse.

Gli sbocchi professionali sono costituiti dalle imprese, dai servizi tecnici e tecnologici, dagli enti pubblici e privati e dagli studi professionali che si occupano di progettazione, pianificazione, realizzazione e gestione di opere ingegneristiche e di sistemi di controllo e monitoraggio dell'ambiente e del territorio, di difesa del suolo, di gestione delle reti e degli impianti, dei rifiuti e delle risorse ambientali, oltre che di valutazione dell'impatto e della compatibilità ambientale di piani e opere.

Studi che si possono intraprendere dopo la laurea
-------------------------------------------------

Il conseguimento della Laurea in Ingegneria per l’ambiente e il territorio consente

* l’accesso diretto alla **[Laurea magistrale in Ingegneria per l’ambiente e il territorio](https://offertaformativa.unitn.it/it/lm/ingegneria-l-ambiente-e-il-territorio)** attivata presso l’Università di Trento.
* in generale l’accesso ai percorsi di Laurea Magistrale di più discipline ingegneristiche di cui vengano soddisfatti i requisiti di ingresso.








Il corso di laurea in Ingegneria per l’Ambiente e il Territorio affronta le tematiche fondamentali necessarie per rispondere alla crescente domanda di qualità, protezione e gestione sostenibile dell’ambiente e del territorio, fornendo una solida preparazione di base per intraprendere con adeguati strumenti un percorso di studi di secondo livello (laurea magistrale).


### Primo anno


| Insegnamenti obbligatori | Crediti (CFU) |
| --- | --- |
| **Analisi matematica 1** Introduzione agli argomenti basilari dell'analisi infinitesimale in una variabile (numeri reali e numeri complessi, limiti di successioni e di funzioni, funzioni continue, derivate, approssimazione polinomiale, integrali e integrali impropri, serie numeriche, serie di potenze e serie di Fourier, equazioni differenziali lineari e non lineari). | 12 crediti |
| **Chimica** Il corso si propone un duplice obiettivo: fornire le conoscenze propedeutiche di base della chimica generale sui fenomeni chimici, la struttura e le proprietà dei composti chimici di interesse ambientale e introdurre i fenomeni chimici naturali e le variazioni ambientali causate dall'inquinamento chimico, con l’ausilio di fondamenti di chimica organica e biochimica. Il corso sarà integrato da esercitazioni didattiche in aula e, ove possibile, in laboratorio. Il corso ha finalità metodologiche e professionalizzanti e fornisce allo studente le basi per acquisire i successivi contenuti formativi sulla gestione della qualità ambientale e delle risorse e sulle operazioni di monitoraggio e riqualificazione ambientale. | 9 crediti |
| **Fisica 1** Scopo del corso è di fornire i fondamenti concettuali ed operativi del metodo sperimentale in fisica. Il corso tratta della cinematica e della dinamica classiche sia del punto materiale sia dei sistemi di punti, arrivando fino alla trattazione della dinamica del corpo rigido. Il corso è integrato da numerosi esercizi di applicazione volti a sviluppare nello studente la capacità di modellare un semplice problema fisico e di trovarne la soluzione. Il corso richiede la conoscenza dei fondamenti del calcolo. L’esame consiste in uno scritto, richiedente la risoluzione di uno o più problemi fisici, e di un orale vertente sia su argomenti teorici sia sulla discussione dello scritto. | 9 crediti |
| **Statistica, algoritmi e programmazione** Statistica: Media e varianza di una distribuzione di dati statistici. Dati vettoriali e regressione lineare, indice di correlazione. Il linguaggio del Calcolo delle Probabilità nel caso discreto e nel caso continuo. Variabili aleatorie discrete e continue. Distribuzione di probabilità, media e varianza di una variabile aleatoria. Distribuzioni binomiale, gaussiana e di Poisson. Esempi di funzioni di una variabile aleatoria. Distribuzione chi quadro. Enunciato e significato della Legge dei grandi numeri e del teorema limite centrale. Distribuzione congiunta, distribuzioni marginali, covarianza, dipendenza e indipendenza. In contesti tipici dell'ingegneria per l'ambiente: esempi elementari di modelli statistici e di stima dei parametri, un esempio di analisi delle componenti principali. Per la parte di algoritmi e programmazione il corso ha l’obiettivo di fare conoscere i diversi metodi per l'approssimazione numerica della soluzione di alcune classi di problemi della matematica applicata, utilizzando il calcolatore: risoluzione di sistemi lineari e di equazioni non lineari; approssimazione di funzioni; rappresentazione ed analisi di dati; metodo ai minimi quadrati; ottimizzazione nonlineare; integrazione e derivazione numerica; risoluzione di equazioni differenziali ordinarie con applicazioni a problemi della meccanica. Al contempo intende chiarire i fondamenti matematici alla base dei diversi metodi numerici e analizzare le proprietà di stabilità, accuratezza e complessità algoritmica, nonché fornire criteri per la scelta dell'algoritmo più adatto per affrontare un problema specifico curandone anche la relativa implementazione in un linguaggio di programmazione di alto livello (ad esempio Matlab o Python). Le esercitazioni al computer riguardano anche la parte di statistica. | 9 crediti |
| **Geometria e algebra lineare** Il corso intende fornire ai futuri ingegneri elementi di geometria analitica nel piano e nello spazio tridimensionale. L'efficace formalismo dell'algebra lineare sarà introdotto gradualmente, valorizzando l'intuizione visiva e seguendo un approccio operativo. Il principale obiettivo formativo del corso consiste pertanto nell'apprendimento e nella pratica del linguaggio matematico indispensabile per trattare gli enti in uno spazio e le loro trasformazioni. | 6 crediti |
| **Geologia** Il corso fornisce agli studenti le conoscenze di base della geologia, necessarie per la comprensione e la soluzione di problemi applicativi di interesse ingegneristico. Attraverso l’apprendimento di queste conoscenze, lo studente è posto nelle condizioni di concorrere alla progettazione di interventi di carattere geologico. Lo studente apprende queste conoscenze attraverso lezioni, esercitazioni ed escursioni sul terreno. | 6 crediti |
| **Lingua inglese B2** | 3 crediti |
| **Introduzione all'ingegneria ambientale** | 1 credito |
| **Laboratorio didattico di fisica** Scopo de Laboratorio è introdurre gli studenti del 2 anno di Ingegneria alla pratica del laboratorio, all'uso della strumentazione per l'acquisizione di dati sperimentali, al concetto di misura e di incertezza, alle tecniche di base di analisi dei dati (stima dei parametri, ricerca di relazioni tra grandezze fisiche, propagazione degli errori, verifica dei modelli). | 1 credito |
| **Tecniche della rappresentazione** Il corso introduce alla rappresentazione dell'ambiente, sia naturale che antropico, alle diverse scale. Vengono illustrati i principi della rappresentazione grafica e cartografica, nonché quelli del disegno tecnico dei manufatti, anche attraverso esempi applicativi. Gli studenti acquisiscono conoscenze di base, sia metodologiche che operative, con l'utilizzo di software specifici. Il corso prevede lo svolgimento di un caso applicativo completo, che fornisce gli spunti per la discussione metodologica e per la verifica delle abilità pratiche. Le competenze acquisite formano una base strumentale per le analisi ambientali e lo sviluppo dei progetti dei corsi successivi. | 3 crediti |


### Secondo anno


| Insegnamenti obbligatori | Crediti CFU |
| --- | --- |
| **Analisi matematica 2** Elementi di Calcolo differenziale e integrale per funzioni di più variabili a valori scalari e vettoriali. Visualizzazione e rappresentazione: Derivate parziali e direzionali, differenziale, gradiente, matrice jacobiana, derivate di funzioni composte, matrice hessiana, formula di Taylor al primo e secondo ordine. Massimi e minimi locali e globali, carattere dei punti stazionari. Curve e superfici parametrizzate, lunghezza, area, vettori tangenti e normali, curvature. Coordinate polari nel piano e nello spazio. Integrali di funzioni di più variabili, formule di riduzione, cambiamenti di variabile. Integrali su curve e superfici. Campi di vettori, Teoremi di Green, della divergenza e di Stokes. Esercizi di calcolo. Sviluppo della capacità di visualizzare, rappresentare graficamente e interpretare il significato geometrico e fisico di insiemi, funzioni, curve, superfici, campi di vettori e trasformazioni del piano e dello spazio. | 9 crediti |
| **Tecnologia dei materiali con Laboratorio di chimica per l'ambiente** L’obiettivo del corso è duplice. Primariamente quello di fornire allo studente le conoscenza propedeutiche di base delle proprietà dei materiali di interesse ingegneristico correlate ai loro processi produttivi e di trasformazione, con particolare attenzione alle interazioni materiale-ambiente e alla durabilità in servizio dei manufatti. La seconda finalità e quella di fornire allo studente, attraverso un approccio prevalentemente sperimentale di laboratorio, i fondamenti del monitoraggio ambientale introducendo le basi della determinazione analitica della qualità ambientale in relazione con i problemi connessi ai diversi processi di produzione industriale, all’interazione dei materiali con l’ambiente, al loro degrado e smaltimento. | 9 crediti |
| **Fisica 2** Il corso si prefigge di fornire agli studenti le conoscenze di base sui fenomeni elettromagnetici e la capacità di usare in modo predittivo le leggi che regolano i suddetti fenomeni. L'elettromagnetismo verrà presentato partendo dalla fenomenologia e con esempi legati agli aspetti di applicazione tecnologica e naturali dei fenomeni. Alla fine del corso lo studente avrà acquisito le quattro equazioni di Maxwell e le avrà applicate a svariati problemi. Il corso è propedeutico a parecchie materie di carattere più professionalizzante; poiché la maggior parte degli studenti, nel proprio percorso didattico, non affronterà in modo sistematico gli sviluppi della materia (ottica ed onde elettromagnetiche), il corso ha l'impegnativo scopo di dare solidi concetti perché lo studente possa approfondire ed affrontare autonomamente problemi che coinvolgono fenomeni elettromagnetici variabili nel tempo. | 6 crediti |
| **Fondamenti di meccanica razionale** Introdurre gli argomenti base della meccanica razionale: algebra vettoriale e vettori applicati, geometria delle masse, statica ed equazioni del moto per i sistemi vincolati più significativi (punto materiale, corpo rigido, sistemi olonomi), equazioni cardinali, conservazione dell'energia meccanica. | 6 crediti |
| **Ingegneria sanitaria** Il corso introduce gli studenti all’ingegneria sanitaria e, più in generale, alle problematiche ambientali. Gli studenti vi acquisiscono pertanto conoscenze di base. Vengono forniti elementi conoscitivi che integrano aspetti tecnologici, applicativi e specialistici che consentono la comprensione delle interazioni tra attività antropiche ed ambiente e successivamente, all’interno del percorso formativo completo, l’acquisizione di strumenti rivolti alla gestione delle problematiche ambientali. Lo studente viene sollecitato alla discussione di casi/situazioni contingenti e coinvolto (singolarmente o in gruppi) nell’approfondimento e presentazione di specifici aspetti ambientali. | 6 crediti |
| **Fisica tecnica** Il corso ha l’obiettivo di introdurre l’allievo alla conoscenza della termodinamica, in generale, approfondendo in particolare la termodinamica dell’aria umida e dell’atmosfera e quindi fornendo i principi fondamentali del condizionamento ambientale. Inoltre sono trattati i principi della trasmissione del calore, in regime stazionario e variabile, e introdotti i metodi numerici di soluzione. Una parte del corso è dedicata all’acustica applicata, con particolare riferimento alle implicazioni nel settore delle costruzioni civili. | 9 crediti |
| **Topografia** La disciplina della Topografia ha un carattere prevalentemente pratico e applicativo. Ciò nonostante risulta necessario inserire nel corso alcuni argomenti di carattere di base che tradizionalmente non vengono impartiti negli altri corsi frequentati dallo studente (nozioni sul trattamento statistico delle misure). Le conoscenze acquisite nel corso hanno un autonoma rilevanza per chi dovrà occuparsi professionalmente di rilevamento del territorio, ma hanno anche una valenza complementare e di supporto per altri ambiti applicativi in cui sia necessario svolgere rilievi dedicati a scopi specifici o utilizzare coscientemente e criticamente i prodotti di rilievi svolti da altri e i prodotti cartografici. Lo studente acquisisce conoscenze attraverso lezioni frontali e studio autonomo, acquisisce abilità operative con le attività di esercitazioni strumentali ed esercitazioni di elaborazione di dati. | 9 crediti |
| **Insegnamento a scelta** Insegnamenti a scelta offerti dal corso di studio oppure altri insegnamenti offerti dai corsi di laurea  triennale in Ing. per l'Ambiente e il Territorio e Ing. Civile, previa  richiesta allla Commissione di area didattica per approvazione. | 6 crediti |


### Terzo anno


| Insegnamenti obbligatori | Crediti |
| --- | --- |
| **Meccanica dei fluidi** L’insegnamento fornisce le nozioni di base della meccanica dei fluidi. Nella prima parte del programma vengono illustrati i fondamenti fisico-matematici della disciplina, mentre nella seconda parte vengono illustrate le applicazioni più importanti all’idraulica. L’insegnamento ha soprattutto un ruolo di base, propedeutico a molte delle applicazioni che verranno poi affrontate nei corsi di laurea specialistica dei settori dell’Ingegneria Civile ed Ambientale. Durante il corso lo studente impara ad elaborare in un contesto applicativo gli strumenti di base che gli sono stati forniti dalle discipline dell’area delle matematiche e della fisica. Il corso è integrato da una serie di esercizi applicativi aventi lo scopo di esercitare lo studente a risolvere dal punti di vista quantitativo anche alcune applicazioni. | 12 crediti |
| **Scienza delle costruzioni** Il corso si propone di illustrare i principi fondamentali riguardanti la meccanica dei solidi e delle strutture in regime elastico lineare e la resistenza dei materiali, fornendo le basi concettuali e i metodi per studiare il comportamento delle strutture ed accertarne la sicurezza in presenza di carichi assegnati. L'impostazione data al corso intende conciliare differenti esigenze: sviluppare con rigore le basi teoriche della disciplina; chiarire il significato fisico dei modelli strutturali introdotti, riconoscendone i limiti di applicabilità; fornire agli allievi capacità pratico-operative su tutti gli argomenti trattati. | 12 crediti |
| **Idrologia** Il corso fornisce le conoscenze di base necessarie alla comprensione dei principali processi idrologici che sottendono la generazione dei deflussi, le interazioni fra suolo vegetazione e atmosfera, nonché la dinamica delle acque sotterranee. Esso fornisce, inoltre, gli strumenti necessari allo svolgimento di studi idrologici per la progettazione di opere idrauliche e di interventi sul territorio che interagiscono con i corpi idrici e per la gestione delle risorse idriche. L’allievo verrà guidato alla comprensione ed alla valutazione quantitativa dei flussi idrologici, come ad esempio le portate dei corpi idrici e gli scambi di vapore con l’atmosfera, compreso il calcolo dei parametri assunti alla base della progettazione delle opere idrauliche. Alla fine del corso l’allievo sarà in grado di comprendere e valutare criticamente gli studi idrologici. | 6 crediti |
| **Geotecnica** Il corso è orientato a fornire una introduzione alla conoscenza del comportamento meccanico dei terreni e delle prove geotecniche in laboratorio e in sito, che costituiscono il punto di partenza per la definizione di un progetto geotecnico. Nel corso, si porrà particolare attenzione allo studio degli effetti della pressione dell’acqua interstiziale, alle problematiche indotte dalla evoluzione nel tempo delle pressioni interstiziali, ai concetti di resistenza del terreno in condizioni non drenate e drenate. Saranno privilegiate le competenze più applicative, che saranno utilizzate per l’interpretazione dei risultati di indagini in sito ed in laboratorio, con lo scopo di ottenere una descrizione geotecnica preliminare dei terreni. Le nozioni impartite in questo corso sono propedeutiche ai corsi di approfondimento teorico e ai corsi progettuali della laurea magistrale. | 6 crediti |
| **Ecologia** Il corso si propone di fornire allo studente: - conoscenze di base che consentono di affrontare in un'ottica ecologica i problemi di protezione e pianificazione del territorio, nonché di gestione delle risorse naturali. In tal senso vengono analizzati i principali fattori dell'ambiente e la loro influenza sugli ecosistemi terrestri, con particolare riferimento a quelli propri del territorio di montagna. - conoscenze sulla struttura e sul funzionamento dell'ecosistema, al fine di evidenziare l'importanza dei meccanismi di autoregolazione oltre che le interrelazioni fra le diverse cenosi | 9 crediti |
| **Tecnica delle costruzioni** Il corso si propone di fornire allo studente le conoscenze di base necessarie ad impostare la progettazione strutturale di tipiche costruzioni dell’ingegneria civile. Lo studente sarà quindi introdotto alla conoscenza delle basi teoriche necessarie ad effettuare i dimensionamenti e le principali verifiche dei più comuni elementi strutturali. Lo sviluppo di semplici esempi applicativi, svolti nel rispetto della normativa tecnica nazionale ed europea, consentirà allo studente di rielaborare ed approfondire i contenuti delle lezioni teoriche. | 6 crediti |
| **Insegnamento a scelta** Insegnamenti a scelta offerti dal corso di studio oppure altri insegnamenti offerti dai corsi di laurea  triennale in Ing. per l'Ambiente e il Territorio e Ing. Civile, previa  richiesta allla Commissione di area didattica per approvazione. | 6 crediti |
| **Altre attività** | 1 crediti |
| **Prova finale** Discussione orale di un tema scelto dallo studente all’interno di una lista di argomenti predisposta dal Collegio di Area Didattica. | 3 crediti |









[Iscriversi](/it/l/ingegneria-civile/iscriversi "Iscriversi")
-------------------------------------------------------------


Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I cittadini europei che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli.

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.  

Possono accedere e iscriversi ad anni successivi al primo, solo i cittadini e le cittadine italiani, dei Paesi dell’Unione Europea o non europei già residenti in Italia.









 







 

