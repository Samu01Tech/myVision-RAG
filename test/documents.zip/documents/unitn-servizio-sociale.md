

Orientamento
------------

* [I nostri studenti](http://orienta.unitn.it/cosa-scegliere/63/servizio-sociale)
* [Eventi di orientamento](http://orienta.unitn.it/come-scegliere/4/eventi-di-orientamento)
* [Orienta: tutti i servizi](http://orienta.unitn.it)
* [Scegliere UniTrento](http://www.unitn.it/ateneo/4/perche-scegliere-unitrento)




* **Livello**: Laurea di primo livello
* **Classe** del corso: **L39 Servizio Sociale**
* Lingua in cui si tiene il corso: **italiano**
* **Modalità di accesso**: **programmato**, con superamento di una prova d'ammissione
* **Sede**: Dipartimento di Sociologia e ricerca sociale, via Verdi 26, 38122 Trento.

Il corso di laurea in Servizio Sociale prepara alla professione di assistente sociale che si può esercitare dopo aver superato l’esame di stato per l’abilitazione alla professione e l’iscrizione all’albo professionale. Il corso si rivolge a chi intende impegnarsi per portare un cambiamento positivo nella società e contribuire a costruire un mondo più giusto e sostenibile, coltivando la solidarietà e la cura delle relazioni, lavorando insieme alle persone e con le organizzazioni.

Il Servizio Sociale sviluppa conoscenze per occuparsi del rapporto tra persone e ambiente, considerando le due dimensioni:

* le persone, con l’obiettivo di accompagnarle nel migliorare la loro relazione con l’ambiente;
* l’ecosistema sociale (persone, rapporti, istituzioni, servizi) affinché  risponda ai bisogni di chi lo vive.

La professione dell’assistente sociale attraversa i confini delle classi sociali: nel realizzare l’attività professionale l’assistente sociale incontra persone diversissime tra loro, con visioni della vita molto differenziate; ciò permette di ampliare la propria conoscenza del mondo e allena a coltivare il dialogo e la collaborazione.  Si è in contatto con il cambiamento costante delle società e con le forme di ingiustizia e di emarginazione: dalla povertà, all’analfabetismo, dall’emigrazione e alle disuguaglianze prodotte dai disastri ambientali, dall’isolamento o dall’individualizzazione dei legami sociali.

Il corso aiuta ad acquisire:

* un sapere multidisciplinare (negli ambiti della Sociologia, della Psicologia, del Diritto) finalizzato alla comprensione e all’analisi dei problemi sociali e delle loro cause, dei modi in cui si manifestano e delle conseguenze che hanno sulle persone;
* Il sapere professionale della disciplina di servizio sociale, che consente di acquisire un metodo, essere consapevole dei valori di riferimento e dei diversi approcci teorici, di avere la competenze necessarie per la realizzazione dei progetti di aiuto e intervento
* Le conoscenze e i metodi utili a sviluppare la capacità di riflessione critica e di collegare la pratica professionale agli aspetti teorici e i risultati delle ricerche,  per essere in grado di cogliere i problemi e mettere in campo azioni innovative

### Obiettivi formativi

Il percorso formativo mira a far acquisire ai laureati e alle laureate in Servizio Sociale:

* la capacità di conoscere il tessuto sociale territoriale e delle politiche sociali, al fine di coglierne i bisogni e le risorse e individuare le strategie di intervento sia a livello individuale che nell’organizzazione dei servizi.
* La capacità di collaborare con le persone che accedono ai servizi e con la rete dei professionisti.
* La capacità di individuare e intervenire nelle situazioni a rischio di emarginazione e di deprivazione economica e sociale, progettando e realizzando gli interventi.
* La capacità di intervenire efficacemente aiutando persone in difficoltà a riorganizzarsi nel gestire vari aspetti della vita pratica e relazionale.
* La capacità di analizzare criticamente i contesti, assicurando forme di supporto e protezione nelle situazioni di rischio e sostenendo la tutela dei soggetti deboli.
* La capacità di prevenire situazioni di disagio, attraverso la sensibilizzazione della comunità e la corresponsabilizzazione dei cittadini.

### Profili professionali

La laurea in Servizio Sociale prepara alla professione di **assistente sociale**, che si può esercitare dopo aver superato l’[esame di stato per l’abilitazione alla professione e l’iscrizione all’albo professionale](http://www.unitn.it/servizi/257/abilitazione-alla-professione-di-assistente-sociale-sezione-b).

Gli assistenti e le assistenti sociali possono lavorare come dipendenti nei servizi sociali e sociosanitari degli enti pubblici o degli enti del privato sociale,  oppure come liberi professionisti.

### Studi che si possono intraprendere dopo la laurea

Al termine della laurea in Servizio Sociale è possibile accedere a corsi di laurea magistrale, master di primo livello e altri percorsi formativi, in base ai requisiti di ammissione previsti.

All'Università di Trento la laurea in Servizio Sociale fornisce le conoscenze necessarie per accedere:

* alla laurea magistrale in [Metodologia, organizzazione e valutazione dei servizi sociali](http://offertaformativa.unitn.it/it/lm/metodologia-organizzazione-e-valutazione-dei-servizi-sociali/il-corso), che prepara alla professione dell'**assistente sociale specialista**
* alla laurea magistrale in [Global and Local Studies](https://offertaformativa.unitn.it/it/lm/global-and-local-studies)
* alla laurea magistrale in [Organizzazione, Società e Tecnologia](https://offertaformativa.unitn.it/it/lm/organizzazione-societa-tecnologia)
* alla laurea magistrale in [Sociology and social research](http://offertaformativa.unitn.it/it/lm/sociology-and-social-research/il-corso)
* alla laurea magistrale in [Data Science](https://offertaformativa.unitn.it/en/lm/data-science)
* ai [Master di primo livello](https://www.unitn.it/ateneo/200/master).








La laurea in Servizio Sociale si articola in tre anni di studio in cui si affrontano insegnamenti che spaziano dall’ambito della Sociologia a quello della Psicologia, delle Politiche Sociali e l’Organizzazione dei servizi al Diritto e fornisce le metodologie per analizzare, comprendere e cercare di risolvere i problemi sociali.

Il corso offerto dall’Università di Trento ha alcuni punti di forza peculiari:

* ha una forte connessione con la professione dell’assistente sociale, grazie alla presenza di diversi docenti che possiedono sia un’esperienza professionale nel campo sia la competenza accademica.
* Dà ampio spazio agli insegnamenti specifici di servizio sociale, dai fondamenti etici della professione e le teorie del servizio sociale, fino ai metodi e alle tecniche del servizio sociale, sviluppati con una particolare attenzione all’analisi e valutazione dei bisogni, la progettazione degli interventi, la partecipazione, lo sviluppo di comunità e alla capacità critica e riflessiva.
* Dedica molta attenzione al [tirocinio professionale](tirocinio-professionale) seguendo gli studenti e le studentesse sia con supervisori aziendali che un’équipe di tutor accademici, professionisti del Servizio Sociale impegnati a tempo pieno nel seguire gli studenti per la rielaborazione di ciò che imparano in aula e ciò che sperimentano nella pratica.
* Coinvolge nelle attività di insegnamento, con testimonianze dirette, sia le persone che si sono rivolte ai servizi sociali sia i professionisti che in essi lavorano.
* È collegato con le attività di ricerca del Dipartimento, i convegni e le iniziative della Società Italiana di Servizio Sociale (SOCISS), di altre associazioni e degli organismi internazionali del settore.

Primo anno
----------


### **Insegnamenti obbligatori**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Individui, famiglie e società  Il corso si propone di fornire agli studenti gli strumenti concettuali e analitici per comprendere i principali fenomeni e istituzioni sociali evidenziando la complessa natura del rapporto tra individui, gruppi sociali e istituzioni attraverso opportuni schemi interpretativi | 6 |
| Principi, deontologia e etica del servizio sociale  Il corso si propone di fornire conoscenze relative ai principi etici e deontologici del servizio sociale come strumenti di guida per l’azione per permettere di valutare il fondamento etico e deontologico delle diverse scelte professionali in relazioni ai principi fondativi della professione | 6 |
| Teorie e approcci al servizio sociale  Il corso ha lo scopo di fornire le conoscenze teoriche relative ai principali approcci teorici e metodologici del servizio sociale e di promuovere e incentivare una formazione di base pluralistica e flessibile per l’esercizio della professione | 8 |
| Relazioni interpersonali e comunicazione sociale  Il corso fornisce strumenti e competenze per gestire le relazioni comunicative con gli individui e i gruppi sociali di riferimento permettendo un uso corretto delle tecniche comunicative e di relazione interpersonale basate sulla comprensione, l’ascolto attivo, l’uso corretto del linguaggio e la negoziazione | 6 |
| Diritto e amministrazione per il servizio sociale  Il corso si propone di fornire le conoscenze dell’inquadramento giuridico pubblico e amministrativo e gli strumenti di lettura delle principali normative che impattano sul lavoro di servizio sociale | 6 |
| Tirocinio osservativo  Il tirocinio osservativo si propone di introdurre gli studenti nel mondo dei servizi sociali offrendo la possibilità di conoscere e interagire con il sistema degli attori e dei servizi entro il quale si svolgono i processi di aiuto e di sviluppare capacità di analisi e osservazione autonome. Il tirocinio viene normato da apposito Regolamento | 4 |
| Diversità e relazioni interculturali  Il corso si propone di fornire chiavi di analisi e comprensione e strumenti di lavoro per operare all’interno di una società culturalmente e etnicamente plurale permettendo la comprensione dei fattori culturali che caratterizzano l’interazione sociale con gruppi e individui appartenenti a culture diverse | 6 |
| Politiche del welfare sociale  Il corso offre gli strumenti concettuali e analitici per comprendere la configurazione delle politiche sociali e il complesso rapporto esistente tra di esse e il concreto lavoro degli assistenti sociali nei diversi comparti di attività | 8 |
| Competenze linguistiche - Inglese B1  Il corso si propone di sviluppare le capacità ricettive della competenza linguistica, in particolare la capacità di leggere e comprendere dei testi, e di interagire in una conversazione e produrre un testo | 4 |
|

Secondo anno
------------


### **Insegnamenti obbligatori**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Comportamento umano in contesti sociali  Il corso si propone di offrire le basi concettuali e gli strumenti di analisi e comprensione dei fenomeni di categorizzazione sociale e di influenza e interazione tra individui e gruppi sociali con particolare attenzione all’analisi dei processi di identificazione sociale, socializzazione, esclusione e stigma sociali | 8 |
| Metodi di valutazione e progettazione per gli interventi di servizio sociale  Il corso offre le conoscenze e gli strumenti per valutare e progettare interventi di servizio sociale sia in relazione a singoli individui che a famiglie e gruppi sociali specifici attraverso un approccio multidisciplinare e critico riflessivo | 8 |
| Diritto penale e dell’esecuzione della pena  Il corso si propone di far acquisire una conoscenza generale del sistema penale ed un’adeguata consapevolezza delle principali problematiche penalistiche connesse alla professione dell’assistente sociale, mediante un’analisi critica del sistema normativo | 9 |
| Servizio sociale di comunità  Il corso fornisce conoscenze e strumenti per supportare e orientare il lavoro di servizio sociale di comunità e per promuovere la partecipazione come parte integrante del processo di aiuto e di inclusione sociale sviluppando le capacità di analisi, interazione e negoziazione tra i diversi interlocutori comunitari dei servizi. | 6 |
| Modelli di organizzazione per il servizio sociale  Il corso si propone di fornire gli strumenti per l’analisi organizzativa con particolare riguardo per le organizzazioni di servizio sociale, pubbliche, private e di terzo settore | 6 |
| Medicina del servizio sociale  Il corso di propone di descrivere e riconoscere i principali processi e fattori che sostengono la salute e concorrono a generare le forme di patologia che impattano maggiormente con il lavoro di servizio sociale | 6 |
| Rischi, politiche e diritti  Il corso intende offrire conoscenze e strumenti per l’analisi e la comprensione del modo in cui si definiscono i diritti sociali e sono riconosciuti attraverso le politiche pubbliche sui diversi livelli di governo | 6 |
| Primo tirocinio  Il primo tirocinio ha come obiettivo l’apprendimento di conoscenze e strumenti all’interno dei servizi con la guida di un supervisore e relativi al lavoro con i singoli individui. Il tirocinio viene normato da apposito Regolamento | 10 |
| Competenze informatiche  Il corso si propone di fornire agli studenti le competenze utili per trattare proficuamente informazioni in formato digitale | 2 |
|

Terzo anno
----------


### **Insegnamenti obbligatori**


| Insegnamento | Crediti (CFU) |
| --- | --- |
| Laboratorio di pratica riflessiva  Il corso si propone di fornire agli studenti strumenti per operare in forma critico riflessiva rispetto a singoli interventi sia individuali che di gruppo sviluppando le competenze di rielaborazione dei problemi e di riformulazione continua delle ipotesi di interventi | 6 |
| Psicologia delle età della vita  Il corso si propone di presentare i principali modelli interpretativi dello sviluppo umano utilizzando la prospettiva del ciclo di vita, dalla nascita all’età senile in modo da permettere una comprensione adeguata di fattori psicologici che influenzano le diverse età della vita e i bisogni ad esse correlati | 8 |
| Progettazione di interventi per il territorio  Il corso intende offrire conoscenze e strumenti per l’analisi e la progettazione economica di interventi complessi di servizio sociale a livello territoriale | 6 |
| Servizio sociale in pratica  Il corso si propone di fornire conoscenze e strumenti di lavoro per operare nei diversi ambiti di intervento del servizio sociale attraverso l’esercizio del lavoro istituzionale, associativo e in forma di libera professione e l’uso appropriato degli strumenti di lavoro e analisi e intervento in relazione al contesto di riferimento | 6 |
| Diritto di famiglia  Il corso si propone di offrire strumenti conoscitivi ed operativi sugli istituti del diritto di famiglia e delle persone, in particolare dei minorenni e sul funzionamento degli organi giurisdizionali competenti e del rapporto tra gli stessi e il lavoro di servizio sociale | 6 |
| Devianza e controllo sociale  Il corso si propone di favorire l’ acquisizione di una adeguata conoscenza teorica e intervento nei confronti dei fenomeni di devianza sociale, con sviluppo di strumenti di lavoro relativi alla prevenzione e alla riabilitazione dai processi di criminalizzazione, vittimizzazione e controllo sociale | 8 |
| Secondo tirocinio  Il secondo tirocinio ha come obiettivo l’apprendimento di conoscenze e strumenti all’interno dei servizi (con la guida di un supervisore) relativi al lavoro con i gruppi sociali sia nella prospettiva della prevenzione che della promozione di interventi di aiuto e inclusione sociale incentivando lo sviluppo di autonomia di giudizio, capacità di apprendimento e rielaborazione e consapevolezza di ruolo . Il tirocinio viene normato da apposito Regolamento | 10 |
| Materie a scelta  Le materie a scelta hanno lo scopo di completare la formazione con attività formative a scelta che vengano incontro agli interessi degli studenti (insegnamenti o altre attività formative quali seminari di credito, laboratori, eccetera) | 12 |
| Prova finale  La prova finale della laurea prevede la stesura di un elaborato su un tema approvato dal Supervisore. Le modalità di svolgimento della prova finale e di conseguimento del titolo sono disciplinate in un apposito Regolamento | 3 |
|









Per iscriversi al corso è necessario avere un diploma di scuola secondaria o di altro titolo di studio conseguito all'estero riconosciuto idoneo.

Il corso è a numero programmato: i posti sono assegnati in base a una selezione destinata a cittadini e cittadine italiani, cittadini e cittadine dei Paesi dell’Unione Europea, cittadini e cittadine non europei residenti al di fuori dell’Italia.




Iscrizione anno accademico 2025/2026
------------------------------------

### Ammissioni e immatricolazioni al primo anno

Per essere ammessi al corso di laurea è necessario superare un test TOLC gestito dal CISIA (Consorzio Interuniversitario Sistemi Integrati per l’Accesso).

I bandi e le scadenze sono pubblicati alla pagina [Ammissioni 2025](https://www.unitn.it/ammissioni-2025).

Sul sito del CISIA sono disponibili informazioni sui contenuti e la struttura del TOLC, materiali didattici e simulazioni per prepararsi al test: [TOLC: esercitazioni e simulazioni](https://www.cisiaonline.it/area-tematica-tolc-cisia/tolc-esercitazioni-e-simulazioni/).

### Passaggi di corso, trasferimenti e riconoscimento crediti

I candidati e le candidate che chiedono di iscriversi con:

* passaggio di corso
* trasferimento da un altro Ateneo
* il riconoscimento crediti da carriere chiuse per laurea, decadenza, rinuncia agli studi o da corsi singoli

devono presentare la domanda per l'ammissione ad anni successivi secondo scadenze e modalità indicate sul sito entro il 3 febbraio 2025.









 

